function h = mkWhisker(d,xl,groupColor,varargin)
    if nargin<2 || isempty(xl)
        xl = 1:length(d(1,:));
    end

    if ~iscell(d)
        newD = repmat({[]},[1 length(d(1,:))]);
        for i = 1:length(d(1,:))
            newD{i} = d(:,i);
        end
        d = newD;
    end
    
    groups = length(d(:,1));
    ticks = length(d(1,:));
    set(gca,'xlim',[0.5 ticks+0.5],'xtick',[1:ticks],'xticklabel',xl,'fontname','arial',...
        'fontsize',10,'fontweight','bold')
    hold on
    
    w = 0.6;
    wpg = w./groups;
%     groupColor = ones(groups,3).*0.8

    if nargin < 3 || isempty(groupColor)
        groupColor = [0.3 0.3 0.3; 0.4 0.4 0.9];
    end
%     groupColor = [{[0.7 0.7 0.9]} {[0.6 0.6 0.9]} {[0.5 0.5 0.9]} {[0.4 0.4 0.9]} {[0.9 0.9 0.6]} {[0.6 0.9 0.6]} {[0.6 0.9 0.6]} {[0.6 0.9 0.6]}];
%     groupColor = cat(1,groupColor{:});
%     groupColor = (cool(groups)/2)+.3;
%     tmp = transcm;
%     groupColor = tmp(round(linspace(1,length(tmp),groups)),:);
    
%     groupColor = [0.5 0.5 0.5; 0.7 0.7 0.7; 0.5 0.5 0.9; 0.7 0.7 0.9; ...
%         0.9 0.5 0.5; 0.9 0.7 0.7; 0.8 0.5 0.8; 0.8 0.7 0.8; 0.5 0.5 0.5; 0.7 0.7 0.7;...
%         [0.5 0.5 0.5; 0.7 0.7 0.7; 0.5 0.5 0.9; 0.7 0.7 0.9; ...
%         0.9 0.5 0.5; 0.9 0.7 0.7; 0.8 0.5 0.8; 0.8 0.7 0.8; 0.5 0.5 0.5; 0.7 0.7 0.7]];
    
%     groupColor = repmat(hsv(4),[4 1]);

    dip = 0.025; 
    th = [];
    jitters = repmat({[]},[size(d)]);
    for i = 1:groups
        for j = 1:ticks
            jitters{i,j} = randn(size(d{i,j})).*0.05;
        end
    end
    for i = 1:groups
        for j = 1:ticks
            
            if length(d{i,j})>=1
                h(i,j) = plot(j-(w./2)+(wpg.*(i-1))+wpg./2+jitters{i,j},d{i,j},'linestyle','none','color',ones(1,3).*0.75,...
                    'marker','o','markersize',5,'markerfacecolor',ones(1,3).*0.75);

                if j<ticks && length(d{i,j})==length(d{i,j+1})
                    plot([j-(w./2)+(wpg.*(i-1))+wpg./2+jitters{i,j} ...
                        (j+1)-(w./2)+(wpg.*(i-1))+wpg./2+jitters{i,(j+1)}]',[d{i,j} d{i,j+1}]','linestyle','-',...
                        'color',ones(1,3).*0.75);
                end
            end
            
        end
    end

    ebW = 6;
    th = [];
    for i = 1:groups
        for j = 1:ticks
            if isempty(d{i,j})
                continue
            end
            sVals = sort(d{i,j});
            sVals(isnan(sVals)) = [];
            
%             plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]).*ones(1,2),...
%                 sVals([1 end]),'color','k','linewidth',2);

            % 1 SD Cutoff Rule 
            cutoff = [nanmean(sVals)-nanstd(sVals) nanmean(sVals)+nanstd(sVals)];
            cutoff = [-inf inf];

            % Tukey plot rule +/- 1.6 IQR
%             iqr = [sVals(ceil(length(sVals).*0.75))-sVals(floor(length(sVals).*0.25))];
%             cutoff = [sVals(floor(length(sVals).*0.25))-iqr.*1.5 sVals(ceil(length(sVals).*0.75))+iqr.*1.5];

            plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]).*ones(1,2),...
                [max(cutoff(1),sVals(1)) min(cutoff(2),sVals(end))],'color',groupColor(ceil(j),:),'linewidth',1.5,'linestyle','-');
            
%             plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]),...
%                 sVals([sVals<cutoff(1)|sVals>cutoff(2)]),'linestyle','none',...
%                 'marker','d','markersize',2.5,'markerfacecolor','k','color','k','markeredgecolor','k')
            
            h(i,j) = patch([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i)) (j-(w./2))+(wpg.*(i)) (j-(w./2))+(wpg.*(i-1))],...
                [sVals(floor(length(sVals).*0.25)) sVals(floor(length(sVals).*0.25)) ...
                sVals(ceil(length(sVals).*0.75)) sVals(ceil(length(sVals).*0.75))],...
                groupColor(ceil(j),:),'edgecolor',groupColor(ceil(j),:),'linewidth',2,'facecolor','none');
            
            plot(([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]),...
                [nanmedian(sVals) nanmedian(sVals)],'color',groupColor(ceil(j),:),'linewidth',2);
        end
    end
end