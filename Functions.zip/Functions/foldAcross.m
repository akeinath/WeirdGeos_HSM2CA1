function out = foldAcross(a,s,outField)
    out = a;
    
    outParts = [];
    inds = [0 find(ismember(outField,'.')) length(outField)+1];
    for i = 1:length(inds)-1
        outParts = [outParts {outField(inds(i)+1:inds(i+1)-1)}];
    end
    
    for i = 1:length(outParts)
        if ~isfield(out,(outParts{i}))
            
        end
    end
    
end