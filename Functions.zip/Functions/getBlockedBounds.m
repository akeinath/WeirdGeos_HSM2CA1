function bounds = getBlockedBounds(blocked)
    x = 75;
    bounds = [0 0 x 0; 0 0 0 x; ...
        0 x x x; x 0 x x];
    
    blockMap = [0 1 2; 3 4 5; 6 7 8]';
    x = 25;
    tb = [0 0 x 0; 0 0 0 x; ...
        0 x x x; x 0 x x];
    
    for  i = 1:length(blocked)
        [a b] = find(blockMap==blocked(i));
        if ~isempty(a)
            bounds = [bounds; bsxfun(@plus,tb,[(a-1).*25 (b-1).*25 (a-1).*25 (b-1).*25])];
        end
    end
    
%     figure
%     set(gcf,'position',[50 50 350 350])
%     for i = 1:length(bounds(:,1))
%         plot(bounds(i,[1 3]),bounds(i,[2 4]),'color','k')
%         hold on
%     end
%     set(gca,'xlim',[-5 80],'ylim',[-5 80]);
end