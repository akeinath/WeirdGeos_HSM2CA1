function mkf2f2Vec(f2f,blocked,root)

    scalar = 0.2;

    %%%%% Full flow diagram

    figure
    set(gcf,'position',[50 50 length(f2f).*100 3.*200])
    for si = 1 %:length(um(1,1,1,:))
        for sj = si+1:length(f2f)
            
            a = f2f{si,sj}(:,1:2);
            b = f2f{si,sj}(:,3:4);
            
            vm = [];
            for i = 1:15
                for j = 1:15
                    good = [(floor(a(:,1))+1 >= (i-1)) & (floor(a(:,1))+1 <= (i+1))] & ...
                        [(floor(a(:,2))+1 >= (j-1)) & (floor(a(:,2))+1 <= (j+1))];
                    
                    vm = [vm; i j nanmean(b(good,:)-[i j],1)];
                end
            end
            vm(any(isnan(vm),2),:) = [];
            

            isClosed = reshape(ismember([0:8],blocked{sj})',[3 3])';
            [a b] = find(isClosed);
            
            subplot(2,5,sj-1)
            quiver(vm(:,1),vm(:,2),vm(:,3).*scalar,vm(:,4).*scalar,'off');
            hold on
            for i = 1:length(a(:,1))
                rectangle('position',[(a(i)-1).*5+0.5 (b(i)-1).*5+0.5 5 5])
            end
            axis equal
            axis off
        end
    end
    saveFig(gcf,[root '/FieldFlow_Raw'],[{'tiff'} {'pdf'} {'jpeg'}])

    
    %%%%% Square-subtracted flow diagram
    
    si = 1;
    sj = 11;
    a = f2f{si,sj}(:,1:2);
    b = f2f{si,sj}(:,3:4);

    vm = [];
    refDistMap = nan(15,15);
    for i = 1:15
        for j = 1:15
            good = [(floor(a(:,1))+1 >= (i-1)) & (floor(a(:,1))+1 <= (i+1))] & ...
                [(floor(a(:,2))+1 >= (j-1)) & (floor(a(:,2))+1 <= (j+1))];

            vm = [vm; i j nanmean(b(good,:)-[i j],1)];
            
            tmp = b(good,:)-[i j];
            if ~isempty(tmp)
                [theta dist] = cart2pol(tmp(:,1),tmp(:,2));
                if length(dist(:,1)) >= 5
                    refDistMap(j,i) = nanmean(dist);
                end
            end
        end
    end
    vm(any(isnan(vm),2),:) = [];
    vmRef = vm;
    
    figure
    set(gcf,'position',[50 50 3.*200 3.*200])
    for si = 1 %:length(um(1,1,1,:))
        for sj = si+1:length(f2f)-1
            
            a = f2f{si,sj}(:,1:2);
            b = f2f{si,sj}(:,3:4);
            
            vm = [];
            for i = 1:15
                for j = 1:15
                    good = [(floor(a(:,1))+1 >= (i-1)) & (floor(a(:,1))+1 <= (i+1))] & ...
                        [(floor(a(:,2))+1 >= (j-1)) & (floor(a(:,2))+1 <= (j+1))];
                    
                    vm = [vm; i j nanmean(b(good,:)-[i j],1)];
                end
            end
            vm(any(isnan(vm),2),:) = [];
            
            for i = length(vm(:,1)):-1:1
                isGood = ismember(vmRef(:,1),vm(i,1))&ismember(vmRef(:,2),vm(i,2));
                if ~any(isGood)
                    vm(i,:) = [];
                else
                    vm(i,3:4) = vm(i,3:4) - vmRef(isGood,3:4);
                end
            end
            
            isClosed = reshape(ismember([0:8],blocked{sj})',[3 3])';
            [a b] = find(isClosed);
            
            subplot(3,3,sj-1)
            quiver(vm(:,1),vm(:,2),vm(:,3).*scalar,vm(:,4).*scalar,'off');
            hold on
            for i = 1:length(a(:,1))
                rectangle('position',[(a(i)-1).*5+0.5 (b(i)-1).*5+0.5 5 5])
            end
            axis equal
            axis off
        end
    end
    
    saveFig(gcf,[root '/FieldFlow_SquareNormed'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%% Square-subtracted field distances
    
    figure
    set(gcf,'position',[50 50 3.*200 3.*200])
    for si = 1 %:length(um(1,1,1,:))
        for sj = si+1:length(f2f)-1
            
            a = f2f{si,sj}(:,1:2);
            b = f2f{si,sj}(:,3:4);
            
            distMap = nan(15,15);
            for i = 1:15
                for j = 1:15
                    good = [(floor(a(:,1))+1 >= (i-1)) & (floor(a(:,1))+1 <= (i+1))] & ...
                        [(floor(a(:,2))+1 >= (j-1)) & (floor(a(:,2))+1 <= (j+1))];
                    
                    tmp = b(good,:)-[i j];
                    if ~isempty(tmp)
                        [theta dist] = cart2pol(tmp(:,1),tmp(:,2));
                        if length(dist(:,1)) >= 5
                            distMap(j,i) = nanmean(dist);
                        end
                    end
                end
            end
            
            isClosed = reshape(ismember([0:8],blocked{sj})',[3 3])';
            [a b] = find(isClosed);
            
            subplot(3,3,sj-1)
            imagesc(distMap-refDistMap)
            alpha(double(~isnan(distMap-refDistMap)))
            hold on
            for i = 1:length(a(:,1))
                rectangle('position',[(a(i)-1).*5+0.5 (b(i)-1).*5+0.5 5 5])
            end
%             caxis([-8 8])
%             colormap('cool')
            axis off
        end
    end
    
    saveFig(gcf,[root '/FieldDistance_SquareNormed'],[{'tiff'} {'pdf'} {'jpeg'}])
end

























