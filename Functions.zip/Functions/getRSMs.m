function rsm = getRSMs(m)
    for i = numel(m)
        m{}
    end
end