function sim = getPairwiseMapSim(um,varargin)

    if isstruct(um)
        tmp = um;
        um = tmp.maps;
        trace = tmp.trace;
    elseif ndims(um) == 2
        trace = um;
    else
        % input is indeed a map
    end

    if nargin<2 || isempty(varargin)
        varargin = {'pearson'};
    end

    if ismember({'pfr'},varargin)
        %%% peak firing rate differences
        fprintf('\n\tComputing peak firing rate differences...')
        tic
        apfr = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        rpfr = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                tmp = abs(permute(nanmax(nanmax(tmp1,[],1),[],2)-nanmax(nanmax(tmp2,[],1),[],2),[3 1 2]));
                apfr(si,sj,:) = tmp;
                rpfr(si,sj,:) = tmp./permute(nanmax(nanmax(nanmax(tmp1,[],1),[],2), ...
                    nanmax(nanmax(tmp2,[],1),[],2)),[3 1 2]);
            end
        end     
        sim.pfr.abs = apfr;
        sim.pfr.rel = rpfr;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'emd_scaled'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing earth movers distance (scaled) map similarity...')
        tic
        [x y] = meshgrid(1:size(um,1),1:size(um,2));
        d2e = sqrt(bsxfun(@minus,x(:),x(:)').^2 + bsxfun(@minus,y(:),y(:)').^2);
        emds = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                tmp1 = mnorm(tmp1);
                tmp2 = mnorm(tmp2);
                
                rt1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                rt2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                
%                 emds(si,sj,:) = nanmean(abs(rt1-rt2));

                drt1 = bsxfun(@minus,permute(rt1,[1 3 2]),permute(rt1,[3 1 2]));
                drt2 = bsxfun(@minus,permute(rt2,[1 3 2]),permute(rt2,[3 1 2]));
                
                tmp = bsxfun(@times,abs(drt1-drt2),d2e);
                tmp = reshape(tmp,[numel(tmp(:,:,1)) length(tmp(1,1,:))]);

                emds(si,sj,:) = nanmean(tmp);
                
            end
            
            figure(1)
            imagesc(squarify(nanmean(emds,3)))
            drawnow
            
        end     
        sim.emds = emds;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'pearson'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pearsons map similarity...')
        tic
        pearson = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                pearson(si,sj,:) = xcorr3transform(tmp1,tmp2,[0 0 0]);
            end
        end     
        sim.pearson = pearson;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'c2c_pearson'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pearsons map similarity across cells...')
        tic
        c2cpearson = nan([length(um(1,1,:,1)) length(um(1,1,:,1)) length(um(1,1,1,:)) length(um(1,1,1,:))]);
        for si = 1:length(um(1,1,1,:))
            for sj = 1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                rtmp1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                rtmp2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                
                isBad = all(isnan(rtmp1),2) | all(isnan(rtmp2),2);
                rtmp1(isBad,:) = [];
                rtmp2(isBad,:) = [];
                
                mcr(um(:,:,:,si),um(:,:,:,sj),true);
                
                c2cpearson(:,:,si,sj) = corr(rtmp1,rtmp2);
            end
        end     
        sim.c2c.pearson = c2cpearson;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'pv'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing population vector map similarity...')
        tic
        pv = nan([length(um(1,1,1,:)) length(um(1,1,1,:))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                tmp = pvxcorr(tmp1,tmp2,[1 1]);
                pv(si,sj) = tmp(2,2);
            end
        end     
        sim.pv = pv;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'partitioned_pv'},varargin)
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pop vec similarity with 3 partitions...')
        tic
        pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 1]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for i1 = 1:3
                    for j1 = 1:3
                        for i2 = 1:3
                            for j2 = 1:3
                                tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                                tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);
                                
                                isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);
                                
                                if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
                                    continue
                                end
                                
                                a = tmp1(repmat(isGoodPix,[1 1 length(tmp1(1,1,:))]));
                                b = tmp2(repmat(isGoodPix,[1 1 length(tmp2(1,1,:))]));
                                doInclude = ~isnan(a) & ~isnan(b);
                                
                                pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2) = ...
                                    corr(a(doInclude),b(doInclude));
                            end
                        end
                    end
                end
            end
        end     
        sim.partitioned.pv = pp;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'partitioned_pearson'},varargin)
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pearsons map similarity with 3 partitions...')
        tic
        pp2 = nan([9 9 length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for qi = 1:9
                    j1 = floor((qi-1)./3)+1;
                    i1 = mod((qi-1),3)+1;
                    
                    tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                    rt1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                    for qj = 1:9
                        j2 = floor((qj-1)./3)+1;
                        i2 = mod((qj-1),3)+1;
                        
                        tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);

                        isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);

                        if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
                            continue
                        end
                        rt2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                        
                        doInclude = ~all(isnan(rt1),2) & ~all(isnan(rt2),2);
                        
                        tmp = corr(rt1(doInclude,:),rt2(doInclude,:));
                        pp2(qi,qj,si,sj,:) = tmp(1:length(tmp)+1:end);
                    end
                end
            end
        end 
        ts = size(pp2);
        sim.partitioned.pearson = reshape(permute(pp2,[1 3 2 4 5]), ...
            [prod(ts([1 3])) prod(ts([1 3])) length(pp2(1,1,1,1,:))]);
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
%     if ismember({'partitioned_pearson'},varargin)
%         partSize = ceil(length(um(:,1,1,1))./3);
%         %%% Pearson correlation similarity
%         fprintf('\n\tComputing pearsons map similarity with 3 partitions...')
%         tic
%         pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 length(um(1,1,:,1))]);
%         for si = 1:length(um(1,1,1,:))
%             for sj = si:length(um(1,1,1,:))
%                 for i1 = 1:3
%                     for j1 = 1:3
%                         for i2 = 1:3
%                             for j2 = 1:3
%                                 tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
%                                 tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);
%                                 
%                                 isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);
%                                 
%                                 if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
%                                     continue
%                                 end
%                                 
%                                 pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2,:) = ...
%                                     xcorr3transform(tmp1,tmp2,[0 0 0]);
%                             end
%                         end
%                     end
%                 end
%             end
%         end     
%         sim.partitioned.pearson = pp;
%         tmp = toc;
%         fprintf('  %0.3fs.',tmp);
%     end
    
    if ismember({'partitioned_pfr'},varargin)
        
        num = maxnorm(um);
        
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pfr similarity with 3 partitions...')
        tic
        appfrs = nan([length(um(1,1,1,:)) 9 length(um(1,1,:,1))]);
        pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for i1 = 1:3
                    for j1 = 1:3
                        tmp1 = num((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                        appfrs(si,((j1-1).*3) + i1,:) = nanmax(nanmax(tmp1,[],1),[],2);
                        for i2 = 1:3
                            for j2 = 1:3
                                tmp2 = num((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);
                                
                                
                                pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2,:) = ...
                                    abs(nanmax(nanmax(tmp1,[],1),[],2) - nanmax(nanmax(tmp2,[],1),[],2));
                            end
                        end
                    end
                end
            end
        end     
        sim.partitioned.dpfr = pp;
        sim.partitioned.pfr = appfrs;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'cosine'},varargin)
        fprintf('\n\tComputing cosine similarity...')
        tic
        cossim = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);

                tmp1 = reshape(tmp1,[numel(um(:,:,1,1)) length(um(1,1,:,1))]);
                tmp2 = reshape(tmp2,[numel(um(:,:,1,1)) length(um(1,1,:,1))]);

                isGood = ~all(isnan(tmp1),2) & ~all(isnan(tmp2),2);
                tmp1 = tmp1(isGood,:);
                tmp2 = tmp2(isGood,:);

                isGood = ~all(isnan(tmp1),1) & ~all(isnan(tmp2),1);
                tmp1 = tmp1(:,isGood);
                tmp2 = tmp2(:,isGood);

                dp = pdist2(tmp1',tmp2','cosine');
                
                cossim(si,sj,isGood) = diag(dp);
            end
        end     
        sim.cosine = cossim;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    if ismember({'peak'},varargin)
        fprintf('\n\tComputing difference in peak locations...')
        tic
        isPeak = um==repmat(nanmax(nanmax(um,[],1),[],2),size(um(:,:,1,1)));
        ploc = nan(2,length(um(1,1,1,:)),length(um(1,1,:,1)));
        d2p = nan(length(um(1,1,1,:)),length(um(1,1,1,:)),length(um(1,1,:,1)));
        for k = 1:length(um(1,1,:,1))
            for i = 1:length(um(1,1,1,:))
                [x y] = find(isPeak(:,:,k,i));
                if ~isempty(x)
                    ploc(:,i,k) = [nanmedian(x) nanmedian(y)]';
                end
            end
            d2p(:,:,k) = sqrt(bsxfun(@minus,ploc(1,:,k),ploc(1,:,k)').^2 + ...
                bsxfun(@minus,ploc(2,:,k),ploc(2,:,k)').^2);
        end
        doToss = repmat(logical(eye(size(d2p(:,:,1)))),[1 1 length(d2p(1,1,:))]);
        d2p(doToss) = nan;
        sim.d2p = d2p;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    
%     fprintf('\n\tComputing map distance similarity...')
%     
%     normer = nanmax(nanmax(nanmax(um,[],1),[],2),[],4);
%     normer = repmat(normer,[size(um(:,:,1,:))]);
%     num = um./normer;
%     num = reshape(num,[numel(num(:,:,1,1)) length(num(1,1,:,1)) length(num(1,1,1,:))]);
% 
%     tic
%     map_distance = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
%     for si = 1:length(um(1,1,1,:))
%         tmp1 = num(:,:,si);
%         for sj = si+1:length(um(1,1,1,:))
%             tmp2 = num(:,:,sj);
%             
%             map_distance(si,sj,:) = nanmean(abs(tmp1-tmp2),1);
%         end
%     end     
%     sim.map_distance = map_distance;
%     tmp = toc;
%     fprintf('  %0.3fs.',tmp);
    
end