function mkpv2pv2Vec(pv2pv,blocked,root)

    scalar = 0.2;

    %%%%% Full flow diagram

    figure
    set(gcf,'position',[50 50 length(pv2pv).*100 3.*200])
    for si = 1 %:length(um(1,1,1,:))
        for sj = si+1:length(pv2pv)
            
            avm = [];
            for k = 1:length(pv2pv{si,sj}(1,1,:))
                a = pv2pv{si,sj}(:,:,k);
                [x y] = meshgrid(1:15,1:15);
                x = x(:);
                y = y(:);

                [blah b] = nanmax(a,[],2);
                vm = [x(:) y(:) x(b)-x(:) y(b)-y(:)];
                avm = cat(3,avm,vm);
%                 vm(isnan(blah),:) = [];
            end
            vm = nanmean(avm,3);

            isClosed = reshape(ismember([0:8],blocked{sj})',[3 3])';
            [a b] = find(isClosed);
            
            subplot(2,5,sj-1)
            quiver(vm(:,1),vm(:,2),vm(:,3).*scalar,vm(:,4).*scalar,'off');
            hold on
            for i = 1:length(a(:,1))
                rectangle('position',[(a(i)-1).*5+0.5 (b(i)-1).*5+0.5 5 5])
            end
            axis equal
            axis off
        end
    end
    saveFig(gcf,[root '/PVFlow_Raw'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%% Square-normed flow diagram

    si = 1;
    sj = 11;
    
    avm = [];
    for k = 1:length(pv2pv{si,sj}(1,1,:))
        a = pv2pv{si,sj}(:,:,k);
        [x y] = meshgrid(1:15,1:15);
        x = x(:);
        y = y(:);

        [blah b] = nanmax(a,[],2);
        vm = [x(:) y(:) x(b)-x(:) y(b)-y(:)];
        avm = cat(3,avm,vm);
    end
    refVM = nanmean(avm,3);
    
    figure
    set(gcf,'position',[50 50 3.*200 3.*200])
    for si = 1 %:length(um(1,1,1,:))
        for sj = si+1:length(pv2pv)-1
            
            avm = [];
            for k = 1:length(pv2pv{si,sj}(1,1,:))
                a = pv2pv{si,sj}(:,:,k);
                [x y] = meshgrid(1:15,1:15);
                x = x(:);
                y = y(:);

                [blah b] = nanmax(a,[],2);
                vm = [x(:) y(:) x(b)-x(:) y(b)-y(:)];
                avm = cat(3,avm,vm);
%                 vm(isnan(blah),:) = [];
            end
            vm = nanmean(avm,3);

            isClosed = reshape(ismember([0:8],blocked{sj})',[3 3])';
            [a b] = find(isClosed);
            
            subplot(3,3,sj-1)
            quiver(vm(:,1),vm(:,2),(vm(:,3)-refVM(:,3)).*scalar, ...
                (vm(:,4)-refVM(:,4)).*scalar,'off');
            hold on
            for i = 1:length(a(:,1))
                rectangle('position',[(a(i)-1).*5+0.5 (b(i)-1).*5+0.5 5 5])
            end
            axis equal
            axis off
        end
    end
    saveFig(gcf,[root '/PVFlow_SquareNormalized'],[{'tiff'} {'pdf'} {'jpeg'}])
end

























