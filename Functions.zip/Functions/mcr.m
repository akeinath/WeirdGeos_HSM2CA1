function xc = mcr(varargin)

    forceFull = false;
    isBool = cellfun(@islogical,varargin);
    if any(isBool) && varargin{isBool}
        varargin(isBool) = [];
        forceFull = true;
    end

    if length(varargin)==1
        ms = varargin{1};
    else
        ms = cat(4,varargin{:});
    end

    if size(ms,4)>1 && ~forceFull
        xc = nan(size(ms,3),size(ms,4),size(ms,4));
        for i = 1:size(ms,4)
            for j = i+1:size(ms,4)
                m1 = ms(:,:,:,i);
                m2 = ms(:,:,:,j);

                isBad = all(isnan(m1),3) | all(isnan(m2),3);

                rm1 = reshape(m1,[numel(m1(:,:,1)) size(m1,3)]);
                rm2 = reshape(m2,[numel(m2(:,:,1)) size(m2,3)]);
                rIB = isBad(:);

                rm1(rIB,:) = [];
                rm2(rIB,:) = [];

                tmp = corr(rm1,rm2);
                xc(:,i,j) = tmp(1:length(tmp)+1:end);
            end
        end

        if size(ms,4)==2
            xc = xc(:,1,2);
        end
    else
        m1 = ms(:,:,:,1);
        m2 = ms(:,:,:,end);

        isBad = all(isnan(m1),3) | all(isnan(m2),3);

        rm1 = reshape(m1,[numel(m1(:,:,1)) size(m1,3)]);
        rm2 = reshape(m2,[numel(m2(:,:,1)) size(m2,3)]);
        rIB = isBad(:);

        rm1(rIB,:) = [];
        rm2(rIB,:) = [];

        xc = corr(rm1,rm2);
        
        if ~forceFull
            xc(1:length(xc)+1:end) = nan;
        end
    end
end
