function m = catMat(dim,a,b)
    if isempty(a)
        m = b;
    else
        as = size(a,1:nanmax([ndims(a) ndims(b) dim]));
        bs = size(b,1:nanmax([ndims(a) ndims(b) dim]));


    end
end