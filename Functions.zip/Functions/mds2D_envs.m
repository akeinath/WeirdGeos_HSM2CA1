function eigVal = mds2D(mat,envs,root)

    if nargin < 3
        root = [];
    end

    close all
    drawnow
    
    %%% Multidimensional Scaling 2D
    if iscell(mat)
        tmp = cellfun(@nanmean,mat);
    else
        tmp = nanmean(mat,3);
    end
    tmp = nanmax(tmp,tmp');
    tmp(logical(eye(size(tmp)))) = 1;
    tmp = 1-(tmp).*1;

    [mdssim eigVal] = mdscale(tmp,2);
    
    mdssim = mdssim(:,1:2);

    envLabels = getEnvLabels;
    blah = hsv(8);
    partitionColors = [blah(1:3,:); blah(8,:); 1 1 1; blah(4,:); ...
        blah(7,:); blah(6,:) ; blah(5,:)].*0.9+0.1;

    figure
    set(gcf,'position',[50 50 500 500])
    scatter(mdssim(:,1),mdssim(:,2),30,[0 0 0],'filled')
    shift = nanmax([abs(get(gca,'xlim')) abs(get(gca,'ylim'))]);
    text(shift+mdssim(:,1),mdssim(:,2),envs)
    axis square
    axis equal
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color',[0.5 0.5 0.5])
    plot([0 0],get(gca,'ylim'),'linestyle','--','color',[0.5 0.5 0.5])
    ylabel('MDS Dim 2 (a.u.)');
    xlabel('MDS Dim 1 (a.u.)');

    if ~isempty(root)
        checkP(root);
        saveFig(gcf,[root '_Combined'],[{'pdf'} {'tiff'}]);
    end
    
    %%% Separated
    
    expandedMDS = nan([length(mat(:,1,1)) 2]);
    expandedMDS(~doExclude,:) = mdssim;
    expandedPartitions = nan([length(mat(:,1,1)) 1]);
    expandedPartitions(~doExclude) = partitions;
    
    fillSpace = [[{[0 0 1 1]} {[1 0 1 1]} {[2 0 1 1]}]; ...
        [{[0 1 1 1]} {[1 1 1 1]} {[2 1 1 1]}]; ...
        [{[0 2 1 1]} {[1 2 1 1]} {[2 2 1 1]}]];
    
    figure
    set(gcf,'position',[50 50 200.*11 300])
    for si = 1:11
        subplot(2,11,si)
        tmp = expandedPartitions((si-1).*9+1:(si).*9);
        for i = tmp(~isnan(tmp))'
            hold on
            rectangle('position',fillSpace{i+1},'facecolor',partitionColors(i+1,:),...
                'edgecolor',partitionColors(i+1,:).*0.5 + 0.5)
        end
        set(gca,'xlim',[0 3],'ylim',[0 3],'color',[0 0 0])
        axis square
        axis off
        subplot(2,11,si+11)
        scatter(expandedMDS((si-1).*9+1:(si).*9,1),expandedMDS((si-1).*9+1:(si).*9,2), ...
            50,partitionColors([0:8]+1,:),'filled','marker','s')
        set(gca,'color',[0 0 0],'xlim',lims,'ylim',lims)
        hold on
        plot(get(gca,'xlim'),[0 0],'linestyle','--','color',[0.5 0.5 0.5])
        plot([0 0],get(gca,'ylim'),'linestyle','--','color',[0.5 0.5 0.5])
        ylabel('MDS Dim 2 (a.u.)');
        xlabel('MDS Dim 1 (a.u.)');
        axis square
    end

    if ~isempty(root)
        checkP(root);
        saveFig(gcf,[root '_Separated'],[{'pdf'} {'tiff'}]);
    end
    
    %%% Special
    
    expandedMDS = nan([length(mat(:,1,1)) 2]);
    expandedMDS(~doExclude,:) = mdssim;
    expandedPartitions = nan([length(mat(:,1,1)) 1]);
    expandedPartitions(~doExclude) = partitions;
    
    fillSpace = [[{[0 0 1 1]} {[1 0 1 1]} {[2 0 1 1]}]; ...
        [{[0 1 1 1]} {[1 1 1 1]} {[2 1 1 1]}]; ...
        [{[0 2 1 1]} {[1 2 1 1]} {[2 2 1 1]}]];
    
    ref = nanmean(cat(3,expandedMDS(1:9,:),expandedMDS(end-8:end,:)),3);
    
    figure
    set(gcf,'position',[50 50 200.*9 300])
    for si = 2:10
        subplot(2,9,(si-1))
        tmp = expandedPartitions((si-1).*9+1:(si).*9);
        for i = tmp(~isnan(tmp))'
            hold on
            rectangle('position',fillSpace{i+1},'facecolor',partitionColors(i+1,:),...
                'edgecolor',partitionColors(i+1,:).*0.5 + 0.5)
        end
        set(gca,'xlim',[0 3],'ylim',[0 3],'color',[0 0 0])
        axis square
        axis off
        subplot(2,9,(si-1)+9)
        scatter(ref(:,1),ref(:,2), ...
            15,partitionColors([0:8]+1,:).*0.25 + 0.75,'filled','marker','o')
        set(gca,'color',[0 0 0],'xlim',lims,'ylim',lims)
        hold on
        plot(get(gca,'xlim'),[0 0],'linestyle','--','color',[0.5 0.5 0.5])
        plot([0 0],get(gca,'ylim'),'linestyle','--','color',[0.5 0.5 0.5])
        for k = 1:9
            ts = (si-1).*9+1:(si).*9;
            plot([ref(k,1) expandedMDS(ts(k),1)]', ...
                [ref(k,2) expandedMDS(ts(k),2)]',...
                'color',partitionColors(k,:).*0.5 + 0.5,'linewidth',1);
        end
        scatter(expandedMDS((si-1).*9+1:(si).*9,1),expandedMDS((si-1).*9+1:(si).*9,2), ...
            100,partitionColors([0:8]+1,:),'filled','marker','s')
        ylabel('MDS Dim 2 (a.u.)');
        xlabel('MDS Dim 1 (a.u.)');
        axis square
    end

    if ~isempty(root)
        checkP(root);
        saveFig(gcf,[root '_SquareReferenced'],[{'pdf'} {'tiff'}]);
    end
end