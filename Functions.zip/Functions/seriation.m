function out = seriation(Z,N,cur_index,allOut)
    if cur_index < N
        out = cur_index;
    else
        left = (Z(cur_index-N+1,1));
        right = (Z(cur_index-N+1,2));
        out = [seriation(Z,N,left) seriation(Z,N,right)];
    end
end