function mkOrderPlot(dat,envs)

    if size(dat,3)~=1
        tmp = permute(dat(1,2:11,:),[3 2 1]);
    else
        tmp = dat(:,2:end);
    end
    [a b] = sort(nanmean(tmp),'descend');
    tmp = tmp(:,b);
    labels = envs(2:end);
    labels = labels(b);
    
    figure
    set(gcf,'position',[50 50 250 250]);
    mkBow(tmp,cellfun(@upper,labels,'uni',0))
end