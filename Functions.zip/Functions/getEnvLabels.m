function labels = getEnvLabels()
    labels = [{[-1]} {'Square'}];
    labels = [labels; {[4]} {'O'}];
    labels = [labels; {[0 2 6 8]} {'+'}];
    labels = [labels; {[3 5 6 8]} {'T'}];
    labels = [labels; {[4 5]} {'U'}];
    labels = [labels; {[2 5 8]} {'Rectangle'}];
    labels = [labels; {[3 5]} {'I'}];
    labels = [labels; {[0 4]} {'Bit donut'}];
    labels = [labels; {[0 8]} {'Glenn'}];
    labels = [labels; {[1 2 4 5]} {'L'}];
end