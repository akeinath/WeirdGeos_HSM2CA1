function com = help_getLinCOM(v)

end