function rawTrace = flynerize(rawTrace)

    if isnumeric(rawTrace)
        rawTrace = {rawTrace};
    end
    
    for i = 1:length(rawTrace)
        
        t = rawTrace{i};
        
        isGood = find(diff(t(1,:),[],2)~=0);
        for k = 1:length(t(:,1))
            t(k,isGood(1):isGood(end)) = linterp(isGood,t(k,isGood),isGood(1):isGood(end));
        end

        for k = 1:length(t(:,1))
            dt = [0 conv(diff(t(k,:)),fspecial('gauss',[1 60],5),'same')];

            bsd = nanstd(dt(t(k,:)<0))./sqrt(1-2./pi); %%% Z-score derivative based on estimated from below baseline portion
            zdt = dt./bsd;

            t(k,:) = zdt > 2.5;   
        end
        rawTrace{i} = t;
    end
end