function fix_catLine(p)

    inputFileName = p;
    outputFileName = [p '_fix.txt'];
    
    % Open the input file for reading
    fid = fopen(inputFileName, 'r');
    if fid == -1
        error('Cannot open input file.');
    end
    
    % Read the entire file content
    fileContent = fread(fid, '*char')';
    fclose(fid);
    
    % Initialize variables for processing
    lines = splitlines(fileContent);
    modifiedLines = {};
    
    % Keep track of whether the line should be kept
    keepLine = true;
    
    % Process each line
    for i = 1:length(lines)
        if keepLine
            modifiedLines{end+1} = lines{i};
        else
            
        end
        % Toggle keepLine flag for the next line
        keepLine = ~keepLine;
    end
    
    % Join the lines back into a single string with newlines
    modifiedContent = strjoin(modifiedLines, newline);
    
    % Open the output file for writing
    fid = fopen(outputFileName, 'w');
    if fid == -1
        error('Cannot open output file.');
    end
    
    % Write the modified content to the output file
    fwrite(fid, modifiedContent);
    fclose(fid);
end