function pd = getPathDist(p)
    pd = nansum(sqrt(nansum(diff(p([1 3],:),[],2).^2,1)));
end