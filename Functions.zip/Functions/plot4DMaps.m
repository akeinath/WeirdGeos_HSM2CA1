function plot4DMaps(um,root)
    if nargin < 2 || isempty(root)
        root = [];
    end
    um = permute(um,[2 1 3 4]);        
    numSessions = nansum(~permute(all(all(isnan(um),1),2),[4 3 1 2]),1);
    
    % Pad y-axis
    um = cat(2,um,nan([size(um,1) 2 size(um,3) size(um,4)]));
    
    %%% Normed
    catMaps = nan(length(um(:,1,1,1)),length(um(1,1,1,:)).*length(um(1,:,1,1)),length(um(1,1,:,1)));
    for si = 1:length(um(1,1,1,:))
        for k = 1:length(um(1,1,:,1))
            catMaps(:,(si-1).*length(um(1,:,1,1))+1:(si).*length(um(1,:,1,1)),k) = ...
                um(:,:,k,si); %./nanmax(nanmax(um(:,:,k,si)));
        end
    end
    [a b] = sort(numSessions,'descend');
    catMaps = catMaps(:,:,b(a>nanmax(a).*(2./3))); %sort by number of registered sessions

    doSize = [8 1];
    for gi = 1:floor(length(catMaps(1,1,:))./prod(doSize))
        figure
        set(gcf,'position',[50 50 fliplr(doSize).*[200 20].*4])
        axis tight
        for k = 1:prod(doSize)
            try
                dm = catMaps(:,:,(gi-1).*prod(doSize)+k);
                subplot(doSize(1),doSize(2),k)
                imagesc(dm)
                axis equal
                axis off
                alpha(double(~isnan(dm)))
            end
        end
        if ~isempty(root)
            saveFig(gcf,[root '/Part_' num2str(gi)],[{'pdf'} {'tiff'}])
        else
            pause(1);
        end
        close all
        drawnow;
    end
end