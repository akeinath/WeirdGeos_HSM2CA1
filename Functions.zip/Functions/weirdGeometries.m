function weirdGeometries(paths)
    clc
    close all
    drawnow
    
    pause_thresh = -2;
    envSize = [15 15];
    warning off all
     %% Split by animal
    mouse = [];
    cond = [];
    for i = 1:length(paths)
        ind = find(ismember(paths{i},'/'),2,'last');
        mouse = [mouse; {paths{i}(ind(1)+1:ind(2)-1)}];
        tmp = paths{i}(ind(2)+1:end-4);
        cond = [cond; {tmp(find(ismember(tmp,'_'),1,'last')+1:end)}];
    end
    umouse = unique(mouse);
    
    doConds = [{'0'} {'2'} {'2-3'} {'2-3-10-11'} {'1-7-8-9'} ...
        {'2-11'} {'5-8'} {'1-2-8-9-10'} {'5-6-7'} {'1'} {'1-12'} ...
        {'1-4-9-12'} {'1-2-9-10'} {'1-2-4-9-10-12'} {'1-2-3-9-10-11'} ...
        {'1-2-3-5-6-7'} {'1-2-3'}];
    
    for mi = 1:length(umouse)
        fprintf(['\n\tMouse:  ' umouse{mi} '\n'])
        isM = ismember(mouse,umouse(mi));
        
        sessions = paths(isM);
        
        s = load(sessions{1});
        doAl = help_getAlignmentID(s.alignment,length(sessions),sessions);
        alignMap = s.alignment(doAl).alignmentMap{1};
        
%         mcond = cond(isM);
%         order = [];
%         for k = 1:length(mcond)
%             order = [order; find(ismember(doConds,mcond(k)))];
%         end
%         
%         sessions = sessions(order);
%         alignMap = alignMap(:,order);
        
        root = ['Plots/ContinuousAnalysis/' umouse{mi}];
        am = repmat({[]},[1 length(sessions)]);
        amfr = repmat({[]},[1 length(sessions)]);
        envs = [];
        
%         figure(1)
%         set(gcf,'position',[50 50 1500 225.*ceil(length(sessions))./5])
        for si = 1:length(sessions)
            s = load(sessions{si},'processed','exclude');

            gT = s.processed.trace;
            if isfield(s.processed,'exclude')
                gT = gT(s.processed.exclude.SFPs,:);
            end
            
            unv = [0 sqrt(nansum(diff(s.processed.p,[],2).^2,1))].*30;
            unv(unv > 50) = nan;
            unv = interpNaNs(unv')';
            v = conv(unv,fspecial('gauss',[1 200],15),'same');
            amfr{si} = nanmean(gT(:,v>=pause_thresh),2);

            [m os unm] = mkTraceMaps(s.processed.p,gT,v>=pause_thresh,envSize);
            am{si} = m;
            
%             % Plot Path
%             subplot(ceil(length(sessions)./5),5,si)
%             plot(s.processed.p(1,1:10:end),s.processed.p(2,1:10:end),'color','k','linestyle','-')
%             axis equal
%             axis off
            
            envs = [envs; {lower(sessions{si}(find(ismember(sessions{si},'_'),1,'last')+1:end-4))}];
        end
        fprintf(['Done.\n'])

        umfr = nan([length(alignMap(:,1)) length(sessions)]);
        um = nan([envSize length(alignMap(:,1)) length(sessions)]);
        for si = 1:length(sessions)
            umfr(alignMap(:,si)~=0,si) = amfr{si}(alignMap(alignMap(:,si)~=0,si));
            um(:,:,alignMap(:,si)~=0,si) = am{si}(:,:,alignMap(alignMap(:,si)~=0,si));
        end
        
        numPatch = 9;
        catPVPat = nan(numPatch.*length(sessions),numPatch.*length(sessions));
        catIPat = nan(numPatch.*length(sessions),numPatch.*length(sessions),length(um(1,1,:,1)));
        wholeMapSim = nan(length(sessions),length(sessions),length(um(1,1,:,1)));
        
        iter = 0;
        strLength = 0;
        fprintf(['\t\tComputing pairwise map comparisons: '])
        for si = 1:length(sessions)
            for sj = si:length(sessions)
                
                iter = iter+1;
                fprintf(repmat('\b',[1 strLength]));
                str = sprintf([ num2str(iter) ' of ' num2str(nchoosek(length(sessions),2))]);
                fprintf(str);
                strLength = length(str);
                
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
            
                wholeMapSim(si,sj,:) = xcorr3transform(tmp1,tmp2,[0 0 0]);
                
                [pv id ic] = gridRSA(tmp1,tmp2);
                
                catPVPat((si-1).*numPatch+1:(si).*numPatch, ...
                    (sj-1).*numPatch+1:(sj).*numPatch) = pv;
                
                catIPat((si-1).*numPatch+1:(si).*numPatch, ...
                    (sj-1).*numPatch+1:(sj).*numPatch,:) = id;
                
%                 figure(1)
%                 set(gcf,'position',[50 50 250.*length(sessions) length(sessions).*250])
%                 subplot(length(sessions),length(sessions),(si-1).*length(sessions)+sj)
%                 pvWarp(tmp1,tmp2);
%                 axis square

            end
        end
        
        
        tmp = squarify(catPVPat);
        isBad = ~any(~isnan(tmp));
        tmp(1:length(tmp)+1:end) = 1;
        tmp(isBad,isBad) = nan;
        weird_mds2D((tmp.*0.5)+0.5,envs,[root '/PV_Patch_MDS_2D']);
        
        figure
        set(gcf,'position',[50 50 400 400])
        imagesc(tmp)
        alpha(double(~isnan(tmp)))
        colorbar
        axis off
        saveFig(gcf,[root '/PV_Patch_RSA'],[{'pdf'} {'tiff'}])
        
        
        weird_mds2D(squarify(nanmedian(catIPat,3)),envs,[root '/Cellwise_Patch_MDS_2D']);
        
        figure
        set(gcf,'position',[50 50 400 400])
        tmp = squarify(nanmedian(catIPat,3));
        imagesc(tmp)
        alpha(double(~isnan(tmp)))
        colorbar
        axis off
        saveFig(gcf,[root '/Cellwise_Patch_RSA'],[{'pdf'} {'tiff'}])
    end    
end