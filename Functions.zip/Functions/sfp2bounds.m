function allBounds = sfp2bounds(tSFP)
    allBounds = repmat({[]},[size(tSFP,3),size(tSFP,4)]);
    for k = 1:size(tSFP,3)
        for si = 1:size(tSFP,4)
            bw = tSFP(:,:,k,si)>nanmax(nanmax(tSFP(:,:,k,si))).*0.2;
            tmp = bwboundaries(bw);
            if ~isempty(tmp)
                allBounds{k,si} = tmp;
            end
        end
    end
end