function [mapsOut mfrsOut spmOut smOut ordersOut] = getMouseMaps()
    
    paths = getFilePaths('MatlabData/Mouse_CA1_Agg','.mat');
    m = [];
    envs = [];
    mfrs = [];
    spm = [];
    sm = [];
    for p = paths'
        s = load(p{1},'maps','envs','trace','si','shc');
        
        tmp = cellfun(@nanmean,s.trace,repmat({2},size(s.trace)),'uni',0);
        mfr = cat(2,tmp{:});
        
        if isempty(m)
            m = {permute(s.maps.unsmoothed,[1 2 3 4])};
            spm = {permute(s.maps.splitHalf,[1 2 3 4 5])};
            sm = {s.maps.sampling};

            envs = {s.envs};
            mfrs = {mfr};
        else
            m = cat(2,m,{permute(s.maps.unsmoothed,[1 2 3 4])});
            spm = cat(2,spm,{permute(s.maps.splitHalf,[1 2 3 4 5])});
            sm = cat(2,sm,{permute(s.maps.sampling,[1 2 3 4])});
            envs = cat(2,envs,{s.envs});
            mfrs = cat(2,mfrs,{mfr});

        end
    end
    
    mfrsOut = repmat({[]},[3 length(m)]);
    mapsOut = repmat({[]},[3 length(m)]);
    spmOut = repmat({[]},[3 length(m)]);
    smOut = repmat({[]},[3 length(m)]);
    ordersOut = repmat({[]},[3 length(m)]);
    for i = 1:length(m)
        for j = 1:floor((size(m{i},4)-1)./10)
            doS = (j-1).*10+2:(j).*10+1;
            tm = m{i}(:,:,:,doS); % Exclude first square from each sequence
            tspm = spm{i}(:,:,:,doS,:);
            tmfr = mfrs{i}(:,doS);
            tsm = sm{i}(:,:,doS);

            [a b] = unique(envs{i}(doS)); % order maps by canonical order
            canonOrder = b([1:7 9:10 8]);
            tm = tm(:,:,:,canonOrder);
            tspm = tspm(:,:,:,canonOrder,:);
            tmfr = tmfr(:,canonOrder);
            tsm = tsm(:,:,canonOrder);

            mapsOut{j,i} = tm;
            ordersOut{j,i} = canonOrder;

            spmOut{j,i} = tspm;
            mfrsOut{j,i} = tmfr;
            smOut{j,i} = tsm;

        end
    end
end