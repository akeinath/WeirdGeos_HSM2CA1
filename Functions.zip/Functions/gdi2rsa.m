function gdi2rsa(root,gdi,rsm)

    figure
    set(gcf,'position',[50 50 300.*length(2) 250])
    subplot(1,2,1)
    imagesc(nanmean(gdi,3))
    alpha(double(~isnan(nanmean(gdi,3))))
    colorbar('location','southoutside');
    colormap inferno
    axis equal
    axis off
    subplot(1,2,2)
    imagesc(nanmean(rsm,3))
    alpha(double(~isnan(nanmean(rsm,3))))
    colorbar('location','southoutside');
    colormap inferno
    axis equal
    axis off
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/GDIvsRSMs_' slind(root,[1 0])],[{'tiff'} {'pdf'}])
    drawnow

    a = nanmean(gdi,3);
    b = nanmean(rsm,3);

    outP = ['Stats/' root '_GDIvsRSM.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    [rval pval] = corr(getTri(a),getTri(b));
    fprintf(fid,sprintf('\nDistortion Index (-1) vs Replace Map Similarity (Pearson): r = %0.3f, p = %0.3e',[rval pval]));
    [rval pval] = corr(getTri(a),getTri(b),'type','kendall');
    fprintf(fid,sprintf('\nDistortion Index (-1) vs Replace Map Similarity (Kendall): r = %0.3f, p = %0.3e',[rval pval]));
    fclose(fid);
end