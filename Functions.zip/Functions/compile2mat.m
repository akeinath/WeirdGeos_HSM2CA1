function compile2mat(doAnimal)
    if nargin < 1 || isempty(doAnimal)
        doAnimal = 'QLAK-CA1-08';
    end
    clc

    warning off all
    ap = getFilePaths(['Processed/' doAnimal],'ms.mat');

    for p = ap'

        slind = find(ismember(p{1},'/\'));

        fprintf(['\n\t\t' p{1}])
        
        s = load(p{1});
        
        tmpS = struct();
        tmpS.calcium.meanFrame = s.ms.meanFrame;
        tmpS.calcium.SFPs = s.ms.SFPs;
        tmpS.calcium.FiltTraces = s.ms.FiltTraces;
%         tmpS.calcium.deconvTraces = s.ms.deconvolvedSig;
        
        tmpS.calcium.ts = xlsread([p{1}(1:slind(3)-1) '/ms_timeStamps.csv']);
        
        try
            tmpS.pos.p = xlsread([p{1}(1:slind(3)-1) '/clean_poses.csv']);
            tmpS.pos.ts = xlsread([p{1}(1:slind(3)-1) '/behav_timeStamps.csv']);
        catch
            fprintf(['\n\t\t\t***** No DLC for:  ' p{1}]);
            continue
        end
        
        outP = ['ForRegistration/' doAnimal '/' p{1}(slind(1)+1:slind(2)-1)];
        checkP(outP);
        save(outP,'-struct','tmpS','-v7.3');
    end
end