function doRSA(across,root)
    
    doS = [10:90];

    correlationType = 'kendall';

    doGammas = [0.999 0.95 0.90];
    doAlphas = [(50./30).*10.^(-1) (50./30).*10.^(-2) (50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5) (50./30).*10.^(-6)];
    doTimestep = [1 150];

    doChoices = combvec(doGammas,doAlphas,doTimestep);
    
    srLabels = [];
    for k = 1:length(doChoices(1,:))
        srLabels = [srLabels; {['g=' sprintf('%0.3f',doChoices(1,k)) ', a=' sprintf('%0.7f',doChoices(2,k)) ', ts=' sprintf('%i',doChoices(3,k))]}];
    end


    %%%%%%%%%% Overall %%%%%%%%%%%%%%
    measures = fieldnames(across.rsa);
    for mi = 1 %:length(measures)
        ref = across.rsa.(measures{mi}).rsm.actual(doS,doS,:);
    
        noiseCeil = nan(size(ref,3),2);
        for i = 1:size(ref,3)
            a = getTri(ref(:,:,i));
            b = getTri(nanmean(ref(:,:,[1:i-1 i+1:end]),3));
            c = getTri(nanmean(ref,3));
            lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
            hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
            noiseCeil(i,:) = [lo hi];
        end
        noiseCeil = nanmean(noiseCeil);
    
        doComps = fieldnames(across.rsa.(measures{mi}).rsm);
        doComps(ismember(doComps,{'actual'})) = [];
        doComps = sort(doComps);
        for i = length(doComps):-1:1
            if isempty(across.rsa.(measures{mi}).rsm.(doComps{i}))
                across.rsa.(measures{mi}).rsm = rmfield(across.rsa.(measures{mi}).rsm,(doComps{i}));
                doComps(i) = [];
            end
        end
        
        fits = nan(length(doComps),1);
        for i = 1:length(doComps)
            a = getTri(nanmean(across.rsa.(measures{mi}).rsm.(doComps{i})(doS,doS,:),3));
            b = getTri(nanmean(ref,3));
            fits(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
        end
    

        figure(1)
        set(gcf,'position',[50 50 40.*length(doComps)*length(measures) 150])
        subplot(1,length(measures),mi)
        set(gca,'ylim',[-0.05 1]);
        mkBar(fits',doComps,[0 0 0])
        hold on
        plot(get(gca,'xlim'),[0 0],'color','k','linestyle','-','linewidth',1);
        a = get(gca,'xlim');
        patch([a(1) a(1) a(2) a(2)],[noiseCeil fliplr(noiseCeil)], ...
            [0 0 0],'facealpha',0.2,'edgecolor','none','facecolor',[0 0 0]);
        title(measures{mi})
    end
    saveFig(gcf,[root '/ModelComparison/TreatSequencesSeparate'],[{'tiff'} {'pdf'}]);
    
    %%%%%%%%%%%%%%% Subject wise%%%%%%%%%%%%%%%%
    
    for mi = 1:length(measures)
        um = unique(across.rsa.(measures{mi}).label);
        aaRSMs = [];
        aRSMs = [];
        compRSMs = repmat({[]},[1 length(doComps)]);
        compRSMs3 = repmat({[]},[1 length(doComps)]);
        for mouseI = 1:length(um)
            isM = ismember(across.rsa.(measures{mi}).label,um(mouseI));
            ref = across.rsa.(measures{mi}).rsm.actual(doS,doS,isM);
            aRSMs = cat(3,aRSMs,nanmean(ref,3));

            noiseCeil = nan(size(ref,3),2);
            for i = 1:size(ref,3)
                a = getTri(ref(:,:,i));
                b = getTri(nanmean(ref(:,:,[1:i-1 i+1:end]),3));
                c = getTri(nanmean(ref,3));
                lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
                hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
                noiseCeil(i,:) = [lo hi];
            end
            noiseCeil = nanmean(noiseCeil);
        
            aaRSMs = cat(2,aaRSMs,getTri(nanmean(ref,3)));

            doComps = fieldnames(across.rsa.(measures{mi}).rsm);
            doComps(ismember(doComps,{'actual'})) = [];
            doComps = sort(doComps);
            exNum = cellfun(@getStr2Num,doComps,repmat({'bvc_sr_'},[length(doComps) 1]),'uni',0);
            exNum = cat(1,exNum{:});
            exNum(isnan(exNum)) = -inf;
            [exNum b] = sort(exNum);
            doComps = doComps(b);
            exNum(exNum==-inf) = nan;
            compLabels = doComps;
            for i = 1:length(exNum)
                if ~isnan(exNum(i))
                    compLabels(i) = srLabels(exNum(i));
                end
            end


            for i = length(doComps):-1:1
                if isempty(across.rsa.(measures{mi}).rsm.(doComps{i}))
                    across.rsa.(measures{mi}).rsm = rmfield(across.rsa.(measures{mi}).rsm,(doComps{i}));
                    doComps(i) = [];
                end
            end
            
            fits = nan(length(doComps),1);
            for i = 1:length(doComps)
                compRSMs3{i} = cat(3,compRSMs3{i},nanmean(across.rsa.(measures{mi}).rsm.(doComps{i})(doS,doS,isM),3));
                a = getTri(nanmean(across.rsa.(measures{mi}).rsm.(doComps{i})(doS,doS,isM),3));
                b = getTri(nanmean(ref,3));
                compRSMs{i} = cat(2,compRSMs{i},a);
                fits(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
            end
        
    
            figure(2)
            set(gcf,'position',[50 50 40.*length(doComps)*length(um) 150*length(measures)])
            subplot(length(measures),length(um),(mi-1).*length(um)+mouseI)
            set(gca,'ylim',[-0.05 1]);
            mkBar(fits',compLabels,[0 0 0])
            hold on
            plot(get(gca,'xlim'),[0 0],'color','k','linestyle','-','linewidth',1);
            a = get(gca,'xlim');
            patch([a(1) a(1) a(2) a(2)],[noiseCeil fliplr(noiseCeil)], ...
                [0 0 0],'facealpha',0.2,'edgecolor','none','facecolor',[0 0 0]);
            title(measures{mi})
        end

        %%%%% Compare to average within animals first

        ref = aaRSMs;
        noiseCeil = nan(size(ref,3),2);
        for i = 1:length(aaRSMs(1,:))
            a = ref(:,i);
            b = nanmean(ref(:,[1:i-1 i+1:end]),2);
            c = nanmean(ref,2);
            lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
            hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
            noiseCeil(i,:) = [lo hi];
        end
        noiseCeil = nanmean(noiseCeil);
    
%         compRSMs3 = [{aRSMs} compRSMs3];
%         figure(5)
%         set(gcf,'position',[50 50 300.*(length(doComps)+1) 300])
%         for qi = 1:length(compRSMs3)
%             subplot(1,length(doComps)+1,qi)
%             tmp = 1-squarify(nanmean(compRSMs3{qi},3));
%             isBad = all(isnan(tmp));
%             tmp(:,isBad) = [];
%             tmp(isBad,:) = [];
%             imagesc(tmp)
%             tmp(1:length(tmp)+1:end) = nan;
%             alpha(double(~isnan(tmp)))
%             colormap inferno
%             axis equal
%             axis square
%             axis off
%         end
%         saveFig(gcf,[root '/ModelComparison/ModelRSMs_' measures{mi}],[{'tiff'} {'pdf'}]);

        fits = nan(length(doComps),1);
        for i = 1:length(doComps)
            a = nanmean(compRSMs{i},2);
            b = nanmean(ref,2);
            fits(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
        end
    

        figure(4)
        set(gcf,'position',[50 50 40.*length(doComps)*length(measures) 150])
        subplot(1,length(measures),mi)
        set(gca,'ylim',[-0.05 0.8]);
        mkBar(fits',compLabels,[0 0 0])
        hold on
        plot(get(gca,'xlim'),[0 0],'color','k','linestyle','-','linewidth',1);
        a = get(gca,'xlim');
        patch([a(1) a(1) a(2) a(2)],[noiseCeil fliplr(noiseCeil)], ...
            [0 0 0],'facealpha',0.2,'edgecolor','none','facecolor',[0 0 0]);
        title(measures{mi})
        
        %%%% Compare animals to one another

        figure(3)
        set(gcf,'position',[50 50 200.*length(measures) 200])
        subplot(1,length(measures),mi)
        aaRSMs(~any(~isnan(aaRSMs),2),:) = [];
        tmp = corr(aaRSMs(:,[1 6 7 5 2 3 4]),'type',correlationType);
        tmp(1:length(tmp)+1:end) = nan;
        imagesc(tmp);
        alpha(double(~isnan(tmp)));
        colorbar
        colormap magma
        axis equal
        axis square
        axis off
        caxis([0 1])
    end

    figure(4)
    saveFig(gcf,[root '/ModelComparison/AverageWithinAnimalFirst'],[{'tiff'} {'pdf'}]);

    figure(3)
    saveFig(gcf,[root '/ModelComparison/AnimalXAnimal'],[{'tiff'} {'pdf'}]);

    figure(2)
    saveFig(gcf,[root '/ModelComparison/AnimalwiseComparisons'],[{'tiff'} {'pdf'}]);

    
end
