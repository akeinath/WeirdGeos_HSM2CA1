function rsa_partition_xThresholding(hRSM,allHumanMaps,allMouseMaps)
    % impact of adjusting predicted maps after prediction


    nsims = 100;
    doScale = [-1:0.01:0.4];
    asFits = nan(length(doScale),nsims);
    asJNC = nan(length(doScale),2,nsims);

    predictedHumanMaps = predictMaps(allHumanMaps(end),allMouseMaps(end),[],[]);
    for scaleI = 1:length(doScale)
        tm = predictedHumanMaps{1};
        isBad = tm < doScale(scaleI);
        tm(isBad) = nan;
        tm = mmnorm(tm);
        tm(isBad) = 0;

%         tm = mmnorm(tm);
%         tm(tm< doScale(scaleI)) = nan;
%         tm = mmnorm(tm);
        [~, pRSM] = m2rsm(tm,-1);
        [asFits(scaleI,:) b] = help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),nsims);
        asJNC(scaleI,:,:) = b';
    end

    eyefit = help_shRSA(hRSM{end},repmat(eye(9),[10 10 size(hRSM{end},3)]), ...
        size(hRSM{end},3),1);

    figure()
    set(gcf,'position',[50 50 450 225])
    subplot(1,2,1)
    mkWhisker(asFits',doScale,cool(length(doScale)))
    plot(get(gca,'xlim'),ones(1,2).*eyefit,'linestyle','--','color',[0.8 0.8 0.8]);
    set(gca,'xlim',[-1 length(doScale)+1],'ylim',[0 1])
    ylabel('Kendalls Tau')
    xlabel('Predicted Map Threshold')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    subplot(1,2,2)
    doRange = (75:127);
    doC = cool(length(doScale));
    mkWhisker(asFits(doRange,:)',doScale(doRange),doC(doRange,:))
    set(gca,'ylim',[0.65 0.85])
    ylabel('Kendalls Tau')
    xlabel('Predicted Map Threshold')
    saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_ByPredThresholding',[{'tiff'} {'pdf'}])
    drawnow
end