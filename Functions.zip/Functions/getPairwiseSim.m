function sim = getPairwiseSim(um,whiteNoise,varargin)

    if nargin < 2 || isempty(whiteNoise)
        whiteNoise = 0;
    end

    if isstruct(um)
        tmp = um;
        um = tmp.maps;
        try
            trace = tmp.trace;
        end
        pos = tmp.p;
    elseif ndims(um) == 2
        trace = um; % DOESNT WORK, COULD NEED POSITION DATA
    else
        % input is indeed a map
        um = um+rand(size(um)).*whiteNoise;
    end

    if nargin<2 || isempty(varargin)
        varargin = {'pearson'};
    end

    if iscell(varargin{1})
        varargin = varargin{1};
    end

    if ismember({'pfr'},varargin)
        %%% peak firing rate differences
        fprintf('\n\tComputing peak firing rate differences...')
        tic
        apfr = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        rpfr = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                tmp = abs(permute(nanmax(nanmax(tmp1,[],1),[],2)-nanmax(nanmax(tmp2,[],1),[],2),[3 1 2]));
                apfr(si,sj,:) = tmp;
                rpfr(si,sj,:) = tmp./permute(nanmax(nanmax(nanmax(tmp1,[],1),[],2), ...
                    nanmax(nanmax(tmp2,[],1),[],2)),[3 1 2]);
            end
        end     
        sim.pfr.abs = apfr;
        sim.pfr.rel = rpfr;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'emd_scaled'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing earth movers distance (scaled) map similarity...')
        tic
        [x y] = meshgrid(1:size(um,1),1:size(um,2));
        d2e = sqrt(bsxfun(@minus,x(:),x(:)').^2 + bsxfun(@minus,y(:),y(:)').^2);
        emds = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                tmp1 = mnorm(tmp1);
                tmp2 = mnorm(tmp2);
                
                rt1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                rt2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                
%                 emds(si,sj,:) = nanmean(abs(rt1-rt2));

                drt1 = bsxfun(@minus,permute(rt1,[1 3 2]),permute(rt1,[3 1 2]));
                drt2 = bsxfun(@minus,permute(rt2,[1 3 2]),permute(rt2,[3 1 2]));
                
                tmp = bsxfun(@times,abs(drt1-drt2),d2e);
                tmp = reshape(tmp,[numel(tmp(:,:,1)) length(tmp(1,1,:))]);

                emds(si,sj,:) = nanmean(tmp);
                
            end
            
            figure(1)
            imagesc(squarify(nanmean(emds,3)))
            drawnow
            
        end     
        sim.emds = emds;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'pearson'},varargin)
        %%% Pearson correlation similarity
        pearson = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        rum = permute(reshape(um,[numel(um(:,:,1,1)) size(um,[3 4])]),[1 2 3]);
        for i = 1:size(rum,3)
            for j = i+1:size(rum,3)
                isBad = all(isnan(rum(:,:,i)),2) | all(isnan(rum(:,:,j)),2);
                xc = corr(rum(~isBad,:,i),rum(~isBad,:,j));
                pearson(i,j,:) = xc(logical(eye(size(xc))));
            end
        end
        sim.pearson = pearson;
    end
    
    if ismember({'c2c_pearson'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pearsons map similarity across cells...')
        tic
        c2cpearson = nan([length(um(1,1,:,1)) length(um(1,1,:,1)) length(um(1,1,1,:)) length(um(1,1,1,:))]);
        for si = 1:length(um(1,1,1,:))
            for sj = 1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                rtmp1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                rtmp2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                
                isBad = all(isnan(rtmp1),2) | all(isnan(rtmp2),2);
                rtmp1(isBad,:) = [];
                rtmp2(isBad,:) = [];
                
                mcr(um(:,:,:,si),um(:,:,:,sj),true);
                
                c2cpearson(:,:,si,sj) = corr(rtmp1,rtmp2);
            end
        end     
        sim.c2c.pearson = c2cpearson;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'pv'},varargin)
        %%% Pearson correlation similarity
        fprintf('\n\tComputing population vector map similarity...')
        tic
        pv = nan([length(um(1,1,1,:)) length(um(1,1,1,:))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);
                
                tmp = pvxcorr(tmp1,tmp2,[1 1]);
                pv(si,sj) = tmp(2,2);
            end
        end     
        sim.pv = pv;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    if ismember({'partitioned_pmap'},varargin)
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pop vec similarity with 3 partitions...')
        tic
        pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for i1 = 1:3
                    for j1 = 1:3
                        for i2 = 1:3
                            for j2 = 1:3
                                tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                                tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);

                                val = abs(tmp1-tmp2);
                                val(tmp1==0&tmp2==0) = nan;
                                
                                pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2,:) = val;
                            end
                        end
                    end
                end
            end
        end     
        sim.partitioned.pmap = 1-pp./4;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'partitioned_pv'},varargin)
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing pop vec similarity with 3 partitions...')
        tic
        pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 1]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for i1 = 1:3
                    for j1 = 1:3
                        for i2 = 1:3
                            for j2 = 1:3
                                tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                                tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);
                                
                                isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);
                                
                                if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
                                    continue
                                end
                                
                                a = tmp1(repmat(isGoodPix,[1 1 length(tmp1(1,1,:))]));
                                b = tmp2(repmat(isGoodPix,[1 1 length(tmp2(1,1,:))]));
                                doInclude = ~isnan(a) & ~isnan(b);
                                
                                pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2) = ...
                                    corr(a(doInclude),b(doInclude));
                            end
                        end
                    end
                end
            end
        end     
        sim.partitioned.pv = pp;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'partitioned_c2c'},varargin)
        
        fprintf('\n\tComputing trace coactivity similarity with 3 partitions...')
        tic
    
        smoothing = -1;

        if smoothing > 1
            for i = 1:length(trace)
                trace{i} = bin(trace{i},smoothing);
            end
        end
        
        goodS = find(~cellfun(@isempty,trace));
        allPairs = nan([nansum(nansum(triu(true(length(trace{goodS(1)}(:,1))),1))) length(trace).*9]);
        axc = nan(length(trace{goodS(1)}(:,1)),length(trace{goodS(1)}(:,1)),length(trace).*9);
    
        for si = find(~cellfun(@isempty,trace)) % 1:length(trace)
            for i = 1:3
                for j = 1:3
                    isPart = floor(pos{si}(1,:)./25)+1 == i & ...
                        floor(pos{si}(2,:)./25)+1 == j;
    
                    if nansum(isPart) > 600 % don't count partitions with very few (20 sec) frames
                        tmp = corr(trace{si}(:,isPart)');
                        axc(:,:,(si-1).*9 + (i-1).*3 + j) = tmp;
                        allPairs(:,(si-1).*9 + (i-1).*3 + j) = tmp(triu(true(length(trace{goodS(1)}(:,1))),1));
                    end
                end
            end
        end
        
        minclude = inf;
        for i = 1:length(allPairs(1,:))
            ref = allPairs(:,i);
            for j = i+1:length(allPairs(1,:))
                cr = allPairs(:,j);
                isGood = ~isnan(ref)&~isnan(cr);
                if nansum(isGood)~=0
                    minclude = nanmin(nansum(isGood),minclude);
                end
            end
        end
        
        c2cTraceRSM = nan(length(allPairs(1,:)));
        for i = 1:length(allPairs(1,:))
            ref = allPairs(:,i);
            for j = i+1:length(allPairs(1,:))
                cr = allPairs(:,j);
                isGood = ~isnan(ref)&~isnan(cr);
                if nansum(isGood) == 0
                    continue
                end
                
                inds = find(isGood);
                inds = inds(randperm(length(inds)));
                inds = inds(1:minclude);
                isGood = false(size(isGood));
                isGood(inds) = true;
                
                [rval pval] = corr(ref(isGood),cr(isGood),'type','pearson'); %spearman
                c2cTraceRSM(i,j) = rval;
            end
        end
        
        sim.partitioned.c2c = c2cTraceRSM;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    if ismember({'partitioned_mfr'},varargin)
        
        fprintf('\n\tComputing mean firing similarity with 3 partitions...')
        tic
    
        goodS = find(~cellfun(@isempty,trace));
        aMFR = nan([length(trace{goodS(1)}(:,1)) length(trace).*9]);
        for si = goodS % 1:length(trace)
            isActive = ~all(isnan(trace{si}),2);
            for i = 1:3
                for j = 1:3
                    isPart = floor(pos{si}(1,:)./25)+1 == i & ...
                        floor(pos{si}(2,:)./25)+1 == j;
    
                    if nansum(isPart) > 600 % don't count partitions with very few (20 sec) frames
                        aMFR(:,(si-1).*9 + (i-1).*3 + j) = nanmean(trace{si}(:,isPart),2);
                        aMFR(isnan(aMFR(:,(si-1).*9 + (i-1).*3 + j)) & ...
                            isActive,(si-1).*9 + (i-1).*3 + j) = 0;
                    end
                end
            end
        end
        
        a = abs(bsxfun(@minus,permute(aMFR,[3 2 1]),permute(aMFR,[2 3 1])));
        normer = repmat(permute(nanmax(aMFR,[],2),[3 2 1]),size(a(:,:,1)));

        sim.partitioned.mfr = a./normer;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    if ismember({'partitioned_kl'},varargin)
        partSize = ceil(length(um(:,1,1,1))./3);
        %%% Pearson correlation similarity
        fprintf('\n\tComputing KL divergence map similarity with 3 partitions...')
        tic
        pp2 = nan([9 9 length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si:length(um(1,1,1,:))
                for qi = 1:9
                    i1 = floor((qi-1)./3)+1;
                    j1 = mod((qi-1),3)+1;
                    
                    tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                    rt1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                    for qj = 1:9
                        i2 = floor((qj-1)./3)+1;
                        j2 = mod((qj-1),3)+1;
                        
                        tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);

                        isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);

                        if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
                            continue
                        end
                        rt2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                        
                        doInclude = ~all(isnan(rt1),2) & ~all(isnan(rt2),2);
                        
                        pp2(qi,qj,si,sj,:) = nansum((rt1(doInclude,:)-rt2(doInclude,:)).^2,1).^(1./2);
                    end
                end
            end
        end 
        ts = size(pp2);
        sim.partitioned.kl = reshape(permute(pp2,[1 3 2 4 5]), ...
            [prod(ts([1 3])) prod(ts([1 3])) length(pp2(1,1,1,1,:))]); % Compute 1 - r for distance matrix
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end


    if ismember({'partitioned_pearson'},varargin)

        pid = [ones(5) ones(5).*2 ones(5).*3; ones(5).*4 ones(5).*5 ones(5).*6; ...
            ones(5).*7 ones(5).*8 ones(5).*9];
        pid = pid(:);
        [opid reorderPid] = sort(pid);

        rum = reshape(um,[numel(um(:,:,1,1)) size(um,[3 4])]);
        rum = rum(reorderPid,:,:);
        rum = permute(rum,[1 3 2]);
        rrum = reshape(rum,[size(rum,1)/9 9.*size(rum,2) size(rum,3)]);
        tmp = nan(size(rrum,[2 2 3]));

        for k = 1:size(rrum,3)
            tmp(:,:,k) = corr(rrum(:,:,k));
        end

        sim.partitioned.pearson = tmp;
    end

    if ismember({'pixel_pv'},varargin)

        vals = nan(prod(size(um,[1 2 4])));
        for i = 1:size(um,4)
            for j = i:size(um,4)
                a = um(:,:,:,i);
                b = um(:,:,:,j);
                isGood = permute(~all(all(isnan(a),1),2)&~all(all(isnan(b),1),2),[3 1 2]);

                ra = reshape(a(:,:,isGood),[numel(a(:,:,1)) nansum(isGood)]);
                rb = reshape(b(:,:,isGood),[numel(b(:,:,1)) nansum(isGood)]);
                vals((i-1).*numel(um(:,:,1,1))+1:(i).*numel(um(:,:,1,1)), ...
                    (j-1).*numel(um(:,:,1,1))+1:(j).*numel(um(:,:,1,1))) = corr(ra',rb');
            end
        end
        vals = squarify(vals);
        sim.pixel.pv = vals;
    end

    if ismember({'pixel_pearson'},varargin)

        patchSize = 4; % +/- patchSize./2

        isGood = [ones(patchSize+1,patchSize+1) zeros(patchSize+1,size(um,1)-(patchSize+1)); ...
            zeros(size(um,1)-(patchSize+1),size(um,1))];
        isGood = repmat(isGood,[1 1 (size(um,1)-patchSize).^2]);
        shiftVec = combvec(1:(size(um,1)-patchSize),1:(size(um,1)-patchSize));
        for k = 1:size(isGood,3)
            isGood(:,:,k) = circshift(isGood(:,:,k),[shiftVec(1,k) shiftVec(2,k)]-1);
        end
        isGood = reshape(isGood,[numel(isGood(:,:,1,1)) size(isGood,[3])]);
        rum = reshape(um,[numel(um(:,:,1,1)) size(um,[3 4])]);
        rum = permute(rum,[1 3 2]);

        num = nan([(patchSize+1).^2,size(um,[4 3]),(size(um,1)-patchSize).^2]);
        for i = 1:size(isGood,2)
            num(:,:,:,i) = rum(find(isGood(:,i)),:,:);
        end
        num = permute(num,[1 4 2 3]);
        num = reshape(num,[size(num,[1]) prod(size(num,[2 3])) size(num,[4])]);

        vals = nan(size(num,2),size(num,2),size(num,3));
        for k = 1:size(num,3)
            vals(:,:,k) = corr(num(:,:,k));
        end

        sim.pixel.pearson = vals;
    end
    
%     if ismember({'partitioned_pearson'},varargin)
%         partSize = ceil(length(um(:,1,1,1))./3);
%         %%% Pearson correlation similarity
%         fprintf('\n\tComputing pearsons map similarity with 3 partitions...')
%         tic
%         pp = nan([length(um(1,1,1,:)).*9 length(um(1,1,1,:)).*9 length(um(1,1,:,1))]);
%         for si = 1:length(um(1,1,1,:))
%             for sj = si:length(um(1,1,1,:))
%                 for i1 = 1:3
%                     for j1 = 1:3
%                         for i2 = 1:3
%                             for j2 = 1:3
%                                 tmp1 = um((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
%                                 tmp2 = um((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);
%                                 
%                                 isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);
%                                 
%                                 if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
%                                     continue
%                                 end
%                                 
%                                 pp((si-1).*9 + ((j1-1).*3) + i1,(sj-1).*9 + ((j2-1).*3) + i2,:) = ...
%                                     xcorr3transform(tmp1,tmp2,[0 0 0]);
%                             end
%                         end
%                     end
%                 end
%             end
%         end     
%         sim.partitioned.pearson = pp;
%         tmp = toc;
%         fprintf('  %0.3fs.',tmp);
%     end
    
    if ismember({'partitioned_pfr'},varargin)
        
        num = um; %num = maxnorm(um);
        
        partSize = ceil(length(num(:,1,1,1))./3);
        fprintf('\n\tComputing pfr similarity with 3 partitions...')
        tic
        pp2 = nan([9 9 length(num(1,1,1,:)) length(num(1,1,1,:)) length(num(1,1,:,1))]);
        for si = 1:length(num(1,1,1,:))
            for sj = si:length(num(1,1,1,:))
                for qi = 1:9
                    i1 = floor((qi-1)./3)+1;
                    j1 = mod((qi-1),3)+1;
                    
                    tmp1 = num((i1-1).*partSize+1:(i1).*partSize,(j1-1).*partSize+1:(j1).*partSize,:,si);
                    rt1 = reshape(tmp1,[numel(tmp1(:,:,1)) length(tmp1(1,1,:))]);
                    for qj = 1:9
                        i2 = floor((qj-1)./3)+1;
                        j2 = mod((qj-1),3)+1;
                        
                        tmp2 = num((i2-1).*partSize+1:(i2).*partSize,(j2-1).*partSize+1:(j2).*partSize,:,sj);

                        isGoodPix = ~all(isnan(tmp1),3)&~all(isnan(tmp2),3);

                        if nansum(isGoodPix(:)) < 10 % at least 10 mutually-sampled pixels to compute
                            continue
                        end
                        rt2 = reshape(tmp2,[numel(tmp2(:,:,1)) length(tmp2(1,1,:))]);
                        
                        a = abs(nanmax(rt1,[],1)-nanmax(rt2,[],1));
                        normer = permute(nanmax(nanmax(nanmax(num,[],1),[],2),[],4),[1 3 2]);
                        pp2(qi,qj,si,sj,:) = a./normer;
                    end
                end
            end
        end 
        ts = size(pp2);
        sim.partitioned.pfr = reshape(permute(pp2,[1 3 2 4 5]), ...
            [prod(ts([1 3])) prod(ts([1 3])) length(pp2(1,1,1,1,:))]);
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end
    
    if ismember({'cosine'},varargin)
        fprintf('\n\tComputing cosine similarity...')
        tic
        cossim = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
        for si = 1:length(um(1,1,1,:))
            for sj = si+1:length(um(1,1,1,:))
                tmp1 = um(:,:,:,si);
                tmp2 = um(:,:,:,sj);

                tmp1 = reshape(tmp1,[numel(um(:,:,1,1)) length(um(1,1,:,1))]);
                tmp2 = reshape(tmp2,[numel(um(:,:,1,1)) length(um(1,1,:,1))]);

                isGood = ~all(isnan(tmp1),2) & ~all(isnan(tmp2),2);
                tmp1 = tmp1(isGood,:);
                tmp2 = tmp2(isGood,:);

                isGood = ~all(isnan(tmp1),1) & ~all(isnan(tmp2),1);
                tmp1 = tmp1(:,isGood);
                tmp2 = tmp2(:,isGood);

                dp = pdist2(tmp1',tmp2','cosine');
                
                cossim(si,sj,isGood) = diag(dp);
            end
        end     
        sim.cosine = cossim;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    if ismember({'peak'},varargin)
        fprintf('\n\tComputing difference in peak locations...')
        tic
        isPeak = um==repmat(nanmax(nanmax(um,[],1),[],2),size(um(:,:,1,1)));
        ploc = nan(2,length(um(1,1,1,:)),length(um(1,1,:,1)));
        d2p = nan(length(um(1,1,1,:)),length(um(1,1,1,:)),length(um(1,1,:,1)));
        for k = 1:length(um(1,1,:,1))
            for i = 1:length(um(1,1,1,:))
                [x y] = find(isPeak(:,:,k,i));
                if ~isempty(x)
                    ploc(:,i,k) = [nanmedian(x) nanmedian(y)]';
                end
            end
            d2p(:,:,k) = sqrt(bsxfun(@minus,ploc(1,:,k),ploc(1,:,k)').^2 + ...
                bsxfun(@minus,ploc(2,:,k),ploc(2,:,k)').^2);
        end
        doToss = repmat(logical(eye(size(d2p(:,:,1)))),[1 1 length(d2p(1,1,:))]);
        d2p(doToss) = nan;
        sim.d2p = d2p;
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

    
%     fprintf('\n\tComputing map distance similarity...')
%     
%     normer = nanmax(nanmax(nanmax(um,[],1),[],2),[],4);
%     normer = repmat(normer,[size(um(:,:,1,:))]);
%     num = um./normer;
%     num = reshape(num,[numel(num(:,:,1,1)) length(num(1,1,:,1)) length(num(1,1,1,:))]);
% 
%     tic
%     map_distance = nan([length(um(1,1,1,:)) length(um(1,1,1,:)) length(um(1,1,:,1))]);
%     for si = 1:length(um(1,1,1,:))
%         tmp1 = num(:,:,si);
%         for sj = si+1:length(um(1,1,1,:))
%             tmp2 = num(:,:,sj);
%             
%             map_distance(si,sj,:) = nanmean(abs(tmp1-tmp2),1);
%         end
%     end     
%     sim.map_distance = map_distance;
%     tmp = toc;
%     fprintf('  %0.3fs.',tmp);
    
end