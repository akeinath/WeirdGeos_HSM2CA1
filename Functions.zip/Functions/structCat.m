function s = structCat(s,str,in,dim)
    if nargin < 4 || isempty(dim)
        dim = 3;
    end

    bits = split(str,'.');

    for i = 1:length(bits)
        b = ['s.' sprintf('%s.',bits{1:i-1}) bits{i}];
        b2 = b(1:find(ismember(b,'.'),1,'last')-1);
        if eval(['~isfield(' b2 ',bits{i});'])
            eval([b ' = [];'])
        end
    end

    b = [sprintf('%s.',bits{1:end-1}),bits{end}];
    eval(['s.' b ' = cat(' num2str(dim) ',s.' b ',in);']);
end