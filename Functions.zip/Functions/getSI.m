function si = getSI(m,s)
    m = reshape(m,[numel(m(:,:,1)) size(m,3)]);
    s = s(:)./nansum(s(:));
    si = nansum(s.*(m./nansum(s.*m)).*log2(m./nansum(s.*m)));
    si(all(isnan(m),1)) = nan;
end