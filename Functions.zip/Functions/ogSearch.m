function ogSearch(s,root)
%     doGammas = [0.995 0.95 0.8 0.6 0.4];
%     doAlphas = [(50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5)];
%     doTimestep = [1 5 15 30 60];

    doGammas = [0.999 0.95 0.90 0.8 0.6];
    doAlphas = [(50./30).*10.^(-4) (50./30).*10.^(-3).*5 (50./30).*10.^(-3) ...
        (50./30).*10.^(-3)./5 (50./30).*10.^(-2)];
    doTimestep = [1 3 10 30 60 150];

    doChoices = combvec(doGammas,doAlphas,doTimestep);

    % parameter choices
    for k = 1:length(doChoices(1,:))
        gamma = doChoices(1,k);
        alpha = doChoices(2,k);
        ts = doChoices(3,k);
        srPrecompP = ['MatlabData/SR_Trace_Precomputes/ThirdPass/' slind(root,[2 0]) ...
            '_g' num2str(gamma.*1000) '_a' num2str(round(alpha.*10.^7)) '_t' num2str(ts) '.mat'];
        srPrecompNewP = ['MatlabData/SR_Trace_Precomputes/FullSearch/' slind(root,[2 0]) ...
            '_g' num2str(gamma.*1000) '_a' num2str(round(alpha.*10.^7)) '_t' num2str(ts) '.mat'];
        if exist([srPrecompP])==2
            tic
            fprintf(['\n\t\tLoading Precomputed SR traces...'])
            checkP(srPrecompNewP);
            copyfile(srPrecompP,srPrecompNewP)
            tmp = toc;
            fprintf('  %0.3fs.',tmp);
        end
    end
end