function c2cTraceRSM = c2cTraceAnalysis_Partitioned(uGT,uP,smoothing)
    
    fprintf('\n\tComputing cell-to-cell trace coactivity RSM (partitioned)...')
    tic

    if nargin < 3 || isempty(smoothing)
        smoothing = -1;
    end
    
    if smoothing > 1
        for i = 1:length(uGT)
            uGT{i} = bin(uGT{i},smoothing);
        end
    end
    
    
    allPairs = nan([nansum(nansum(triu(true(length(uGT{1}(:,1))),1))) length(uGT).*9]);
    axc = nan(length(uGT{1}(:,1)),length(uGT{1}(:,1)),length(uGT).*9);

    for si = 1:length(uGT)
        for i = 1:3
            for j = 1:3
                isPart = floor(uP{si}(1,:)./25)+1 == i & ...
                    floor(uP{si}(2,:)./25)+1 == j;

                if nansum(isPart) > 1000
                    tmp = corr(uGT{si}(:,isPart)');
                    axc(:,:,(si-1).*9 + (i-1).*3 + j) = tmp;
                    allPairs(:,(si-1).*9 + (i-1).*3 + j) = tmp(triu(true(length(uGT{1}(:,1))),1));
                end
            end
        end
    end
    
    minclude = inf;
    for i = 1:length(allPairs(1,:))
        ref = allPairs(:,i);
        for j = i+1:length(allPairs(1,:))
            cr = allPairs(:,j);
            isGood = ~isnan(ref)&~isnan(cr);
            if nansum(isGood)~=0
                minclude = nanmin(nansum(isGood),minclude);
            end
        end
    end
    
    c2cTraceRSM = nan(length(allPairs(1,:)));
    for i = 1:length(allPairs(1,:))
        ref = allPairs(:,i);
        for j = i+1:length(allPairs(1,:))
            cr = allPairs(:,j);
            isGood = ~isnan(ref)&~isnan(cr);
            if nansum(isGood) == 0
                continue
            end
            
            inds = find(isGood);
            inds = inds(randperm(length(inds)));
            inds = inds(1:minclude);
            isGood = false(size(isGood));
            isGood(inds) = true;
            
            [rval pval] = corr(ref(isGood),cr(isGood),'type','pearson'); %spearman
            c2cTraceRSM(i,j) = rval;
        end
    end
    
    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end




















