function [srTraces srMaps] = genBVC_sr(bvcTraces,sr_gamma,sr_alpha,timeStep)


    if nargin < 2 || isempty(sr_gamma)
        sr_gamma = 0.995;
    end
    if nargin < 3 || isempty(sr_alpha)
        sr_alpha = (50./30).*10.^(-4);
    end
    if nargin < 4 || isempty(timeStep)
        timeStep = 1;
    end

    if length(sr_alpha)==1
        sr_alpha = repmat(sr_alpha,[1 length(bvcTraces)]);
    end

    fprintf('\n\t\t\t*Computing Successor Features from BVC inputs*')
    tic
    
    placeThreshold = 0.8;
    nBVCs = length(bvcTraces{1}(:,1));
    M = eye(nBVCs);

    tic
    fprintf('\n\t\tComputing SR traces sessions  ')
    srTraces = repmat({[]},[1 length(bvcTraces)]);
    backspace = 0;
    for si = [1:length(bvcTraces)]
        str = sprintf('(%i of %i)',[si length(bvcTraces)]);
        fprintf([repmat('\b',[1 backspace]) str]);
        backspace = length(str);

        srTrace = nan(size(bvcTraces{si}));
        for ti = 1:length(bvcTraces{si}(1,:))-timeStep
            phi = bvcTraces{si}(:,ti)';
            n_phi = bvcTraces{si}(:,ti+timeStep)';

            M = M + sr_alpha(si) * (phi' + sr_gamma * M * n_phi' - M * phi') * phi;
            srTrace(:,ti) = nansum(bsxfun(@times,M,phi),2);
        end
        srTraces{si} = srTrace;
    end
    tmp = toc;
    fprintf('  %0.3fs.',tmp);

    % Norm each to it's max firing across all environments
% % %     tmp = cellfun(@nanmax,srTraces,repmat({[]},size(srTraces)),repmat({2},size(srTraces)),'uni',0);
% % % %     normer = nanmax(cat(2,tmp{:}),[],2);
% % %     for si = 1:length(srTraces)
% % %         srTraces{si} = bsxfun(@rdivide,srTraces{si},tmp{si});
% % %         srTraces{si} = (srTraces{si}-placeThreshold)./(1-placeThreshold); % Only keep top 20%
% % %         srTraces{si}(srTraces{si}<0) = 0;
% % %     end

end







































