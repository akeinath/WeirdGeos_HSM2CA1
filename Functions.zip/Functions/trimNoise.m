function trimNoise(v)

end