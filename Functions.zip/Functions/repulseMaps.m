function rm = repulseMaps(m,scalar)
    if nargin < 2 || isempty(scalar)
        scalar = -0.1;
    end

    nm = permute(all(isnan(m),3),[1 2 4 3]);
    pm = padarray(nm,[1 1],true);

    dm = nan(size(nm));
    for i = 1:length(pm(1,1,:))
        tm = pm(:,:,i);
        [doX doY] = find(~tm);
        [nanX nanY] = find(tm);

        d2n = sqrt(nanmin(nansum(bsxfun(@minus,[doX doY],permute([nanX nanY],[3 2 1])).^2,2),[],3));
        tm = nan(size(tm));
        tm(sub2ind(size(tm),doX,doY)) = d2n;
        dm(:,:,i) = tm(2:end-1,2:end-1);
    end

    md = nanmax(dm(:));

    rm = scalar.*(md - dm)./md;
end