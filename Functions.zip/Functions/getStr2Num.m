function out = getStr2Num(in,prefix)
    out = nan;
    try
        if all(in(1:length(prefix))==prefix)
            out = str2num(in(length(prefix)+1:end));
        end
    end
end