function [fits] = multiRSA(root,varargin)
    ref = varargin{1};
    comps = varargin(2:end);

    minS = nanmin(cellfun(@size,varargin,repmat({3},size(varargin))));
    nsims = 500;
    fits = nan(nsims,length(comps)+1);
    jointNoiseCeiling = nan(nsims,2,length(comps)+1);

    for i = 1:length(comps)
        
        tic
        bestParams = fminsearch(@(params)getRSAFit(ref,comps,params,500,[1:length(comps)]~=i),1);
        toc

        [error fits(:,i) jointNoiseCeiling(:,:,i)] = getRSAFit(ref,comps,bestParams,500,[1:length(comps)]~=i);

% % %         [fits(:,i) jointNoiseCeiling(:,:,i)] = help_shRSA(ref,comps{i},minS,nsims);
    end

    tic
    bestParams = fminsearch(@(params)getRSAFit(ref,comps,params,500,false(1,length(comps))),1);
    toc

    [error fits(:,end) jointNoiseCeiling(:,:,end)] = getRSAFit(ref,comps,bestParams,500,false(1,length(comps)));

    figure()
    set(gcf,'position',[50 50 75+25.*(length(comps)+1).*1.3 225.*1.3])
    set(gca,'position',[0.3 0.3 0.5 0.5])
    mkWhisker(fits,[{'Mouse Prediction'} {'Stability'} {'Combined'}],cool(length(comps)+1).*0.75+0.25)
    set(gca,'ylim',[-0.2 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    
    doPerc = 0.025;
    jnc = [];
    for i = 1:length(jointNoiseCeiling(1,1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,1,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,1,i),1-doPerc)]];
    end
    
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    ylabel('Kendalls Tau')
    xlabel('Compared RSM')
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')

    ntests = 1;
    count = 0;
    for i = 1:length(jointNoiseCeiling(1,1,:))
        for j = i+1:length(fits(1,:))
            count = count+1;

% % %             fprintf(fid,['\nGroups:  ' num2str(i) ' vs. ' num2str(j)]);

            actual = abs(nanmean(fits(:,i))-nanmean(fits(:,j)));

            a = fits(:,i);
            b = fits(:,j);
            c = a(:)<[b(:)]';
            pval = nanmean(c(:));
            pval = nanmin(pval,1-pval).*2;
        
            text(2,1.05+count.*0.1,sprintf('p_{%i, %i} = %0.4f',[i j pval.*ntests]),'fontname','arial','fontsize',9,'horizontalalignment','center')

% % %             str = sprintf('; \tActual = %0.3f, p = %0.4f, p (bonferroni) = %0.4f',[actual pval pval.*ntests]);
% % %             fprintf(fid,str);
        end

        a = fits(:,i);
        b = jointNoiseCeiling(:,1,i);
        c = a(:)<[b(:)]';
        pval = nanmean(c(:));
        pval = nanmin(pval,1-pval).*2;
        text(2,0.2+i.*0.1,sprintf('p_%i = %0.4f',[i pval.*1]),'fontname','arial','fontsize',9,'horizontalalignment','center')
    end


    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/' slind(root,[1 0]) '_MulitRSA'],[{'tiff'} {'pdf'}])
    drawnow
end

function [error fits jointNoiseCeiling] = getRSAFit(ref,comps,params,nsims,doShuf)

    if nargin < 5
        doShuf = false(1,length(comps));
    end

    fits = nan(nsims,1);

    for i = 1:nsims
        
        for j = find(doShuf)
            isGood = find(all(~all(isnan(comps{j}),1),3));
            newOrder = randperm(length(isGood));
            comps{j}(isGood,isGood,:) = comps{j}(isGood(newOrder),isGood(newOrder),:);
        end
    
        in = comps{1};
        for j = 2:length(comps)
            in = in + comps{j}.*params(j-1);
        end

        [fits(i) jointNoiseCeiling(i,:)] = help_shRSA(ref,in,[],1);
    end

    error = (1-nanmean(fits)).^2;
end