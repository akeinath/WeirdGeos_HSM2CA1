function rsaxConfig(rsm)

    [envLabel env_blocked] = envStuff();
    prsm = nan(length(envLabel),length(envLabel),length(envLabel),length(envLabel));
    sprsm = nan(length(envLabel),length(envLabel),length(envLabel),length(envLabel));
    tRSM1 = nanmean(rsm.partition.mouse_pred,3);
    tRSM3 = repmat(eye(9),[10 10 size(rsm.partition.human{end},3)]); %nanmean(pStabRSM,3);
    tRSM2 = nanmean(rsm.partition.human{end},3);
    for ca1_i = 1:length(envLabel)
        for ca1_j = 1:length(envLabel)
            for hsm_i = 1:length(envLabel)
                for hsm_j = 1:length(envLabel)
    
                    rsm1 = tRSM1((ca1_i-1).*9+1:(ca1_i).*9,(ca1_j-1).*9+1:(ca1_j).*9,:);
                    rsm2 = tRSM2((hsm_i-1).*9+1:(hsm_i).*9,(hsm_j-1).*9+1:(hsm_j).*9,:);

                    rsm3 = tRSM3((ca1_i-1).*9+1:(ca1_i).*9,(ca1_j-1).*9+1:(ca1_j).*9,:);
    
                    a = rsm1(:);
                    b = rsm2(:);
                    c = rsm3(:);

                    try
                        prsm(ca1_i,ca1_j,hsm_i,hsm_j) = ...
                            corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)), ...
                            'type','kendall');

                        sprsm(ca1_i,ca1_j,hsm_i,hsm_j) = ...
                            corr(c(~isnan(c)&~isnan(b)),b(~isnan(c)&~isnan(b)), ...
                            'type','kendall');
                    end
                end
            end
        end
    end

    id_sim = nan(10,10);
    for i = 1:10
        for j = 1:10
            id_sim(i,j) = prsm(i,j,i,j);
        end
    end

    prsm(10,9,10,9)

    figure
    set(gcf,'position',[50 50 700 350])
    subplot(1,2,1)
    tmp = permute(prsm(10,1:9,10,1:9),[2 4 1 3]);
    tmp2 = permute(sprsm(10,1:9,10,1:9),[2 4 1 3]);
    tmp = tmp-tmp2;
    tmp = squarify(tmp);
    imagesc(tmp)
    alpha(double(~isnan(tmp)))
    colorbar
%         caxis([0.6 0.9])
    axis equal
    axis square
    ylabel('CA1 Sq->Env')
    xlabel('Human Sq->Env')
    set(gca,'xtick',1:length(envLabel),'xticklabel',envLabel, ...
        'ytick',1:length(envLabel),'yticklabel',envLabel);
    subplot(1,2,2)
    a = tmp(1:length(tmp)+1:end);
    mkBar(a,envLabel)
    saveFig(gcf,'Plots/Experiment_1/Summary/RSM_Square->Env_Comparison',[{'tiff'} {'pdf'}])


%         fitVals = [];
%         for i = 1:10
%             fitVals = [fitVals [tmp(i,i); sort(tmp([1:i-1 i+1:end],i),'descend')]];
%         end
%         figure()
%         set(gcf,'position',[50 50 175 225])
%         mkGraph(fitVals')

    sameTransform = tmp(logical(eye(size(tmp))));

    blah = tmp;
    blah(logical(eye(size(tmp)))) = nan;
    diffTransform = nanmean(blah);

%         [a b] = nanmax(tmp,[],1);
%         diffTransform = [getTri(tmp,1); getTri(tmp',1)];

    figure()
    set(gcf,'position',[50 50 175 225])
    mkGraph([{sameTransform} {diffTransform'}],[{'Same'} {'Different'}],[0 0 0])
    ylabel('Kendalls Tau')
    xlabel('Sq->Env Transformation')
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    [h pval ci tstat] = ttest(sameTransform);
    [h pval ci tstat] = ttest(diffTransform);
    [h pval ci tstat] = ttest(sameTransform,diffTransform');
    saveFig(gcf,'Plots/Experiment_1/Summary/RSM_Square->Env_Comparison_SameVsDiff',[{'tiff'} {'pdf'}])
end