function in = macheck(in,forceMac)
    if nargin < 2 || isempty(forceMac)
        forceMac = false;
    end
    if ~forceMac && ispc
        in(ismember(in,'/')) = '\';
    else
        in(ismember(in,'\')) = '/';
    end
end