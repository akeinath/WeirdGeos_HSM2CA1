function m = mkTri(v,ms)
    m = nan(ms);
    ims = triu(true(ms),1);
    m(ims) = v;
end