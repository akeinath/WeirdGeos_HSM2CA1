function a = maxnorm(a,t)
    if nargin < 2 || isempty(t)
        t = 0;
    end

    norm = nanmax(nanmax(nanmax(a,[],1),[],2),[],4);
    a = a./repmat(norm,[size(a(:,:,1,:))]);

    a = a-t;
    a(a<0) = 0;
end