function [overallRSMs partitionRSMs smoothedMaps pixelRSMs] = m2rsm(m,sd,ignorePartitioned,doPixel)

    %% This function takes in unsmoothed maps and a smoothing value and returns
    %% the overallRSMs, partitionRSMs, and smoothed maps at that parameterization

    if nargin < 2 || isempty(sd)
        sd = -1;
    end

    if nargin < 3 || isempty(ignorePartitioned)
        ignorePartitioned = false;
    end

    if nargin < 4 || isempty(doPixel)
        doPixel = false;
    end

    if ~iscell(m)
        m = {m};
    end
    
%     fprintf(['\n\t\t\tConverting Maps to RSMs (' num2str(sd) ' s.d.):\t']);
%     tic

    smoothedMaps = m;
    pixelRSMs = repmat({[]},size(m));
    partitionRSMs = repmat({[]},size(m));
    overallRSMs = repmat({[]},size(m));
    for i = 1:length(m(1,:))
        for j = 1:length(m(:,1))
            tm = m{j,i};

            if isempty(tm)
                continue
            end

            isGood = nansum(~all(all(isnan(tm),1),2),4) >= 2;
            tm = tm(:,:,isGood,:);

            if sd > 0
                kern = fspecial('gauss',[size(tm,[1]).*3.*ones(1,2)],sd);
                
                
                isBad = isnan(tm);
                tm(isBad) = 0;
                tm = imfilter(tm,kern,'same');
                
                tmp = all(isBad,3);
                newBad = false(size(tmp));
                for envI = 1:10
                    for qi = 0:2
                        for qj = 0:2
                            tt = tmp(:,:,:,envI);
                            doChunk = tt(qi.*5+1:(qi+1).*5,qj.*5+1:(qj+1).*5);
                            if all(doChunk(:))
                                newBad(qi.*5+1:(qi+1).*5,qj.*5+1:(qj+1).*5,envI) = true;
                            end
                        end
                    end
                end
                isBad = repmat(newBad,[1 1 size(tm,3) 1]);

                tm(isBad) = nan;

                smoothedMaps{j,i}(:,:,isGood,:) = tm;
                smoothedMaps{j,i}(:,:,~isGood,:) = nan;
            end
    
            if ~ignorePartitioned
                blah = getPairwiseSim(tm,0,'partitioned_pearson'); % turned off whiteningn
                partitionRSMs{j,i} = squarify(blah.partitioned.pearson);
            end

            if doPixel
                blah = getPairwiseSim(tm,0,'pixel_pearson'); % turned off whiteningn
                pixelRSMs{j,i} = squarify(blah.pixel.pearson);
            end

            blah = getPairwiseSim(tm,0,'pearson'); % turned off whiteningn
            overallRSMs{j,i} = squarify(blah.pearson);
        end
    end

    if all(size(overallRSMs)==1)
        partitionRSMs = partitionRSMs{1};
        overallRSMs = overallRSMs{1};
        pixelRSMs = pixelRSMs{1};
    end

%     tmp = toc;
%     fprintf('  %0.3fs.',tmp);
end














