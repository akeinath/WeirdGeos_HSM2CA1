function c2cTraceRSM = c2cTraceAnalysis(uGT,smoothing)
    
    fprintf('\n\tComputing cell-to-cell trace coactivity RSM...')
    tic

    if nargin < 4 || isempty(smoothing)
        smoothing = -1;
    end
    
    if smoothing > 1
        for i = 1:length(uGT)
            uGT{i} = bin(uGT{i},smoothing);
        end
    end
    
    
    
    allPairs = nan([nansum(nansum(triu(true(length(uGT{1}(:,1))),1))) length(uGT)]);

    axc = nan(length(uGT{1}(:,1)),length(uGT{1}(:,1)),length(uGT));
    for si = 1:length(uGT)
        tmp = corr(uGT{si}');
        axc(:,:,si) = tmp;
        
        allPairs(:,si) = tmp(triu(true(length(uGT{1}(:,1))),1));
    end
    
    minclude = inf;
    for i = 1:length(allPairs(1,:))
        ref = allPairs(:,i);
        for j = i+1:length(allPairs(1,:))
            cr = allPairs(:,j);
            isGood = ~isnan(ref)&~isnan(cr);
            minclude = nanmin(nansum(isGood),minclude);
        end
    end
    
    c2cTraceRSM = nan(length(allPairs(1,:)));
    for i = 1:length(allPairs(1,:))
        ref = allPairs(:,i);
        for j = i+1:length(allPairs(1,:))
            cr = allPairs(:,j);
            isGood = ~isnan(ref)&~isnan(cr);
            inds = find(isGood);
            inds = inds(randperm(length(inds)));
            inds = inds(1:minclude);
            isGood = false(size(isGood));
            isGood(inds) = true;
            
            [rval pval] = corr(ref(isGood),cr(isGood),'type','spearman'); %spearman
            c2cTraceRSM(i,j) = rval;
        end
    end
    
    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end




















