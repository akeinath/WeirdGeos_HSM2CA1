function across = prepAcross()

    across.mfr = [];
    across.pfr = [];
    across.f2f = repmat({[]},[11 11]);
    across.pv2pv = repmat({[]},[11 11]);
    across.unum.partitioned.pv = [];
    across.unum.partitioned.pearson = [];
    across.unum.partitioned.dpfr = [];
    across.um.partitioned.pv = [];
    across.um.partitioned.pearson = [];
    across.um.partitioned.dpfr = [];
    
    across.models.boundaryTethered = [];
    across.models.allo = [];
    across.models.fit.bt = [];
    across.models.fit.allo = [];
    
    across.rsm.bySeq.partitioned_pearson = [];
    across.rsm.pearsonXc2c = [];
    across.rsm.pearson = [];

    across.rsm.drift = [];
    across.rsm.stabilization = [];
    across.rsm.envSim = [];
    
    across.vecSim = [];
    
%     across.rsa.rsm.bt = [];
%     across.rsa.rsm.allo = [];
%     across.rsa.rsm.bt_dropout = [];
%     across.rsa.rsm.allo_dropout = [];
%     across.rsa.rsm.actual = [];
%     across.rsa.rsm.bvc = [];
%     across.rsa.rsm.bvc2place = [];
%     across.rsa.label = [];

    across.c2c.trace.condCRSM = [];
    across.c2c.trace.xc = [];
    across.c2c.trace.condProb = [];
    across.c2c.simVsBlocked = [];
    across.c2c.closedHiSqStab = repmat({[]},[1 4]);
end