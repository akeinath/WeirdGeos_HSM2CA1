function in = spaceSub(in)
    in(ismember(in,' -')) = '_';
end