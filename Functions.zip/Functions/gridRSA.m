function [pv diff_ivals corr_ivals] = gridRSA(a,b,gridStride)
    if nargin<3 || isempty(gridStride)
        gridStride = 5;
    end
    
    % normalize maps?
    a = maxnorm(a);
    b = maxnorm(b);
    
    sa = ceil(size(a(:,:,1))./gridStride);
    sb = ceil(size(b(:,:,1))./gridStride);
    
    isGood = ~(all(all(isnan(a),1),2) | all(all(isnan(b),1),2));
    
    pv = nan(prod(sa),prod(sb));
    corr_ivals = nan(prod(sa),prod(sb),length(a(1,1,:)));
    diff_ivals = nan(prod(sa),prod(sb),length(a(1,1,:)));
    for ai = 1:gridStride:length(a(:,1,1))
        for aj = 1:gridStride:length(a(1,:,1))
            apiece = a(ai:nanmin(ai+gridStride-1,length(a(:,1,1))), ...
                aj:nanmin(aj+gridStride-1,length(a(1,:,1))),:);
            for bi = 1:gridStride:length(a(:,1,1))
                for bj = 1:gridStride:length(a(:,1,1))
                    bpiece = b(bi:nanmin(bi+gridStride-1,length(b(:,1,1))), ...
                        bj:nanmin(bj+gridStride-1,length(b(1,:,1))),:);
                    
                    ra = reshape(apiece(:,:,isGood),[numel(apiece(:,:,1)) nansum(isGood)]);
                    rb = reshape(bpiece(:,:,isGood),[numel(bpiece(:,:,1)) nansum(isGood)]);
                    goodPix = ~any(isnan(ra),2) & ~any(isnan(rb),2);
                    
                    if any(goodPix)
                        
                        tra = ra(goodPix,:);
                        trb = rb(goodPix,:);
                        
                        pv(((ai-1)./gridStride).*(length(a(:,1,1))./gridStride) + (aj-1)./gridStride+1, ...
                            ((bi-1)./gridStride).*(length(b(:,1,1))./gridStride) + (bj-1)./gridStride+1) = ...
                            corr(tra(:),trb(:));
                        
                        % try within cell within patch corrs
                        tv = corr(ra(goodPix,:),rb(goodPix,:));
                        corr_ivals(((ai-1)./gridStride).*(length(a(:,1,1))./gridStride) + (aj-1)./gridStride+1, ...
                            ((bi-1)./gridStride).*(length(b(:,1,1))./gridStride) + (bj-1)./gridStride+1, ...
                            isGood) = tv(1:length(tv)+1:end);
                        
                        % try within cell within patch mean map differences
                        % (avoids the degeneracies of low variance for out-of-field patches)
                        
                        diff_ivals(((ai-1)./gridStride).*(length(a(:,1,1))./gridStride) + (aj-1)./gridStride+1, ...
                            ((bi-1)./gridStride).*(length(b(:,1,1))./gridStride) + (bj-1)./gridStride+1, ...
                            isGood) = 1-nanmean(abs(ra(goodPix,:)-rb(goodPix,:)));
                    end
                end
            end
        end
    end
end