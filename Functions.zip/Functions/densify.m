function nm = densify(m)
    nm = m;

    badCols = all(all(isnan(m),3),1);
    badRows = all(all(isnan(m),3),2);

    nm(:,badCols,:) = [];
    nm(badRows,:,:) = [];
end