function d2bComp(varargin)

    aP = nan(500,2,length(varargin));
    for i = 1:length(varargin)
        aP(:,:,i) = dispxD2B(varargin{i});
    end
    
    labels = [];
    for i = 1:length(varargin)
        labels = [labels {slind(varargin{i}{1},[1 3],'\/_-')}];
    end

    figure
    set(gcf,'position',[50 50 250 225])
    subplot(1,2,1)
    mkWhisker(permute(aP(:,1,:),[1 3 2]),labels)
    ylabel('Decay Rate (per m)')
    set(gca,'ylim',[0 1.5])
    subplot(1,2,2)
    mkWhisker([permute(aP(:,2,:),[1 3 2])],labels)
    ylabel('Decay Scalar')
    set(gca,'ylim',[0 1])
    compLabels = [];
    for i = 1:length(varargin)
        for j = i+1:length(varargin)
            compLabels = [compLabels {[labels{i} '_' labels{j}]}];
        end
    end
    outP = ['Stats/Group_Comparison_D2B_Fits_' cat(2,labels{:}) '.txt'];
    
    checkP(outP);
    fid = fopen(outP,'w');
    for gi = 1:length(varargin)-1
        for gj = gi+1:length(varargin)
            tmp = bsxfun(@gt,aP(:,1,gi),aP(:,1,gj)');
            pval_rate = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;

            tmp = bsxfun(@gt,aP(:,2,gi),aP(:,2,gj)');
            pval_scalar = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
            fprintf(fid,'\nNonparametric shuffles: Decay Rate p = %0.4e; Decay Scalar p = %0.4e',[pval_rate pval_scalar]);
        end
    end
    fclose(fid)
end