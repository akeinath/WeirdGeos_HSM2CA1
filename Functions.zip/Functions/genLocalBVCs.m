function [bvcTraces spaceTraces geoSpaceTraces] = genBVCs(p,bvc_distanceConstant,bvc_distanceScalar,dist_params,walls,localRot)

    
    % add three squares for familiarization, maybe rotate paths for less
    % redundancy?

    if nargin < 2 || isempty(bvc_distanceConstant)
        bvc_distanceConstant = 8;
    end
    if nargin < 3 || isempty(bvc_distanceScalar)
        bvc_distanceScalar = (1./12);
    end
    if nargin < 4 || isempty(dist_params)
        dist_params = [1 2];
    end
    if nargin < 6 || isempty(localRot)
        localRot = repmat({[]},size(p));
        for i = 1:length(p)
            localRot{i} = zeros(1,length(p{i}));
        end
    end

    % params from Will de Cothi


    fprintf('\n\tPrecomputing BVCs...')
    tic
    
%     nBVCs = 500;
%     bvcAngs = rand(nBVCs,1).*2.*pi;
% %     bvcDists = rand(nBVCs,1).*85;
%     bvcDists = betarnd(dist_params(1),dist_params(2),nBVCs,1).*85;
%     bvc_angleSD = ones(nBVCs,1).*deg2rad(11.25);
    
    ar = [0:pi./12:2.*pi-pi./12];
    dr = [1:0.5:6.5].^2; %[3:3:36]; % 0:4:48

    nBVCs = nanmax(size(ar).*size(dr));
    t = combvec(ar,dr)';
    bvcAngs = t(:,1);
    bvcDists = t(:,2);
    bvc_angleSD = ones(nBVCs,1).*deg2rad(11.25);

    
    bvcTraces = repmat({[]},[1 length(p)]);

    if any(bvc_distanceConstant+bvc_distanceScalar.*bvcDists<=0)
        bvcMaps = nan;
        bvcMaps_unsmoothed = nan;
        return;
    end

    %%% Generate all BVC traces

    if nargin < 5 || isempty(walls)
        % generate the walls
        roomDims = [20 35];
        tw = [0 0 7.5 0; ...
            roomDims(1) 0 12.5 0; ...
            0 0 0 roomDims(2); ...
            0 roomDims(2) roomDims(1) roomDims(2); ...
            roomDims(1) 0 roomDims(1) roomDims(2)]-[roomDims roomDims]./2;
    
        walls = tw + [0 27.5 0 27.5];
        walls = [walls; walls(:,1:2)*[cos(pi) -sin(pi); sin(pi) cos(pi)] ...
            walls(:,3:4)*[cos(pi) -sin(pi); sin(pi) cos(pi)]];
    
        walls = [walls; walls(:,1:2)*[cos(pi./2) -sin(pi./2); sin(pi./2) cos(pi./2)] ...
            walls(:,3:4)*[cos(pi./2) -sin(pi./2); sin(pi./2) cos(pi./2)]];
        walls = walls+[45 45 45 45];
        walls = permute(walls,[2 3 1]);
        %%%%%%%%%%%%%%%%%
    end


    figure
    hold on
    for i = 1:length(walls(1,1,:))
        plot(walls([1 3],1,i),walls([2 4],1,i));
    end
    axis equal
    for i = 1:length(p)
        plot(p{i}(1,:),p{i}(2,:));
        drawnow
    end
    %%%%%%%%%%%%%%%%%%%

    globalAngs = bvcAngs;
    for si = [1:length(p)]

%         walls = permute(getBlockedBounds(blocked{si}),[2 3 1]);
        wXphd = bsxfun(@minus,repmat(p{si},[2 1]),walls);

        a = permute(walls([3 4],:,:) - walls([1 2],:,:),[3 1 2]);
        wtheta = cart2pol(a(:,1),a(:,2));

        rays = ar; %[0:binAng:2.*pi-binAng];

        rayPoints = permute([cos(rays).*200; sin(rays).*200],[1 2 3]);
        m2 = permute(rayPoints(2,:)./rayPoints(1,:),[2 1 3]);
        sc = [sign(rayPoints(1,:))' sign(rayPoints(2,:))'];
        allInDist = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        allInAngs = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        for j = 1:length(walls(1,1,:))
            intOut = lineSegmentIntersect(wXphd(:,:,j)',[zeros(size(rayPoints))' rayPoints']);


            doesInt = intOut.intAdjacencyMatrix;
            d2w = sqrt(intOut.intMatrixX.^2 + intOut.intMatrixY.^2);
            d2w(~doesInt) = nan;
            allInDist(:,:,j) = d2w';
        end

%         [nearestBorder nbInd] = nanmin(allInDist,[],3);
%         nearestBorder(isnan(nearestBorder)) = 0; % No Firing if all NaNs
%         for i = unique(localRot{si})
%             doInds = i==localRot{si};
%             nearestBorder(:,doInds) = circshift(nearestBorder(:,doInds),[-(i./90).*8 0]);
%         end

    %%%%% Create local BVCs
        
        for k = 1:size(allInDist,3)
            tmp = allInDist(:,:,k);
            for i = unique(localRot{si})
                doInds = i==localRot{si};
                tmp(:,doInds) = circshift(tmp(:,doInds),[-(i./90).*6 0]);
            end
            allInDist(:,:,k) = tmp;
        end

% % %         %%% Comment in for global place cells
% % %         for i = 1:length(p)
% % %             localRot{i} = zeros(1,length(p{i}));
% % %         end

        currAngle =  ar'-deg2rad(localRot{si});
        [nearestBorder nbInd] = nanmin(allInDist,[],3);
        nearestBorder(isnan(nearestBorder)) = 0; % No Firing if all NaNs
        nearestBorderAngle = nan(size(nearestBorder));
        for i = 1:length(ar)
            nearestBorderAngle(i,:) = mod(wtheta(nbInd(i,:))' - currAngle(i,:),2.*pi);
        end
        
        rnb = repmat(nearestBorder,[length(dr) 1]);
        rar = repmat(nearestBorderAngle,[length(dr) 1]);

        % Distance tuning gaussian
        a = normpdf(bsxfun(@minus,rnb,bvcDists),zeros(size(rnb)), ...
            repmat(bvc_distanceConstant+bvc_distanceScalar.*bvcDists, ...
            [1 length(rnb(1,:))]));
        % Angle tuning gaussian
        b = normpdf(nanmin(abs(rar-[pi./2]), ...
            abs(rar-[3.*pi./2])),0,repmat(bvc_angleSD, ...
            [1 length(rar(1,:))]));
        bvcTrace = a.*b; % Combine

        bvcTraces{si} = bvcTrace;
    end

    % Norm each to it's max firing across all environments
    tmp = cellfun(@nanmax,bvcTraces,repmat({[]},size(bvcTraces)),repmat({2},size(bvcTraces)),'uni',0);
    normer = nanmax(cat(2,tmp{:}),[],2);
    for si = 1:length(bvcTraces)
        bvcTraces{si} = bsxfun(@rdivide,bvcTraces{si},normer);
        bvcTraces{si}(isnan(bvcTraces{si})) = 0;
    end

%     m = mkTraceMaps(p{end},bvcTraces{end});

    %%%%%%% Make Spatial Cells

% % %     allLocs = cat(2,p{:});
% % %     gridSpace = nanmax(allLocs(:))./sqrt(nBVCs);
% % %     allLocs = combvec(gridSpace./2:gridSpace:nanmax(allLocs(:)), ...
% % %         gridSpace./2:gridSpace:nanmax(allLocs(:)));
% % % 
% % %     nSpatialCells = nBVCs;
% % %     spaceTraces = repmat({[]},[1 length(p)]);
% % %     spaceSD = 5;
% % %     for k = 1:nSpatialCells
% % %         nCons = poissrnd(2,1,1);
% % %         while nCons<2 || nCons>8
% % %             nCons = poissrnd(2,1,1);
% % %         end
% % %         doLocs = allLocs(:,randperm(length(allLocs)));
% % %         doLocs = doLocs(:,1:nCons);
% % %         for si = [1:length(p)]
% % %             d2f = permute(sqrt(nansum(bsxfun(@minus,p{si},permute(doLocs,[1 3 2])).^2,1)),[3 2 1]);
% % %             zd2f = normpdf(d2f./spaceSD);
% % %             zt = nanmax(zd2f,[],1);
% % % %             zt = (zt-nanmin(zt))./range(zt);
% % %             spaceTraces{si}(k,:) = zt./nanmax(zt);
% % %         end
% % %     end

    %%%%%%% Make Random Spatial Cells

    % compute environment center
    tmp = permute(walls,[1 3 2]);
    envCenter = nanmean(tmp([1 2],:),2)';

    ars = [];
    for i = 1:4
        doWalls = permute(walls(:,:,(i-1).*5+1:(i).*5),[1 3 2]);
        roomBounds = [nanmin(nanmin(doWalls([1 3],:),[],2)) nanmin(nanmin(doWalls([2 4],:),[],2)) ...
            nanmax(nanmax(doWalls([1 3],:),[],2)) nanmax(nanmax(doWalls([2 4],:),[],2))];

        center = nanmean([roomBounds(1:2); roomBounds(3:4)]);
        entryAngles(i) = round(rad2deg(cart2pol(center(1) - envCenter(1),center(2) - envCenter(2))));

        roomSize = [range(roomBounds([1 3])) range(roomBounds([2 4]))];
        if abs(entryAngles(i))==90
            roomSize = roomSize([2 1]);
        end
        ars = [ars; roomSize center entryAngles(i)];
    end


    gridSpace = nanmax(ars(:,1:2))./sqrt(nBVCs);
    allLocs = combvec(gridSpace(1)./2:gridSpace(1):nanmax(ars(:,1)), ...
        gridSpace(2)./2:gridSpace(2):nanmax(ars(:,2)));

    
    nSpatialCells = nBVCs;
    spaceTraces = repmat({[]},[1 length(p)]);
    spaceSD = 5;
    for k = 1:nSpatialCells

        for q = 1:4
            tmp = allLocs(:,randperm(length(allLocs)));
            doLoc = tmp(:,1);
            tl = doLoc-(ars(q,1:2)'./2);
            tl = [cosd(ars(q,5)) -sind(ars(q,5)); sind(ars(q,5)) cosd(ars(q,5))]*tl;
            equiLocs(:,q) = tl+ars(q,3:4)';
        end

        for si = [1:length(p)]
            d2f = nanmin(sqrt(nansum([p{si}-permute(equiLocs,[1 3 2])].^2,1)),[],3);
            zd2f = normpdf(d2f./spaceSD);
            zt = nanmax(zd2f,[],1);

            spaceTraces{si}(k,:) = zt./nanmax(zt);
        end
    end
    %       m = mkTraceMaps(p{1},spaceTraces{1});

    %%%%%%% Make GeoSpace Cells

    % compute environment center
    tmp = permute(walls,[1 3 2]);
    envCenter = nanmean(tmp([1 2],:),2)';

    ars = [];
    for i = 1:4
        doWalls = permute(walls(:,:,(i-1).*5+1:(i).*5),[1 3 2]);
        roomBounds = [nanmin(nanmin(doWalls([1 3],:),[],2)) nanmin(nanmin(doWalls([2 4],:),[],2)) ...
            nanmax(nanmax(doWalls([1 3],:),[],2)) nanmax(nanmax(doWalls([2 4],:),[],2))];

        center = nanmean([roomBounds(1:2); roomBounds(3:4)]);
        entryAngles(i) = round(rad2deg(cart2pol(center(1) - envCenter(1),center(2) - envCenter(2))));

        roomSize = [range(roomBounds([1 3])) range(roomBounds([2 4]))];
        if abs(entryAngles(i))==90
            roomSize = roomSize([2 1]);
        end
        ars = [ars; roomSize center entryAngles(i)];
    end


    gridSpace = nanmax(ars(:,1:2))./sqrt(nBVCs);
    allLocs = combvec(gridSpace(1)./2:gridSpace(1):nanmax(ars(:,1)), ...
        gridSpace(2)./2:gridSpace(2):nanmax(ars(:,2)));

    
    nSpatialCells = nBVCs;
    geoSpaceTraces = repmat({[]},[1 length(p)]);
    spaceSD = 5;
    for k = 1:nSpatialCells

        doLoc = allLocs(:,k);
        for q = 1:4
            tl = doLoc-(ars(q,1:2)'./2);
            tl = [cosd(ars(q,5)) -sind(ars(q,5)); sind(ars(q,5)) cosd(ars(q,5))]*tl;
            equiLocs(:,q) = tl+ars(q,3:4)';
        end

        for si = [1:length(p)]
            d2f = nanmin(sqrt(nansum([p{si}-permute(equiLocs,[1 3 2])].^2,1)),[],3);
            zd2f = normpdf(d2f./spaceSD);
            zt = nanmax(zd2f,[],1);

            geoSpaceTraces{si}(k,:) = zt./nanmax(zt);
        end
    end
%     normTrace = activeNorm(geoSpaceTraces,1);
%       m = mkTraceMaps(p{1},geoSpaceTraces{1});

% % % 
% % %     %%%%%%% Make geometric place cells
% % %     nPCs = nBVCs;
% % %     combAmt = [2 16]; % lambda = 4;
% % %     nCons = poissrnd(4,nPCs,1);
% % % 
% % %     placeTraces = repmat({[]},[1 length(p)]);
% % %     srTraces = repmat({[]},[1 length(p)]);
% % %     connections = repmat({[]},[1 nPCs]);
% % %     for si = [1:length(p)]
% % %         %%%% Geometric SR traces
% % %         allFits = [];
% % %         tpt = nan(size(bvcTraces{si}));
% % %         for k = 1:nPCs
% % %             if si == 1
% % %                 nCons = poissrnd(4,1,1);
% % %                 while nCons<2 || nCons>16
% % %                     nCons = poissrnd(4,1,1);
% % %                 end
% % %                 inds = randperm(nBVCs);
% % %                 connections{k} = inds(1:nCons);
% % %             end
% % %             pt = bvcTraces{si}(connections{k},:);
% % %             tmp = prod(pt,1).^(1./nCons);
% % %             tmp = tmp - nanmax(tmp).*0.3;
% % %             tmp(tmp<0) = 0;
% % %             tmp = tmp.*25; % Different from grieves, chosen to scale Hz between 1 and 50
% % % 
% % %             tpt(k,:) = tmp;
% % %         end
% % %         placeTraces{si} = tpt;
% % %     end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%     srTraces = genBVC_sr(bvcTraces);

    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end





















