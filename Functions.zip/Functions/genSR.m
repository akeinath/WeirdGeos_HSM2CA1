function [srTraces M] = genSR(bvcTraces,sr_gamma,sr_alpha,timeStep,separates)


    if nargin < 2 || isempty(sr_gamma)
        sr_gamma = 0.995;
    end
    if nargin < 3 || isempty(sr_alpha)
        sr_alpha = (50./30).*10.^(-2);
    end
    if nargin < 4 || isempty(timeStep)
        timeStep = 1;
    end
    if nargin < 5 || isempty(separates)
        separates = repmat({[]},[1 length(bvcTraces)]);
        for si = 1:length(bvcTraces)
            separates{si} = ones(1,length(bvcTraces{si}(1,:)));
        end
    end

    if length(sr_alpha)==1
        sr_alpha = repmat(sr_alpha,[1 length(bvcTraces)]);
    end

    fprintf('\n\t\t\t*Computing Successor Features from BVC inputs*')
    tic
    
    nMaps = nanmax(cellfun(@size,separates,repmat({1},size(separates))));

    nBVCs = length(bvcTraces{1}(:,1));

    M = nan(nBVCs,nBVCs,nMaps);
    for i = 1:nMaps
        M(:,:,i) = eye(nBVCs);
    end

    tic
    fprintf('\n\t\tComputing SR traces sessions  ')
    srTraces = repmat({[]},[1 length(bvcTraces)]);
    backspace = 0;
    for si = [1:length(bvcTraces)]
        str = sprintf('(%i of %i)',[si length(bvcTraces)]);
        fprintf([repmat('\b',[1 backspace]) str]);
        backspace = length(str);

        srTrace = nan(size(bvcTraces{si}));
        for ti = 1:length(bvcTraces{si}(1,:))-timeStep
            isGroup = separates{si}(:,ti);
            phi = bvcTraces{si}(:,ti)';
            n_phi = bvcTraces{si}(:,ti+timeStep)';

            M(:,:,isGroup) = M(:,:,isGroup) + sr_alpha(si) * (phi' + sr_gamma * M(:,:,isGroup) * n_phi' - M(:,:,isGroup) * phi') * phi;
            srTrace(:,ti) = nansum(bsxfun(@times,M(:,:,isGroup),phi),2);
        end
        srTrace(:,end) = srTrace(:,end-1);
        srTraces{si} = srTrace;
    end
    tmp = toc;
    fprintf('  %0.3fs.',tmp);

% % %     r = nan(4,4);
% % %     for i = 1:4
% % %         for j = 1:4
% % %             r(i,j) = corr(getTri(M(:,:,i)),getTri(M(:,:,j)));
% % %         end
% % %     end
end







































