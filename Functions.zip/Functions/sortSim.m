function [sc2c order] = sortSim(c2c)

    c2c(1:length(c2c(:,1,1))+1:end) = 1;
    [c2c_embedding b c d] = run_umap(1-c2c,'n_neighbors',30, ...
        'n_epochs',500, ...
        'distance','euclidean',...
        'min_dist',0.15,'NSMethod','exhaustive','cluster_method_2D','dbm');
%     ass = double(c+1);
    
    scatter(c2c_embedding(:,1),c2c_embedding(:,2))
end