function out = getVecFields(um,blocked,envs)

    out.f2f = repmat({[]},[length(um(1,1,1,:)) length(um(1,1,1,:))]);
    for k = 1:length(um(1,1,:,1))
        
        afc = repmat({[]},[1 length(um(1,1,1,:))]);
        for si = 1:length(um(1,1,1,:))
            nm = nanmax(reshape(um(:,:,k,:),[numel(um(:,:,k,:)) 1]));
           [a b afc{si}] = getPatches(um(:,:,k,si),9,nm.*0.2);
        end
        
        for si = 1:length(um(1,1,1,:))
            for sj = 1:length(um(1,1,1,:))
                
                a = afc{si};
                b = afc{sj};
                
                if ~isempty(a) && ~isempty(b)

                    d2f = sqrt(nansum(bsxfun(@minus,permute(a,[1 3 2]),permute(b,[3 1 2])).^2,3));
                    
                    while ~isempty(d2f)
                        [blah nn] = nanmin(d2f,[],2);
                        nn = nn(1);
                        out.f2f{si,sj} = [out.f2f{si,sj}; a(1,:) b(nn,:)];
                        
                        a(1,:) = [];
                        b(nn,:) = [];
                        d2f(:,nn) = [];
                        d2f(1,:) = [];
                    end
                end
            end
        end
    end
    
    out.pv2pv = nan([numel(um(:,:,1,1)) numel(um(:,:,1,1)) ...
        length(um(1,1,1,:)) length(um(1,1,1,:))]);
    for si = 1:length(um(1,1,1,:))
        for sj = 1:length(um(1,1,1,:))
            
            a = permute(um(:,:,:,si),[3 1 2]);
            b = permute(um(:,:,:,sj),[3 1 2]);
            ra = reshape(a,[length(a(:,1,1)) numel(a(1,:,:))]);
            rb = reshape(b,[length(b(:,1,1)) numel(b(1,:,:))]);
            
            isGoodCells = ~all(isnan(ra),2) & ~all(isnan(rb),2);
            ra = ra(isGoodCells,:);
            rb = rb(isGoodCells,:);
            
            out.pv2pv(:,:,si,sj) = corr(ra,rb);
        end
    end
end





























