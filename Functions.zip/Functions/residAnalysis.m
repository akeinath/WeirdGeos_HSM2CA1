function residAnalysis(root,h,m,s)

%     tmp = permute(~all(isnan(h)),[3 2 1]);
%       find(0==tmp(:,42))
%     nansum(permute(~all(isnan(h)),[3 2 1]))

    [envLabel env_blocked] = envStuff();

    mh = nanmean(h,3);
    mm = nanmean(m,3);
    ms = nanmean(s,3);

    exclude = all(any(isnan(cat(3,mh,mm,ms)),3));
    mh(exclude,:) = []; mh(:,exclude) = [];
    mm(exclude,:) = []; mm(:,exclude) = [];
    ms(exclude,:) = []; ms(:,exclude) = [];

    th = atanh(getTri(mh)); % No FisherTransform?
    tm = atanh(getTri(mm));
    ts = atanh(getTri(ms));

    getR2 = @(r,t) 1 - nansum(r.^2)./nansum((t-nanmean(t)).^2);

    [b dev stats] = glmfit([tm],th);
    r2_actual = getR2(stats.resid,th);

    fid = fopen(['Stats/' root '_ResidualAnalysis.txt'],'w');
    str = sprintf(['\n\n\t\t*** Just Mouse Included ***\n\nBeta weights:' ...
        '\n\tConstant: %0.3f, p = %0.2e' ...
        '\n\tMouse RSM: %0.3f, p = %0.2e'],[b stats.p]');
    fprintf(fid,str);
    fprintf(fid,sprintf('\n\nr-squared: %0.3f',r2_actual));

    %%%%

    rsmResid = nan(size(mh,[1 2]));
    rsmResid(triu(true(size(rsmResid)),1)) = stats.resid;
    rsmResid = squarify(rsmResid);
%     rsmResid = inflate(rsmResid,exclude);

    figure
    set(gcf,'position',[50 50 350 300])
    imagesc(rsmResid)
    alpha(double(~isnan(rsmResid)))
%     set(gca,'xtick',[4.5:9:90],'ytick',[4.5:9:90], ...
%         'xticklabel',envLabel,'yticklabel',envLabel);
    colorbar
    tmp = biColor;
    colormap(biColor)
% % %     caxis([-1 1])
    axis square
    axis equal
    axis off
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/ResidualAnalysis/' ...
        slind(root,[1 0]) '_JustMousePred'],[{'tiff'} {'pdf'}])

    %%%%%


    [b dev stats] = glmfit([ts],th);
    r2_actual = getR2(stats.resid,th);

    fid = fopen(['Stats/' root '_ResidualAnalysis.txt'],'w');
    str = sprintf(['\n\n\t\t*** Just Stability Included ***\n\nBeta weights:' ...
        '\n\tConstant: %0.3f, p = %0.2e' ...
        '\n\tMouse RSM: %0.3f, p = %0.2e'],[b stats.p]');
    fprintf(fid,str);
    fprintf(fid,sprintf('\n\nr-squared: %0.3f',r2_actual));


    [b dev stats] = glmfit([ts tm],th);
    r2_actual = getR2(stats.resid,th);

    str = sprintf(['\n\n\t\t*** Stability Included ***\n\nBeta weights:' ...
        '\n\tConstant: %0.3f, p = %0.2e\n\tStability: %0.3f, p = %0.2e' ...
        '\n\tMouse RSM: %0.3f, p = %0.2e'],[b stats.p]');
    fprintf(fid,str);
    fprintf(fid,sprintf('\n\nr-squared: %0.3f',r2_actual));
    fclose(fid);
    
    rsmResid = nan(size(mh,[1 2]));
    rsmResid(triu(true(size(rsmResid)),1)) = stats.resid;
    rsmResid = squarify(rsmResid);
    rsmResid = inflate(rsmResid,exclude);

    residXenv = nan(10,10);
    for i = 1:10
        for j = 1:10
            tres = rsmResid((i-1).*9+1:(i).*9,(j-1).*9+1:(j).*9);
            residXenv(i,j) = nansum(tres(:).^2);
        end
    end

    figure
    set(gcf,'position',[50 50 350 300])
    imagesc(residXenv)
    set(gca,'xtick',[1:10],'ytick',[1:10], ...
        'xticklabel',envLabel,'yticklabel',envLabel);
    colorbar
    axis square
    axis equal
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/ResidualAnalysis/' ...
        slind(root,[1 0]) '_PredAndStab_ByEnvironment'],[{'tiff'} {'pdf'}])

    %%%%%%%%%%%%%

    nsims = 500;
    r2_bothShuff = nan(nsims,1);
    r2_stabShuff = nan(nsims,1);
    r2_mouseShuff = nan(nsims,1);
    r2_noShuff = nan(nsims,1);

    r2_noiseCeiling = nan(nsims,1);
    for i = 1:nsims


        mh = nanmean(h(:,:,randi(size(h,3),1,size(h,3))),3);
        mm = nanmean(m(:,:,randi(size(h,3),1,size(h,3))),3);
        ms = nanmean(s(:,:,randi(size(h,3),1,size(h,3))),3);
    
        exclude = all(any(isnan(cat(3,mh,mm,ms)),3));
        mh(exclude,:) = []; mh(:,exclude) = [];
        mm(exclude,:) = []; mm(:,exclude) = [];
        ms(exclude,:) = []; ms(:,exclude) = [];
    
        th = atanh(getTri(mh));
        tm = atanh(getTri(mm));
        ts = atanh(getTri(ms));

        [b dev stats] = glmfit([ts(randperm(length(ts))) tm(randperm(length(tm)))],th);
        r2_bothShuff(i) = getR2(stats.resid,th);

        [b dev stats] = glmfit([ts(randperm(length(ts))) tm],th);
        r2_stabShuff(i) = getR2(stats.resid,th);

        [b dev stats] = glmfit([ts tm(randperm(length(tm)))],th);
        r2_mouseShuff(i) = getR2(stats.resid,th);

        [b dev stats] = glmfit([ts tm],th);
        r2_noShuff(i) = getR2(stats.resid,th);

        a = nanmean(h(:,:,randi(size(h,3),1,size(h,3))),3);
        a(exclude,:) = []; a(:,exclude) = [];
        a = atanh(getTri(a));

        b = nanmean(h(:,:,randi(size(h,3),1,size(h,3))),3);
        b(exclude,:) = []; b(:,exclude) = [];
        b = atanh(getTri(b));

        [b dev stats] = glmfit(a,b);
        r2_noiseCeiling(i) = getR2(stats.resid,th);
    end

    figure
    set(gcf,'position',[50 50 125 225])
    mkWhisker([r2_stabShuff r2_mouseShuff r2_noShuff], ...
        [{'Stability'} {'Mouse'} {'Neither'}],[0.4 0.4 0.4; 0.4 0.4 0.4; 0.4 0.4 0.4; 0.2 0.2 0.9]);
    xlabel('Shuffled')
    ylabel('r-squared')
    set(gca,'ylim',[0.75 1.05])
    hold on
    plot(get(gca,'xlim'),[1 1],'linestyle','--','color','k')
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/ResidualAnalysis/' ...
        slind(root,[1 0]) '_R2_Shuffles'],[{'tiff'} {'pdf'}])

    
    a = repmat(eye(9),[10 10]);
    a(1:81,1:81) = 0;
    samePartSquare = rsmResid(logical(a));
    a = repmat(eye(9),[10 10]);
    a(82:90,82:90) = 0;
    samePartDiffEnv = rsmResid(logical(a));


    figure
    set(gcf,'position',[50 50 175 275])
    doColors = jet(2).*0.75+0.25;    
    doColors = doColors([2 1],:);
    mkWhisker([{samePartSquare} {samePartDiffEnv}],[{'Def->Square'} {'Def->Other Def'}],doColors)
    set(gca,'ylim',[-1 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--')
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/ResidualAnalysis/' ...
        slind(root,[1 0]) '_ResidPartitionSim'],[{'tiff'} {'pdf'}])
    [pval h stat] = signrank(samePartSquare)


    [pval h stat] = signrank(samePartDiffEnv)


% 
% 
%     [sb sdev sstats] = glmfit([ts],th);
%     [smb smdev smstats] = glmfit([ts],tm);
%     
%     [b dev stats] = glmfit([smstats.resid],sstats.resid);
end