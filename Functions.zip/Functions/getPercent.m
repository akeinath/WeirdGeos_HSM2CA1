function v = getPercent(av,p)
    av(isnan(av)) = [];
    av = sort(av,'ascend');
    v = av(nanmax(round(p.*length(av)),1));
end