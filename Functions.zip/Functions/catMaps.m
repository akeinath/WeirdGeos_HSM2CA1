function out = catMaps(alloMaps)
    alloMaps = cat(2,alloMaps,nan([length(alloMaps(:,1,1,1)) 1 size(alloMaps,3) size(alloMaps,4)]));
    out = nan(length(alloMaps(:,1,1,1)),length(alloMaps(1,1,1,:)).*length(alloMaps(1,:,1,1)),length(alloMaps(1,1,:,1)));
    for si = 1:length(alloMaps(1,1,1,:))
        for k = 1:length(alloMaps(1,1,:,1))
            out(:,(si-1).*length(alloMaps(1,:,1,1))+1:(si).*length(alloMaps(1,:,1,1)),k) = ...
                alloMaps(:,:,k,si)./nanmax(nanmax(alloMaps(:,:,k,si)));
        end
    end
end