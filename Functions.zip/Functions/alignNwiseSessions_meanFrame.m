function alignNwiseSessions(paths,nFold,iters,byHand)
    close all
    if nargin < 2 || isempty(nFold)
        nFold = inf;
    end
    
    warning ('off','all');
    
    
    if nargin < 3 || isempty(iters)
        iters = 1;
    end
    
    if nargin < 4 || isempty(byHand)
        byHand = false;
    end
    
    clc
    fprintf('\n')
    %%% Reliability constaint
    
    %% Split by animal
    piece = [];
    ag = [];
    spiece = [];
    for i = 1:length(paths)
        ind = find(ismember(paths{i},'/\'),1,'last')-1;
        piece = [piece; {paths{i}(1:ind)}];
        spiece = [spiece; {paths{i}(ind+2:end-4)}];
    end
    upiece = unique(piece);
    
    for mi = 1:length(upiece)
        clc
        fprintf(['\n\n****************************************\n\tMouse:  ' (upiece{mi}) '\n\n'])
        
        isM = find(ismember(piece,upiece(mi)));
        sessions = paths(isM);      
        
        
        if nFold > 2
            nFold = length(sessions); %%%% Align All Sessions
        end
        
        if nFold > length(sessions)
            continue
        end
        
        combs = nchoosek(1:length(sessions),nFold);

%         %%% Sliding temporal window
%         combs = repmat(1:length(sessions),[length(sessions) 1]);
%         for i = 1:length(sessions)
%             combs(i,:) = circshift(combs(i,:),[0 -(i-1)]);
%         end
%         combs(end-nFold+2:end,:) = [];
%         combs = combs(:,1:nFold);
       
        %%%%%%% LOADING DATA HERE

        meanFrames = repmat({[]},[1 length(sessions)]);
        allPrepped = repmat({[]},[1 length(sessions)]);
        for si = 1:length(sessions)
            fprintf(['\t\tSession:  ' sessions{si}(find(ismember(sessions{si},'\/'),1,'last')+1:end) '\n'])
            ref = load(sessions{si},'calcium','processed');   %%%%%%% LOADING
            meanFrames{si} = ref.calcium.meanFrame;
            prepped = ref.calcium.SFPs .* ...
                    bsxfun(@gt,ref.calcium.SFPs,0.5.*nanmax(nanmax(ref.calcium.SFPs,[],1),[],2)); % originally 0.5
%             prepped = ref.calcium.SFPs.^(2);
            allPrepped{si} = permute(prepped,[3 1 2]); %msExtractSFPs(ref.calcium);
            if isfield(ref.processed,'exclude')
                allPrepped{si} = allPrepped{si}(ref.processed.exclude.SFPs,:,:);
            end
            if si == 1
                ref = load(sessions{si},'alignment');
                if nFold == 2
                    oldAlignmentMap = repmat({[]},[length(isM) length(isM)]);
                else
                    oldAlignmentMap = repmat({[]},[length(combs(:,1))]);
                end
                if isfield(ref,'alignment')
                    alignID = help_getAlignmentID(ref.alignment,nFold,paths(isM));
% % % %                     if ~isnan(alignID)
% % % %                         oldAlignmentMap = ref.alignment(alignID).alignmentMap; % Comment out to NOT combine
% % % %                     end
                end
            end
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        %%%% Mean Frame Shit
        
        tmp = cellfun(@size,meanFrames,'uniformoutput',false);
        tmp = cat(1,tmp{:});
        matchSize = nanmax(tmp);
        for i = 1:length(meanFrames)
            while length(meanFrames{i}(1,:)) < matchSize(2)
                meanFrames{i} = cat(2,meanFrames{i},zeros(length(meanFrames{i}(:,1)),1));
                tmp = allPrepped{i};
                tmp = permute(tmp,[2 3 1]);
                tmp = cat(2,tmp,zeros(length(tmp(:,1,1)),1,length(tmp(1,1,:))));
                allPrepped{i} = permute(tmp,[3 1 2]);
            end
            
            while length(meanFrames{i}(:,1)) < matchSize(1)
                meanFrames{i} = cat(1,meanFrames{i},zeros(1,length(meanFrames{i}(1,:))));
                tmp = allPrepped{i};
                tmp = permute(tmp,[2 3 1]);
                tmp = cat(1,tmp,zeros(1,length(tmp(1,:,1)),length(tmp(1,1,:))));
                allPrepped{i} = permute(tmp,[3 1 2]);
            end
        end
        
%         allPrepped = normcorredFrameShifts(meanFrames,allPrepped);
        
        % simple supervised roi-based mean frame alignment, heirarchical
        % for speed
        
        out.SFPs = allPrepped;
        out.meanFrames = meanFrames;
%         save('forMohommad','-struct','out','-v7.3');
        
        prePrep = allPrepped;
        [allPrepped blah goodFOV] = supervisedFrameShifts_simple(meanFrames,prePrep,byHand);
  
% % %         for i = 1:length(allPrepped)
% % %             figure(1)
% % %             set(gcf,'position',[300 300 500 400])
% % %             imagesc(nanmax(permute(allPrepped{i},[2 3 1]).^2,[],3))
% % %             drawnow
% % %             pause(1)
% % %         end
% % %         
% % %         save('prepped.mat','allPrepped','goodFOV','-v7.3')
        
        mspiece = spiece(isM);
        alignmentMap = repmat({[]},[length(combs(:,1)) 1]);
        allShiftedOut = repmat({[]},[length(combs(:,1)) length(combs(1,:))]);
        for i = 1:length(combs(:,1))
            
            minPixels = 30; %%%% Minimum size of cell in pixels (usually 100-200 pixels), 
                            %%%% cells smaller are considered
                            %%%% trash or to be shifted out of the field of
                            %%%% view
            doGoodFOV = goodFOV(:,:,combs(i,:));
            doPrepped = allPrepped(combs(i,:));
            shiftedOut = repmat({[]},[1 length(doPrepped)]);
            for q = 1:length(doPrepped)
                doPrepped{q}(repmat(permute(~all(doGoodFOV,3),[3 1 2]),[length(doPrepped{q}(:,1,1)) 1 1])) = 0;
                shiftedOut{q} = nansum(nansum(doPrepped{q}~=0,2),3)<minPixels;
                doPrepped{q}(shiftedOut{q},:,:) = [];
            end

            itermap = repmat({[]},[1 iters]);
            clear ref


            tic;
            for iteration = 1:iters
                [map regStruct] = registerCells(doPrepped);
                itermap{iteration} = map;
                close all
                close all hidden
                drawnow
            end
            str = toc;
            fprintf(sprintf('\n\nTime elapsed'))

            itermap = itermap(~cellfun(@isempty,itermap));
            
            if ~isempty(itermap)
                [a b] = nanmin(cellfun(@length,itermap));
                map = itermap{b};
                alignmentMap{i} = map;
            end

            eff = length(alignmentMap{i}(:,1)) ./ ...
                nanmax(cellfun(@size,doPrepped,repmat({[1]},[size(doPrepped)])));
            fprintf(['\n\n\t\t**** ' sprintf('(%i,%i)',[i,length(combs(:,1))]) ' Time: ' ...
                sprintf('%0.3f',str) ' sec **** Effeciency: ' num2str(eff) ' ****\n\n'])


            % handle the shifted-outs
            for q = 1:length(shiftedOut)
                tmp = cumsum(shiftedOut{q});
                tmp(shiftedOut{q}) = [];
                for j = 1:length(alignmentMap{i}(:,1))
                    if alignmentMap{i}(j,q)~=0
                        alignmentMap{i}(j,q) = alignmentMap{i}(j,q) + ...
                            tmp(alignmentMap{i}(j,q));
                    end
                end
            end
            allShiftedOut(i,:) = shiftedOut;

        end

        if nFold == 2
            nASO = repmat({[]},length(sessions));
            nm = repmat({[]},length(sessions));
            for i = 1:length(combs(:,1))
                best = [alignmentMap(i) oldAlignmentMap(combs(i,1),combs(i,2))];
                best = best(~cellfun(@isempty,best));
                if isempty(best)
                    continue
                end
                [a b] = nanmin(cellfun(@length,best));
                nm{combs(i,1),combs(i,2)} = best{b};
                nASO{combs(i,1),combs(i,2)} = allShiftedOut(i,:);
            end
            alignmentMap = nm;
            allShiftedOut = nASO;
        else
            nm = repmat({[]},[length(combs(:,1)) 1]);
            for i = 1:length(combs(:,1))
                best = [alignmentMap(i) oldAlignmentMap(i)];
                best = best(~cellfun(@isempty,best));
                if isempty(best)
                    continue
                end
                [a b] = nanmin(cellfun(@length,best));
                nm{i} = best{b};
            end
            alignmentMap = nm;
        end
        
        ref = load(sessions{1});
        if isfield(ref,'alignment')
            doInd = help_getAlignmentID(ref.alignment,nFold,paths);
            if isnan(doInd)
                doInd = length(ref.alignment)+1;
            end
        else
            doInd = 1;
        end

        if isfield(ref,'alignment')
            if ~isfield(ref.alignment,'shiftedOut')
                tmp = repmat({{[]}},[size(ref.alignment)]);
                [ref.alignment.shiftedOut] = tmp{:};
            end
        end

        % eliminate previous alignments
        if isfield(ref,'alignment')
            doInd = 1;
            ref = rmfield(ref,'alignment');
        end
        
        ref.alignment(doInd).alignmentMap = alignmentMap;
        ref.alignment(doInd).combs = combs;
        ref.alignment(doInd).sessions = sessions;
        ref.alignment(doInd).nFold = nFold;
        ref.alignment(doInd).shiftedOut = allShiftedOut;
        if nFold == length(sessions)
            ref.alignment(doInd).aam = itermap;
            ref.alignment(doInd).regDetails = regStruct;
        end
        save(sessions{1},'-struct','ref','-v7.3');
    end
end





















