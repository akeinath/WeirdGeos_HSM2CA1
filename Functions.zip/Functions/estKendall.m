function vals = estKendall(A,B)
    a = getTri(A);
    b = getTri(B);
    isGood = ~isnan(a)&~isnan(b);
    a = a(isGood);
    b = b(isGood);
    
    nsims = 100;
    vals = nan(nsims,1);
    tic
    for sim = 1:nsims
        doInds = randperm(length(a));
        vals(sim) = corr(a(doInds(1:1000)),b(doInds(1:1000)),'type','kendall');
    end
    toc
    vals = nanmean(vals);
end