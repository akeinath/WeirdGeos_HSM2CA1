function batchPlotMaps(paths,doS)


    warning off all
    
    clc
    fprintf('\n\t\t\t*********Plotting Batched Maps********\n\n');
    
    for mi = 1:length(paths)
        close all
        drawnow
        fprintf(['\n' paths{mi}]);
        s = load(paths{mi},'maps','SFPs');
            
        if nargin < 2 || isempty(doS)
            doS = 1:size(s.maps,4);
        end


        slashInds = find(ismember(paths{mi},'/\'));
        root = ['Plots/BatchedAnalyses/' paths{mi}(slashInds(end)+1:end-4)];
        
%         %%% Preprocess and canonically order
%         [canonOrder b] = unique(envs(2:end));
%         canonOrder = [canonOrder([1:7 9:10]); canonOrder(8)];
%         canonOrder = [1; [b([1:7 9:10]); b(8)]+1];
%         
%         %reorder
%         um = um(:,:,:,canonOrder);
%         blocked = blocked(canonOrder);
%         envs = envs(canonOrder);
%         
        try
            um = permute(s.maps.smoothed(:,:,:,doS),[2 1 3 4]);     
        catch
            fprintf('\n\t\t\t-Queried sessions not available')
        end
        numSessions = nansum(~permute(all(all(isnan(um),1),2),[4 3 1 2]),1);
        
        % Pad y-axis
        um = cat(2,um,nan([size(um,1) 2 size(um,3) size(um,4)]));
        
        allBounds = sfp2bounds(s.SFPs(:,:,:,doS));

        %%% Normed
        catMaps = nan(length(um(:,1,1,1)),length(um(1,1,1,:)).*length(um(1,:,1,1)),length(um(1,1,:,1)));
        for si = 1:length(um(1,1,1,:))
            for k = 1:length(um(1,1,:,1))
                catMaps(:,(si-1).*length(um(1,:,1,1))+1:(si).*length(um(1,:,1,1)),k) = ...
                    um(:,:,k,si)./nanmax(nanmax(um(:,:,k,si)));
            end
        end
        [a b] = sort(numSessions,'descend');
        catMaps = catMaps(:,:,b(a>nanmax(a).*(2./3))); %sort by number of registered sessions
        allBounds = allBounds(b(a>nanmax(a).*(2./3)),:); %sort by number of registered sessions
%         help_plotOut(catMaps,[root '/ContinuousMaps/Normed_WithinSession_Sessions-' num2str(doS(1)) '-' num2str(doS(end))],allBounds)
        
        catMaps = nan(length(um(:,1,1,1)),length(um(1,1,1,:)).*length(um(1,:,1,1)),length(um(1,1,:,1)));
        for si = 1:length(um(1,1,1,:))
            for k = 1:length(um(1,1,:,1))
                catMaps(:,(si-1).*length(um(1,:,1,1))+1:(si).*length(um(1,:,1,1)),k) = um(:,:,k,si);
            end
        end
        catMaps = catMaps(:,:,b(a>nanmax(a).*(2./3))); %sort by number of registered sessions
        help_plotOut(catMaps,[root '/ContinuousMaps/Normed_AcrossSessions_Sessions-' num2str(doS(1)) '-' num2str(doS(end))],allBounds)

    end
end

function help_plotOut(catMaps,root,sfpBounds)

    if nargin < 3 || isempty(sfpBounds)
        doSize = [10 1];
        for gi = 1:floor(length(catMaps(1,1,:))./prod(doSize))
            figure
            set(gcf,'position',[50 50 fliplr(doSize).*[200 20].*4])
            axis tight
            for k = 1:prod(doSize)
                try
                    dm = catMaps(:,:,(gi-1).*prod(doSize)+k);
                    subplot(doSize(1),doSize(2),k)
                    imagesc(dm)
                    axis equal
                    axis off
                    alpha(double(~isnan(dm)))
                end
            end
            saveFig(gcf,[root '/Part_' num2str(gi)],[{'pdf'} {'tiff'}])
            close all
            drawnow;
        end
    else

        ratio = ceil(size(catMaps,2)./size(catMaps,1));
        doSFPColor = cool(size(sfpBounds,2));
        doSize = [10];
        for gi = 1:floor(length(catMaps(1,1,:))./prod(doSize))
            figure
            set(gcf,'position',[50 50 [ratio+1 doSize].*20.*5])
            axis tight
            for k = 1:prod(doSize)
                try
                    dm = catMaps(:,:,(gi-1).*prod(doSize)+k);
                    subplot(doSize(1),ratio+1,(k-1).*(ratio+1)+1:(k).*(ratio+1)-1)
                    imagesc(dm)
                    axis image
                    axis off
                    alpha(double(~isnan(dm)))
                    subplot
                    subplot(doSize(1),ratio+1,(k).*(ratio+1))
                    hold on
                    for si = 1:size(sfpBounds,2)
                        tmp = sfpBounds{(gi-1).*prod(doSize)+k,si};
                        for q = 1:length(tmp)
                            plot(tmp{q}(:,1),tmp{q}(:,2),'color',doSFPColor(si,:))
                        end
                    end
                    set(gca,'xlim',[0 35],'ylim',[0 35]) % assume [35 35] cutout SFP size
                end
            end
            saveFig(gcf,[root '/Part_' num2str(gi)],[{'pdf'} {'tiff'}])
            close all
            drawnow;
        end
    end
end
































 