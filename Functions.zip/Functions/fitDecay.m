function aP = fitDecay(d)
    
%     d(d(:,1)>1.6,:) = [];
    options = optimoptions('fmincon','Display','off');
    aP = nan(500,2);
    for si = 1:500
        doD = d(randi(length(d),[length(d) 1]),:);
        aP(si,:) = fmincon(@(p)help_expFit(doD,p),[1 1],[],[],[],[],[],[],[],options);
    end
    
    close all
    figure
    plot(d(:,1),d(:,2),'linestyle','none','color',[0.5 0.5 0.5], ...
        'markeredgecolor',[0.5 0.5 0.5],'marker','o','markersize',3)
    hold on
    xlim = get(gca,'xlim');
    steps = [xlim(1):0.01:xlim(2)];
    val = nanmedian(aP(:,2)).*exp(steps.*-nanmedian(aP(:,1)));
    plot(steps,val,'linestyle','-','color','k','linewidth',1.5)
    val = getPercent(aP(:,2),0.25).*exp(steps.*-getPercent(aP(:,1),0.25));
    plot(steps,val,'linestyle','--','color','k','linewidth',1.5)
    val = getPercent(aP(:,2),0.75).*exp(steps.*-getPercent(aP(:,1),0.75));
    plot(steps,val,'linestyle','--','color','k','linewidth',1.5)
end

function mse = help_expFit(d,p)
    val = p(2).*exp(d(:,1).*-p(1));
    mse = nanmean((d(:,2)-val).^2);
end
