function a = mmnorm(a)
    a = bsxfun(@minus,a,nanmin(nanmin(a,[],1),[],2));
    a = bsxfun(@rdivide,a,nanmax(nanmax(a,[],1),[],2));
end