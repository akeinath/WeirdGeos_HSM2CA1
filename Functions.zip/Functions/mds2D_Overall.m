function eigVal = mds2D(mat,labels,root)

    close all
    drawnow
    
    %%% Multidimensional Scaling 2D
    if iscell(mat)
        tmp = cellfun(@nanmean,mat);
    else
        tmp = nanmean(mat,3);
    end
    
    tmp = nanmax(tmp,tmp');
    tmp(logical(eye(size(tmp)))) = 1;
    tmp = 1-(tmp).*1;
    
    [mdssim stress] = mdscale(tmp,2);
    
    envLabels = labels;
%     blah = hsv(8);
%     partitionColors = [blah(1:3,:); blah(8,:); 1 1 1; blah(4,:); ...
%         blah(7,:); blah(6,:) ; blah(5,:)].*0.9+0.1;
% 
%     partitionColors = [0 0.5 0.9; 0.25 0.65 0.9; 0.5 0.8 0.9; ...
%         0 0 0.9; 0.25 0.25 0.9; 0.5 0.5 0.9; ...
%         0.5 0 0.9; 0.65 0.25 0.9; 0.8 0.5 0.9];
    
    %%% Combined Figure
    lims = [round(nanmax(abs(mdssim(:))).*10)./10 + 0.1].*[-1 1];
    
    figure
    set(gcf,'position',[50 50 400 400])
    scatter(mdssim(:,1),mdssim(:,2),50,zeros(length(mdssim(:,1)),3),'filled')
    for i = 1:length(labels)
        text(mdssim(i,1),mdssim(i,2),['  ' labels{i}])
    end
    set(gca,'color',[1 1 1],'xlim',lims ,'ylim',lims)
    axis square
    axis equal
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color',[0.5 0.5 0.5])
    plot([0 0],get(gca,'ylim'),'linestyle','--','color',[0.5 0.5 0.5])
    ylabel('MDS Dim 2 (a.u.)');
    xlabel('MDS Dim 1 (a.u.)');
    text(nanmax(get(gca,'xlim')).*0.6,nanmax(get(gca,'ylim')).*0.9,sprintf('Stress = %0.4f',[stress]));

    checkP(root);
    saveFig(gcf,[root '_Overall'],[{'pdf'} {'tiff'}]);
    
end