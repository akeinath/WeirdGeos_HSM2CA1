function val = getRSA(a,b)

    a = getTri(nanmean(a,3));
    b = getTri(nanmean(b,3));
        
    val = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type','Kendall');

end