function cm = biColor()
    cm = 0.0+1.*[linspace(1,0,50)' linspace(0.75,0,50)'.^(1./1.5) ones(50,1).*0; ...
        ones(50,1).*0 linspace(0,0.75,50)'.^(1./1.5) linspace(0,1,50)'];
    cm = cm(:,[1 3 2]);
end