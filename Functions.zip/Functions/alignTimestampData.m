function alignTimestampData(paths,varargin)
    clc
    close all
    drawnow
    
    warning off all
    if isempty(gcp)
        parpool('local',7);
    end
    pctRunOnAll warning off all
    
    
    fprintf(['Aligning timestamp data and creating <processed> :\n']);
    tmp = [repmat({'\n\t'},[1 length(varargin)]); varargin];
    fprintf(cat(2,tmp{:},'\n\n'))
    
    envSize = 75;
    
    for p = paths'
        s = load(p{1});
        
        fprintf(['\t' num2str(p{1}) '\n'])   
        
        posFrames = s.pos.ts(:,1:2); %bsxfun(@plus,[s.pos.ts(:,1:2)],[1 0]);
        traceFrames = s.calcium.ts(:,1:2); %bsxfun(@plus,[s.calcium.ts(:,1:2)],[1 0]);
        
        unP = s.pos.p(:,1:2)';
        unP = bsxfun(@minus,unP,nanmin(unP')');
        unP = bsxfun(@times,unP,nanmax(envSize./nanmax(unP(:)')));
        
        unX = interp1q(posFrames(:,2),unP(1,:)',traceFrames(:,2));
        unY = interp1q(posFrames(:,2),unP(2,:)',traceFrames(:,2));
        
        s.processed.p = interpNaNs([unX'; unY']')';
%         s.valid.traceFrames = traceFrames;
%         s.valid.posFrames = posFrames;
        
        save(p{1},'-struct','s','-v7.3');
    end
end