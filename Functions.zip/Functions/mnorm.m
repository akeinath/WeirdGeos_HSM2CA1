function m = mnorm(m)
%     m = m./repmat(nanmax(nanmax(nanmax(m,[],1),[],2),[],4),[size(m,1) size(m,2) 1 size(m,4)]);
m = m./repmat(nanmax(nanmax(m,[],1),[],2),[size(m,1) size(m,2)]);
end