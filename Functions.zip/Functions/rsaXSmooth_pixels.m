function [hs ms asFits asJNC] = rsaXSmooth_pixels(root,allHumanMaps,m)

    stepSize = 0.25;
    doHumanSmooth = [stepSize:stepSize:6];
    doMouseSmooth = [-1 stepSize:stepSize:6];
    asFits = nan(length(doHumanSmooth),length(doMouseSmooth));
    for mi = 1:length(doMouseSmooth)
        clear sm allMouseMaps predictedHumanMaps thRSM
        [~, ~, sm] = m2rsm(m,doMouseSmooth(mi),true,false);
        allMouseMaps = [{cat(3,sm{:})}];
        predictedHumanMaps = predictMaps(allHumanMaps(end),allMouseMaps(end));
        [~, ~, ~, tpRSM] = m2rsm(predictedHumanMaps,-1,true,true);
        
        for hi = 1:length(doHumanSmooth)
            [~, ~, ~, thRSM] = m2rsm(allHumanMaps(end),doHumanSmooth(hi),true,true);
            asFits(hi,mi) = estKendall(thRSM,tpRSM);
        end
    end


    figure
    set(gcf,'position',[50 50 250 250])
    imagesc(asFits(:,:,1))
    set(gca,'xtick',[1:length(doMouseSmooth)],'xticklabel',doMouseSmooth,...
        'ytick',[1:length(doHumanSmooth)],'yticklabel',doHumanSmooth)
    xlabel('CA1 map smoothing')
    ylabel('HSM map smoothing')
    colormap(cool)
    colorbar
    title('Predicted Fit (Pixel-wise)')
    saveFig(gcf,'Plots/Experiment_1/Summary/Smoothing_Pixelwise',[{'tiff'} {'pdf'}])
    drawnow

    a = asFits(:,:,1); %-asFits(:,:,1);
    [x y] = find(a==nanmax(a(:)));

    hs = doHumanSmooth(x);
    ms = doMouseSmooth(y);

    fprintf(sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));

    outP = ['Stats/' root '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    fprintf(fid,sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));
    fclose(fid);
end
