function [fits] = shRSA(root,varargin)
    ref = varargin{1};
    comps = varargin(2:end);

    minS = nanmin(cellfun(@size,varargin,repmat({3},size(varargin))));
    nsims = 1000;
    fits = nan(nsims,length(comps));
    noiseCeiling = nan(nsims,2,length(varargin));
    jointNoiseCeiling = nan(nsims,2,length(comps));

    for i = 1:length(comps)
        [fits(:,i) jointNoiseCeiling(:,:,i)] = help_shRSA(ref,comps{i},minS,nsims);
    end


    figure()
    set(gcf,'position',[50 50 75+25.*length(comps) 225])
    tmp = jet(length(comps)).*0.75+0.25;
    mkWhisker(fits,[],tmp([2 1],:));
    set(gca,'ylim',[-0.5 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    
    doPerc = 0.025;
    jnc = [];
    for i = 1:length(jointNoiseCeiling(1,1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,1,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,1,i),1-doPerc)]];
    end
    
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    ylabel('Kendalls Tau')
    xlabel('Compared RSM')
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')

    outP = ['Stats/' root '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    ntests = nchoosek(length(fits(1,:)),2);
    for i = 1:length(fits(1,:))
        for j = i+1:length(fits(1,:))

            fprintf(fid,['\nGroups:  ' num2str(i) ' vs. ' num2str(j)]);

            actual = abs(nanmean(fits(:,i))-nanmean(fits(:,j)));

% % %             null = nan(10000,1);
% % %             for q = 1:10000
% % %                 tmp = [fits(:,i); fits(:,j)];
% % %                 tmp = tmp(randperm(length(tmp)));
% % %                 tmp = [tmp(1:length(tmp)./2) tmp(length(tmp)./2+1:end)];
% % %                 null(q) = abs(nanmean(tmp(:,1))-nanmean(tmp(:,2)));
% % %             end
% % %             pval = nanmean(actual<null);

            a = fits(:,i);
            b = fits(:,j);
            c = a(:)<[b(:)]';
            pval = nanmean(c(:));
            pval = nanmin(pval,1-pval).*2;
        
            text(1.5,1.05,sprintf('p = %0.4f',pval.*ntests),'fontname','arial','fontsize',9,'horizontalalignment','center')

            str = sprintf('; \tActual = %0.3f, p = %0.4f, p (bonferroni) = %0.4f',[actual pval pval.*ntests]);
            fprintf(fid,str);
        end

        a = fits(:,i);
        b = jointNoiseCeiling(:,1,i);
        c = a(:)<[b(:)]';
        pval = nanmean(c(:));
        pval = nanmin(pval,1-pval).*2;
        text(1.5,-0.5+i.*0.075,sprintf('p_%i = %0.4f',[i pval.*ntests]),'fontname','arial','fontsize',9,'horizontalalignment','center')
    end
    fclose(fid);

    
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/' slind(root,[1 0])],[{'tiff'} {'pdf'}])
    drawnow


    null_random = nan([nsims 1]);
    for i = length(comps)
        for si = 1:nsims
            tref = ref;
            reorder = randperm(size(ref,1));
            tref = tref(reorder,reorder,:);
            [null_random(si)] = help_shRSA(tref,comps{i},minS,1);
        end
    end
    
    figure()
    set(gcf,'position',[50 50 400 225])
    h = groupHist([{null_random} {jointNoiseCeiling(:,1,end)} {fits(:,end)}],[-0.2:0.025:1]);
    plot([0 0],get(gca,'ylim'),'linestyle','--','color','k')
    xlabel('Kendalls Tau')
    ylabel('Proportion of resamplings')
    legend(h,[{'Shuffled null'} {'Joint noise ceiling'} {'Actual'}],'location','northwest')
    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/' slind(root,[1 0]) '_GroupHist'],[{'tiff'} {'pdf'}])
    drawnow
    
    
    isGood = ~all(isnan(nanmean(varargin{1},3)));
    figure
    set(gcf,'position',[50 50 300.*length(comps) 250])
    for i = 1:length(varargin)
        subplot(1,length(varargin),i)
        imagesc(nanmean(varargin{i}(isGood,isGood,:),3))
        alpha(double(~isnan(nanmean(varargin{i}(isGood,isGood,:),3))))
        colorbar('location','southoutside');
        colormap inferno
        axis equal
        axis off
    end

    saveFig(gcf,['Plots/' slind(root,[0 1]) '/Summary/' slind(root,[1 0]) '_RSMs'],[{'tiff'} {'pdf'}])
    drawnow
end





















