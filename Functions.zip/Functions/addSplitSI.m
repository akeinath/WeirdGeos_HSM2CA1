function addSplitSI(paths)


    % 0.999 0.0017

    across = struct; %prepAcross();
%     across = prepAcross();
    
    warning off all
    
    clc
    fprintf('\n\t\t\t*********Running batched analyses********\n\n');
    vals = [];
    for mi = 1:length(paths) %:-1:1
        
        close all
        drawnow
        
        fprintf(['\n\n\t\t\t' macheck(paths{mi},true)])
        fprintf('\n\n\tLoading data...')
        tic
        s = load(paths{mi}); %'trace'
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    
        for si = 1:length(s.position)

            dp = s.position{si};
            dt = s.trace{si};
            
            fprintf(['\n\t\t\t\t***Session ' num2str(si) '***'])

            fprintf(['\n\t\tComputing SI... '])
            [a b] = mkTraceMaps(dp,dt,[],[15 15]);
    
            actual_si = getSI(a,b)';
            
            tic
            nsims = 100;
            null_si = nan(length(actual_si),nsims);
            for sim = 1:nsims
                cdp = circshift(dp,[0 30.*60.*2 + randi(length(dp)-30.*60.*4)]);
                [a b] = mkTraceMaps(cdp,dt,[],[15 15]);
                null_si(:,sim) = getSI(a,b);
            end
            tmp = toc;
            fprintf('  %0.3fs.',tmp);

            s.si.actual{si} = actual_si;
            s.si.null_si{si} = null_si;
            s.si.pval{si} = nanmean(bsxfun(@ge,null_si,actual_si),2);
            s.si.pval{si}(isnan(actual_si)) = nan;

            %%%%%

            fprintf(['\n\t\tComputing split-half stability... '])
            isHalf = [1:length(dp)]<length(dp)./2;
            a = mkTraceMaps(dp,dt,isHalf,[15 15]);
            b = mkTraceMaps(dp,dt,~isHalf,[15 15]);
            actual_shc = mcr(a,b);
            
            tic
            nsims = 10;
            null_shc = nan(length(actual_si),nsims);
            for sim = 1:nsims
                cdp = circshift(dp,[0 30.*60.*2 + randi(length(dp)-30.*60.*4)]);
                [a b] = mkTraceMaps(cdp,dt,[],[15 15]);
                null_shc(:,sim) = getSI(a,b);
            end
            tmp = toc;
            fprintf('  %0.3fs.',tmp);

            s.shc.actual{si} = actual_shc;
            s.shc.null_si{si} = null_shc;
            s.shc.pval{si} = nanmean(bsxfun(@ge,null_shc,actual_shc),2);
            s.shc.pval{si}(isnan(actual_shc)) = nan;
        end

        save(paths{mi},'-struct','s','-v7.3');

    end
end































 