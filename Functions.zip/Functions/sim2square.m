function sim2square(varargin)
    [envLabel env_blocked] = envStuff();

    doRow = ismember(envLabel,{'OpenField'});

    order = [];
    amt = [];
    for i = 1:length(varargin)
        a = nanmean(varargin{i},3);
        [tmp, inds] = sort(a(doRow,:));
        order = [order; inds];
        amt = [amt; tmp];
    end

    amt = amt-nanmin(amt,[],2);
    amt = amt./nanmax(amt,[],2);


    figure
    set(gcf,'position',[50 50 900 200.*length(varargin)])
    for i = 1:length(order(:,1))
        to = env_blocked(order(i,:),:);
        for j = 1:9
            block2patch(amt(i,j),(i./4)+randn.*0.03,to(j,:),0.02)
        end
    end
    set(gca,'ydir','reverse','ylim',[0.1 length(varargin).*0.3])
    hold on
    pbaspect([3 1 1])
    saveFig(gcf,'Plots/Experiment_1/Summary/Context_Similarity_Ordering',[{'tiff'} {'pdf'}])
end