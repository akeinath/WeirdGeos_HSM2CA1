function linM = m2linM(m)
    linM = nan(size(m));

    %%%%%%% Make geometric place cells
    for k = 1:size(m,3)

        nCons = poissrnd(4,1,1);
        while nCons<2 || nCons>8
            nCons = poissrnd(4,1,1);
        end
        inds = randperm(size(m,3));
        doCon = inds(1:nCons);

        linM(:,:,k,:) = prod(m(:,:,doCon,:),3).^(1./length(doCon));
    end
end