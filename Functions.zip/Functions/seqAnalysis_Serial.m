function across = seqAnalysis_Serial(s,root,across)

% % %     bvcPrecompP = ['MatlabData/BVC_Trace_Precomputes/' slind(root,[2 0])];
% % %     if exist([bvcPrecompP '.mat'])~=2
% % %         bvcTraces = genBVCs(s.position,s.blocked);
% % %         checkP(bvcPrecompP);
% % %         save(bvcPrecompP,'bvcTraces','-v7.3');
% % %     else
% % %         tic
% % %         fprintf(['\n\t\tLoading Precomputed BVC traces...'])
% % %         load(bvcPrecompP,'bvcTraces');
% % %         tmp = toc;
% % %         fprintf('  %0.3fs.',tmp);
% % %     end


%     doGammas = [0.995 0.95 0.8 0.6 0.4];
%     doAlphas = [(50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5)];
%     doTimestep = [1 5 15 30 60];

%     doGammas = [0.999 0.95 0.90];
%     doAlphas = [(50./30).*10.^(-1) (50./30).*10.^(-2) (50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5) (50./30).*10.^(-6)];
%     doTimestep = [1 150];

    doGammas = [0.999 0.95 0.90 0.8 0.6];
    doAlphas = [(50./30).*10.^(-4) (50./30).*10.^(-3).*5 (50./30).*10.^(-3) (50./30).*10.^(-3)./5 (50./30).*10.^(-2)];
    doTimestep = [1 3 10 30 60 150];

%     doGammas = [0.999 0.95 0.90];
%     doAlphas = [(50./30).*10.^(-3)];
%     doTimestep = [1 15 30 60];

    doChoices = combvec(doGammas,doAlphas,doTimestep);
    lrLabels = cellfun(@num2str,num2cell(1:length(doChoices(1,:))),'uni',0);

%     plot4DMaps(sr(1).srMaps(:,:,:,1:10),['Plots/ModelComparison/SR_Examples_' slind(root,[2 0]) ...
%             '_g' num2str(gamma.*1000) '_a' num2str(round(alpha.*10.^7)) '_t' num2str(ts)]);

    for i = 1:(length(s.envs)-1)./10
        fprintf(['\n\n\t\t***** Separated Sequence Analyses: ' num2str(((i-1)./10)+1) ' *****'])

        allMeasures = [{'partitioned_pearson'} {'partitioned_pfr'}];
            
        doS = [(i-1).*10+1:(i).*10+1];

% % %         % BVC predictions
% % %         sBVC = t2p(s.position(doS),s.maps.smoothed(:,:,:,doS(1)),bvcTraces(doS));
% % %         sBVC.maps = removeBlocked(sBVC.maps(1:15,1:15,:,:),s.blocked(doS));
% % %         sim.bvc2p = getPairwiseSim(sBVC,allMeasures);
% % %         sBVC.maps = removeBlocked(sBVC.doFitMaps(1:15,1:15,:,:),s.blocked(doS));
% % %         sim.bvc = getPairwiseSim(sBVC,allMeasures);
% % % 
% % %         % Boundary-tethered Predictions
% % %         sBT = boundaryTethered(s.maps.smoothed(:,:,:,doS),s.position(doS), ...
% % %             s.trace(doS),1);
% % %         sBT.maps = removeBlocked(sBT.maps(1:15,1:15,:,:),s.blocked(doS));
% % %         sim.bt = getPairwiseSim(sBT,allMeasures);
% % % 
% % %         % Allocentric prediction
% % %         fprintf('\n\n\t\tComputing allocentric (stable) model...')
% % %         sAllo.maps = removeBlocked(repmat(s.maps.smoothed(1:15,1:15,:,doS(1)), ...
% % %             [1 1 1 length(doS)]),s.blocked(doS));
% % %         sAllo.trace = repmat(s.trace(doS(1)),[1 length(doS)]);
% % %         sAllo.p = repmat(s.position(doS(1)),[1 length(doS)]);
% % %         sim.allo = getPairwiseSim(sAllo,allMeasures);

        % Actual data
        fprintf('\n\n\t\tComputing actual data comparisons...')
        sAct.maps = s.maps.smoothed(:,:,:,doS);
        sAct.trace = s.trace(doS);
        sAct.p = s.position(doS);
        sim.actual = getPairwiseSim(sAct,allMeasures);

% % %         %%% add to the across comparisons
% % %         % parameter choices
% % %         for k = 1:length(doChoices(1,:))
% % %             clear sr
% % %             gamma = doChoices(1,k);
% % %             alpha = doChoices(2,k);
% % %             ts = doChoices(3,k);
% % %             srPrecompP = ['MatlabData/SR_Trace_Precomputes/FullSearch/' slind(root,[2 0]) ...
% % %                 '_g' num2str(gamma.*1000) '_a' num2str(round(alpha.*10.^7)) '_t' num2str(ts)];
% % %             if exist([srPrecompP '.mat'])~=2
% % %                 [srTraces srMaps] = genBVC_sr(s.position,bvcTraces,gamma,alpha);
% % %                 sr.srTraces = srTraces;
% % %                 sr.srMaps = srMaps;
% % %                 checkP(srPrecompP);
% % %                 save(srPrecompP,'srTraces','srMaps','-v7.3');
% % %             else
% % %                 tic
% % %                 fprintf(['\n\t\tLoading Precomputed SR traces...'])
% % %                 if exist('sr')~=1
% % %                     sr = load(srPrecompP,'srTraces','srMaps');
% % %                 else
% % %                     load(srPrecompP,'srTraces','srMaps');
% % %                     sr.srTraces = srTraces;
% % %                     sr.srMaps = srMaps;
% % %                 end
% % %                 tmp = toc;
% % %                 fprintf('  %0.3fs.',tmp);
% % %             end
% % %     
% % %             doS = [(i-1).*10+1:(i).*10+1];
% % %             sBVC.maps = removeBlocked(sr.srMaps(1:15,1:15,:,doS),s.blocked(doS));
% % %             eval(['sim.bvc_sr_' lrLabels{k} ' = getPairwiseSim(sBVC,allMeasures);']);
% % %         end


        for mi = 1:length(allMeasures)
            doMeasure = allMeasures{mi};    
            structLoc = slind(doMeasure,[1 0],'_');

% % %             tmp = splitAndOrder(sim.bt.partitioned.(structLoc),s.envs(doS));
% % %             across = structCat(across,['rsa.' structLoc '.rsm.bt'],nanmean(tmp,3));
% % %             
% % %             tmp = splitAndOrder(sim.allo.partitioned.(structLoc),s.envs(doS));
% % %             across = structCat(across,['rsa.' structLoc '.rsm.allo'],nanmean(tmp,3));
% % %             
% % %             tmp = splitAndOrder(sim.bvc.partitioned.(structLoc),s.envs(doS));
% % %             across = structCat(across,['rsa.' structLoc '.rsm.bvc'],nanmean(tmp,3));
% % %             
% % %             tmp = splitAndOrder(sim.bvc2p.partitioned.(structLoc),s.envs(doS));
% % %             across = structCat(across,['rsa.' structLoc '.rsm.bvc2p'],nanmean(tmp,3));
% % % 
% % %             % BVC-sr predictions (across alphas)
% % %             for k = 1:length(doChoices(1,:))
% % %                 eval(['tmp = splitAndOrder(sim.bvc_sr_' lrLabels{k} ...
% % %                     '.partitioned.(structLoc),s.envs(doS));']);
% % %                 across = structCat(across,['rsa.' structLoc '.rsm.bvc_sr_' lrLabels{k}], ...
% % %                     nanmean(tmp,3));
% % %             end
            
            tmp = splitAndOrder(sim.actual.partitioned.(structLoc),s.envs(doS));
            across = structCat(across,['rsa.' structLoc '.rsm.actual'],nanmean(tmp,3));
    
            across = structCat(across,['rsa.' structLoc '.label'],{slind(root,[2 0])},1);
        end

    end
end
















