function [out] = bvc(p,ref,bvcTraces)

    fprintf('\n\n\t\tComputing simple BVC model fits to place cells...')
    tic
    
    placeThreshold = 0.8;
    nPCs = size(ref,3); % size(ref,3);
    combAmt = [2 16]; % lambda = 4;
    nCons = poissrnd(4,nPCs,1);

    nBVCs = length(bvcTraces{1}(:,1));
    bvcMaps = nan(15,15,nBVCs,length(p));
    placeMaps = nan(15,15,nPCs,length(p));
    connections = repmat({[]},[nPCs 1]);
    for si = [1:length(p)]
        bvcMaps(:,:,:,si) = mkTraceMaps(p{si},bvcTraces{si},[],[15 15]);

        allFits = [];
        for k = 1:nPCs
            if si == 1
                tr = ref(:,:,k);
                if all(isnan(tr))
                    continue
                end

                fit = -inf;
                fitThresh = 1;
                fitDecline = 0.0001;
                while fit<fitThresh
                    nCons = poissrnd(4,1,1);
                    if nCons < combAmt(1) || nCons > combAmt(2)
                        fit = -inf;
                        continue
                    end
                    inds = randperm(nBVCs);
                    m = bvcMaps(:,:,inds(1:nCons),si);
                    tmp = prod(maxnorm(m),3).^(1./nCons);
                    tmp = tmp - nanmax(tmp).*placeThreshold;
                    tmp(tmp<0) = 0;
                    tmp = tmp.*500;
                    fit = corr(tr(~isnan(tr)&~isnan(tmp)), ...
                        tmp(~isnan(tr)&~isnan(tmp)));
                    fitThresh = fitThresh - fitDecline;
                end
                allFits = [allFits; fit];
                connections{k} = inds(1:nCons);
            else
                if ~isempty(connections{k})
                    m = bvcMaps(:,:,connections{k},si);
                    tmp = prod(maxnorm(m),3).^(1./length(connections{k}));
                    tmp = tmp - nanmax(tmp).*placeThreshold;
                    tmp(tmp<0) = 0;
                    tmp = tmp.*500;
                end
            end
            placeMaps(:,:,k,si) = tmp;
        end

%         close all
%         for i = 1:3:1000
%             figure(1)
%             set(gcf,'position',[50 50 800 400])
%             subplot(1,2,1)
%             for j = 1:length(walls(1,1,:))
%                 plot(walls([1 3],1,j),walls([2 4],1,j),'color','k')
%                 hold on
%             end
%             plot(p{si}(1,i),p{si}(2,i),'color','r','marker','o','markerfacecolor','r','markersize',10);
%             set(gca,'xlim',[-5 80],'ylim',[-5 80]);
% 
%             subplot(1,2,2)
%             plot([zeros(1,length(rays)); -cos(rays).*nearestBorder(:,i)'], ...
%                 [zeros(1,length(rays)); -sin(rays).*nearestBorder(:,i)'],'color','k')
%             set(gca,'ylim',[-110 110],'xlim',[-110 110]);
%             hold off
%             drawnow
%         end
    end

    out.maps = placeMaps;
    out.bvcMaps = bvcMaps;
    out.p = p;
    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end







































