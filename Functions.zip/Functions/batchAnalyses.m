function batchAnalyses(paths)

%     across = struct;
    across = prepAcross();
    
    warning off all
    
    clc
    fprintf('\n\t\t\t*********Running batched analyses********\n\n');
    
    for mi = 1:length(paths)
        close all
        drawnow
        fprintf(['\n' paths{mi}]);
%         load(paths{mi},'maps','trace','position','blocked','envs');
        s = load(paths{mi});
        slashInds = find(ismember(paths{mi},'/'));
        root = ['Plots/BatchedAnalyses/' paths{mi}(slashInds(3)+1:end-4)];
        
%         s.trace = flynerize(s.trace);
        
        %%% Preprocess and canonically order
        [canonOrder b] = unique(s.envs(2:end));
        canonOrder = [canonOrder([1:7 9:10]); canonOrder(8)];
        canonOrderNames = canonOrder;
        canonOrder = [1; [b([1:7 9:10]); b(8)]+1];
        
        %reorder
        s.canonOrder.envs = [s.envs(1); canonOrderNames];
        s.canonOrder.blocked = s.blocked(canonOrder);
        s.canonOrder.maps.smoothed = s.maps.smoothed(:,:,:,canonOrder);
        s.canonOrder.maps.unsmoothed = s.maps.unsmoothed(:,:,:,canonOrder);
        s.canonOrder.maps.sampling = s.maps.sampling(:,:,canonOrder);
        s.canonOrder.SFPs = s.SFPs(canonOrder);
        s.canonOrder.position = s.position(canonOrder);
        s.canonOrder.trace = s.trace(canonOrder);
        
        
        [a b btMaps alloMaps] = boundaryTethered(s.canonOrder.maps.smoothed,s.canonOrder.position, ...
            s.canonOrder.trace,s.canonOrder.envs);
        
        across.models.boundaryTethered = [across.models.boundaryTethered; a];
        across.models.allo = [across.models.allo; b];
        alloMaps = removeBlocked(alloMaps(1:15,1:15,:,:),s.canonOrder.blocked);
        btMaps = removeBlocked(btMaps(1:15,1:15,:,:),s.canonOrder.blocked);
        
        sim.bt = getPairwiseMapSim(btMaps,'partitioned_pearson'); %,'partitioned_pearson');
        sim.allo = getPairwiseMapSim(alloMaps,'partitioned_pearson'); %,'partitioned_pearson');
        

%         mfr = cellfun(@nanmean,s.canonOrder.trace,num2cell(2.*ones(size(s.canonOrder.trace))),'uni',0);
%         mfr = cat(2,mfr{:});
%         admfr = abs(permute(bsxfun(@minus,mfr,permute(mfr,[1 3 2])),[2 3 1]));
%         rdmfr = admfr./permute(bsxfun(@nanmax,mfr,permute(mfr,[1 3 2])),[2 3 1]);
%         outTrace = c2cTrace(s.canonOrder.trace);
        
%         tmp1 = squarify(nanmean(s.canonOrder.rsm.smoothed.pv,3));
%         tmp2 = squarify(nanmean(s.canonOrder.rsm.smoothed.pearson,3));
%         scatter(tmp1(:),tmp2(:))
        

%         s.canonOrder.rsm.smoothed = getPairwiseMapSim(s.canonOrder.maps.smoothed,'pearson','pv','pfr');
        s.canonOrder.rsm.smoothed = getPairwiseMapSim(s.canonOrder.maps.smoothed,'pearson','pv','pfr','partitioned_pfr', ...
            'c2c_pearson','partitioned_pfr','partitioned_pearson','partitioned_pv'); %,'partitioned_pearson');
%         s.canonOrder.rsm.unsmoothed = getPairwiseMapSim(s.canonOrder.maps.unsmoothed,'partitioned_pfr','partitioned_pearson','partitioned_pv');

        sim.bt = getPairwiseMapSim(btMaps(:,:,:,2:end),'pearson','pv','pfr','partitioned_pfr', ...
            'c2c_pearson','partitioned_pfr','partitioned_pearson','partitioned_pv'); %,'partitioned_pearson');
        sim.allo = getPairwiseMapSim(alloMaps(:,:,:,2:end),'pearson','pv','pfr','partitioned_pfr', ...
            'c2c_pearson','partitioned_pfr','partitioned_pearson','partitioned_pv'); %,'partitioned_pearson');
        
%         cactm = catMaps(s.canonOrder.maps.smoothed);
%         cam = catMaps(alloMaps);
%         cbtm = catMaps(btMaps);
%         
%         scalar = permute(nanmax(nanmax(nanmax(cactm,[],1),[],2),[],4),[3 4 1 2]);
%         
%         isRecorded = ~permute(all(all(isnan(s.canonOrder.maps.smoothed),1),2),[3 4 1 2]);
%         doPlot = find(nansum(isRecorded,2)>9);
%         for k = doPlot(1:10)'
%             close all
%             figure(1)
%             set(gcf,'position',[50 50 1000 300])
%             subplot(3,1,1)
%             imagesc(cactm(:,:,k))
%             alpha(double(~isnan(cactm(:,:,k))))
%             caxis([0 scalar(k)]);
%             axis off
%             subplot(3,1,2)
%             imagesc(cam(:,:,k))
%             alpha(double(~isnan(cam(:,:,k))))
%             caxis([0 scalar(k)]);
%             axis off
%             subplot(3,1,3)
%             imagesc(cbtm(:,:,k))
%             alpha(double(~isnan(cbtm(:,:,k))))
%             caxis([0 scalar(k)]);
%             axis off
%             colormap jet
%             saveFig(gcf,['Plots/ModelFits/' paths{mi}(slashInds(3)+1:end-4) ...
%                 '/Cell_' num2str(k)],[{'tiff'} {'pdf'}])
%         end
        

        doComp = nan(90,90,3);
        
        figure
        set(gcf,'position',[50 50 1200 400])
        subplot(1,3,1)
        tmp = squarify(nanmean(s.canonOrder.rsm.smoothed.partitioned.pearson,3));
        tmp = squarify(nanmean(s.canonOrder.rsm.smoothed.partitioned.pearson(10:end,10:end,:),3));
        tmp(1:length(tmp)+1:end) = nan;
        doComp(:,:,1) = tmp;
        imagesc(tmp);
        alpha(double(~isnan(tmp)));
        axis square
        axis off
        caxis([-1 1])
        colormap inferno
        subplot(1,3,2)
        tmp = squarify(nanmean(sim.bt.partitioned.pearson,3));
        tmp(1:length(tmp)+1:end) = nan;
        imagesc(tmp);
        alpha(double(~isnan(tmp)));
        axis square
        axis off
        caxis([-1 1])
        doComp(:,:,2) = tmp;
        subplot(1,3,3)
        tmp = squarify(nanmean(sim.allo.partitioned.pearson,3));
        tmp(1:length(tmp)+1:end) = nan;
        imagesc(tmp);
        alpha(double(~isnan(tmp)));
        axis square
        axis off
        caxis([-1 1])
        doComp(:,:,3) = tmp;
        
        arv = [];
        a = doComp(:,:,1);
        for i = 2:3
            b = doComp(:,:,i);
            ra = a(:);
            rb = b(:);
            good = ~isnan(ra)&~isnan(rb);
            [rval pval] = corr(ra(good),rb(good),'type','kendall');
            arv = [arv; rval pval];
        end
        across.models.fit.bt = [across.models.fit.bt; arv(1,:)];
        across.models.fit.allo = [across.models.fit.allo; arv(2,:)];

%         mds2D_envs(s.canonOrder.rsm.smoothed.pearson,s.canonOrder.envs)
        
%         across = foldAcross(across,s.canonOrder.rsm,'canonOrder.rsm');
%         
% 
%         try
%             across.canonOrder.rsm.smoothed.pearson = cat(3,across.canonOrder.rsm.smoothed.pearson,...
%                 nanmean(s.canonOrder.rsm.smoothed.pearson,3));
%         catch
%             across.canonOrder.rsm.smoothed.pearson = nanmean(s.canonOrder.rsm.smoothed.pearson,3);
%         end
%         
%         try
%             across.canonOrder.rsm.smoothed.pfr = cat(3,across.canonOrder.rsm.smoothed.pfr,...
%                 nanmean(s.canonOrder.rsm.smoothed.pfr.rel,3));
%         catch
%             across.canonOrder.rsm.smoothed.pfr = nanmean(s.canonOrder.rsm.smoothed.pfr.rel,3);
%         end
%         
%         try
%             across.canonOrder.rsm.smoothed.pv = cat(3,across.canonOrder.rsm.smoothed.pv,...
%                 nanmean(s.canonOrder.rsm.smoothed.pv,3));
%         catch
%             across.canonOrder.rsm.smoothed.pv = nanmean(s.canonOrder.rsm.smoothed.pv,3);
%         end

        
%         pfrPartAnalysis(sim,blocked,envs)
        
% % %         %%%%%%%%%% Field to field vector stuff %%%%%%%%%% 
% % %         
% % %         out = getVecFields(um,blocked,envs);
% % %         for si = 1:11
% % %             for sj = 1:11
% % %                 across.f2f{si,sj} = [across.f2f{si,sj}; out.f2f{si,sj}];
% % %                 across.pv2pv{si,sj} = cat(3,across.pv2pv{si,sj},out.pv2pv(:,:,si,sj));
% % %             end
% % %         end
% % % 
        %%%%%%%%%%%%%%%% Heterogeniety %%%%%%%%%%%%%%%%%%

% % %         outTrace = c2cTraceAnalysis(s.canonOrder.trace,s.canonOrder.blocked,s.canonOrder.envs,30); % Binning
% % %         across.c2c.trace.xc = [across.c2c.trace.xc; outTrace.acv];
%         across.c2c.trace.condProb = [across.c2c.trace.condProb; outTrace.condProb.acv];
%         saveFig(gcf,[root '/Cell2cell_Trace_Conditional_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
%         out = c2csimAnalysis(s.canonOrder.rsm.smoothed.sim,s.canonOrder.blocked,s.canonOrder.envs);
%         across.c2c.simVsBlocked = [across.c2c.simVsBlocked; out.acv];
%         saveFig(gcf,[root '/Cell2cell_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
%         
%         numClosed = cellfun(@length,s.canonOrder.blocked);
%         numClosed([1 11]) = 0;
%         for i = 1:4
%             across.c2c.closedHiSqStab{i} = [across.c2c.closedHiSqStab{i}; ...
%                 cat(1,out.hiSqStabilityPairs{numClosed==i})];
%         end
    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        



% % %         imagesc(squarify(permute(sim.c2c.pearson,[3 4 1 2])))
% % %         
% % %         figure
% % %         set(gcf,'position',[50 50 600 300])
% % %         subplot(1,2,1)
% % %         imagesc(permute(sim.c2c.pearson(1,2,:,:),[3 4 1 2]))
% % %         axis equal
% % %         subplot(1,2,2)
% % %         imagesc(permute(sim.c2c.pearson(2,1,:,:),[3 4 1 2]))
% % %         axis equal
% % %     
% % %         tmp = permute(sim.c2c.pearson,[3 4 1 2]);
% % %         allSims = nan(length(um(1,1,1,:)),length(um(1,1,1,:)),nchoosek(length(um(1,1,:,1)),2));
% % %         ind = 0;
% % %         for ki = 1:length(um(1,1,:,1))
% % %             for kj = ki+1:length(um(1,1,:,1))
% % %                 ind = ind+1;
% % %                 allSims(:,:,ind) = tmp(:,:,ki,kj);
% % %             end
% % %         end
% % %         
% % %         
% % %         isGood = true(size(sim.partitioned.pfr(:,:,1)));
% % %         isGood(~triu(true(size(isGood)))) = false;
% % %         sim.partitioned.pfr(repmat(~isGood,[1 1 length(sim.partitioned.pfr(1,1,:))])) = nan;
% % %         
% % %         [c2c cell_ids] = c2cSim(sim.partitioned.pfr,30);
% % %         [sc2c order] = sortSim(c2c);
% % %         
% % % %         sim = getPairwiseMapSim(um(1:3,1:3,:,:),'pearson','pv','partitioned_pearson');
% % %         
        
% % %         rb = repmat(blocked,[1 9])';
% % %         mds2D(nanmean(unsim.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Unsmoothed']);
% % %         mds2D(1-nanmean(unsim.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Unsmoothed']);
% % %         mds2D(nanmean(sim.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Smoothed']);
% % %         mds2D(1-nanmean(sim.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Smoothed']);
% % %         mds2D(unsim.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Unsmoothed']);
% % %         mds2D(sim.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Smoothed']);

%         figure
%         set(gcf,'position',[50 50 600 500])
%         imagesc(squarify(nanmean(sim.pearson,3)))
%         colorbar
%         axis off
%         axis square
%         alpha(double(~isnan(squarify(nanmean(sim.pearson,3)))))
%         saveFig(gcf,[root '/WholeMap_RateMapSimilarity'],[{'tiff'} {'pdf'}])

%         figure
%         set(gcf,'position',[50 50 600 500])
%         imagesc(squarify(nanmean(unsim.partitioned.pearson,3)))
%         colorbar
%         axis off
%         axis square
%         alpha(double(~isnan(squarify(nanmean(unsim.partitioned.pearson,3)))))
%         saveFig(gcf,[root '/Partition_MDS'],[{'tiff'} {'pdf'}])
    end

    root = ['Plots/BatchedAnalyses/Summary']; 
    
    figure
    set(gcf,'position',[50 50 150 225])
    plot(randn(length(across.models.fit.allo(:,1)),2)'.*0.05+bsxfun(@times,[ones(length(across.models.fit.allo(:,1)),2)],[1 2])', ...
        [across.models.fit.allo(:,1) across.models.fit.bt(:,1)]','color',[0.8 0.8 0.8],...
        'marker','o','markerfacecolor',[0.8 0.8 0.8],'markersize',1)
    hold on
    mkBow([{across.models.fit.allo(:,1)} {across.models.fit.bt(:,1)}], ...
        [{'Allocentric'} {'Boundary-tethered'}])
    ylabel('Model Fit (Kendalls Tau)')
    set(gca,'ylim',[-0.2 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    saveFig(gcf,[root '/Model_Comparison'],[{'pdf'} {'tiff'} {'jpeg'}]);
    
    figure
    set(gcf,'position',[50 50 350 225])
    plot([0 0; 0 0; 0 0; 2 2; 2 2; 2 2; 4 4; 4 4; 4 4; 6 6; 6 6; 8 8; 8 8; 8 8; 10 10; 10 10; 10 10; 12 12; 12 12; 12 12]' + ...
        bsxfun(@times,[ones(length(across.models.fit.allo(:,1)),2)],[1 2])', ...
        [across.models.fit.allo(:,1) across.models.fit.bt(:,1)]','color',[0.8 0.8 0.8],...
        'marker','o','markerfacecolor',[0.8 0.8 0.8],'markersize',3)
    hold on
    ylabel('Model Fit (Kendalls Tau)')
    set(gca,'ylim',[-0.2 1])
    hold on
    set(gca,'xlim',[0 15],'xtick',[1.5:2:15],'xticklabel',[{'QLAKCA108'} {'QLAKCA130'} ...
        {'QLAKCA150'} {'QLAKCA151'} {'QLAKCA156'} {'QLAKCA174'} {'QLAKCA175'}])
    xlabel('Mouse')
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    saveFig(gcf,[root '/Model_Comparison_Mousewise'],[{'pdf'} {'tiff'} {'jpeg'}]);
%     
    
    tmp = [];
    for i = 1:length(across.models.boundaryTethered(1,:))
        tmp = [tmp [{across.models.boundaryTethered(:,i)}; ...
            {across.models.allo(:,i)}]];
    end
    figure
    set(gcf,'position',[50 50 550 350])
    mkBow(tmp,cellfun(@upper,s.canonOrder.envs,'uni',0))
    set(gca,'ylim',[-1 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    ylabel('Rate map correlation')
    saveFig(gcf,[root '/Model_BoundaryTethered_3'],[{'pdf'} {'tiff'} {'jpeg'}]);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    mkOrderPlot(across.canonOrder.rsm.smoothed.pearson,s.canonOrder.envs)
    ylabel('Rate Map Correlation')
    saveFig(gcf,[root '/SimilarityOrder_MeanRateMapCorrelation'],[{'pdf'} {'tiff'} {'jpeg'}]);
    mkOrderPlot(across.c2c.trace.xc,s.canonOrder.envs)
    ylabel('Similarity of Trace Correlation structure')
    saveFig(gcf,[root '/SimilarityOrder_C2C_TraceCorrelationStructure'],[{'pdf'} {'tiff'} {'jpeg'}]);
    
    %%%%%% MDS Stuff %%%%%%%%%%
    
    rb = repmat(blocked,[1 9])';
    val = mds2D(nanmean(across.unum.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Unsmoothed']);
    val = mds2D(1-nanmean(across.unum.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Unsmoothed']);
    val = mds2D(nanmean(across.um.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Smoothed']);
    val = mds2D(1-nanmean(across.um.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Smoothed']);
    val = mds2D(across.unum.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Unsmoothed']);
    val = mds2D(across.um.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Smoothed']);
    
    %%%%%%%%%%%%%%%%%%%%% Firing rate stuff %%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 450 275])
    mkBow(bsxfun(@minus,across.mfr(:,2:end),across.mfr(:,1)))
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    label = cellfun(@upper,canonOrderNames','uniformoutput',false);
    label{end} = 'SQUARE 2';
    set(gca,'xticklabel',label)
    ylabel('Change in MFR')
    saveFig(gcf,[root '/MFR_Difference'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 450 275])
    mkBow(bsxfun(@minus,across.pfr(:,2:end),across.pfr(:,1)))
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    label = cellfun(@upper,canonOrderNames','uniformoutput',false);
    label{end} = 'SQUARE 2';
    set(gca,'xticklabel',label)
    ylabel('Change in PFR')
    saveFig(gcf,[root '/PFR_Difference'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%% Heterogeneity Rate Map Stuff %%%%%%%%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkBow(across.c2c.closedHiSqStab)
    set(gca,'xticklabel',[1:4])
    xlabel('# of closed partitions')
    ylabel('Correlation')
    set(gca,'ylim',[-1 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'color','k','linestyle','--')
    saveFig(gcf,[root '/Cell2cell_Heterogeniety_OnlyHiSqStabPairs'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(cellfun(@nanmean,across.c2c.simVsBlocked),0:4,[0.2 0.2 1])
    set(gca,'xticklabel',[0:4])
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%% Heterogeneity Trace Stuff %%%%%%%%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(across.c2c.simVsBlocked,envs,[0.2 0.2 1])
    set(gca,'xticklabel',envs)
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Trace_XC_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(across.c2c.trace.condProb,envs,[0.2 0.2 1])
    set(gca,'xticklabel',envs)
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Trace_CondProb_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%%%%%%%%% Field transition stuff %%%%%%%%%%%%%%%%%%%%%%
    
    mkf2f2Vec(across.f2f,blocked,root)
    mkpv2pv2Vec(across.pv2pv,blocked,root)
    
    
    figure
    set(gcf,'position',[50 50 length(um(1,1,1,:)).*200 4.*200])
    for sj = 1:10

        a = across.f2f{sj}(:,1:2);
        b = across.f2f{sj}(:,3:4);

        vm = [];
        for i = 1:length(um(:,1,1,1))
            for j = 1:length(um(1,:,1,1))
                good = [(floor(a(:,1)) >= (i)) & (floor(a(:,1)) <= (i))] & ...
                    [(floor(a(:,2)) >= (j)) & (floor(a(:,2)) <= (j))];

                vm = [vm; i j nanmean(b(good,[1 2])-[i j],1)];
            end
        end
        vm(any(isnan(vm),2),:) = [];

        subplot(2,5,sj)
        quiver(vm(:,1),vm(:,2),vm(:,3),vm(:,4));
        axis equal
        axis off
    end
end
















 