function out = boundaryTethered(m,p,t,refSesh)

    if nargin < 4 || isempty(refSesh)
        refSesh = 1;
    end

    fprintf('\n\n\t\tComputing simple boundary-tethered model...')
    tic

    ref = m(:,:,:,refSesh);
    
    binSize = nanmax(cellfun(@nanmax,cellfun(@nanmax,p,'uni',0),'uni',1))./size(m,1);
    db = @(x)floor(x./binSize)+1; % binSize
    bp = cellfun(db,p,'uni',0);
    
    btMaps = nan(size(m));
    alloMaps = nan(size(m));
    
    controlAccuracy = nan(length(t{1}(:,1)),length(t));
    allAccuracy = nan(length(t{1}(:,1)),length(t));
    borderSize = 12.5; %5
    allTraces = repmat({[]},[1 length(p)]);
    allP = repmat({[]},[1 length(p)]);
    for si = [1:refSesh-1 refSesh+1:length(p)]
        east = [0 0 borderSize 75];
        eastShift = [0 0];
        west = [75-borderSize 0 75 75];
        westShift = [0 0];
        south = [0 0 75 borderSize];
        southShift = [0 0];
        north = [0 75-borderSize 75 75];
        northShift = [0 0];
        
        % Add new regions because of blocking
        extras = bwconncomp(all(isnan(m(:,:,:,si)),3),4);
        for i = 1:length(extras.PixelIdxList)
            [x y] = ind2sub(size(m(:,:,1,1)),extras.PixelIdxList{i});
            east = [east; [0 0 borderSize 0]+[nanmax(x) nanmin(y)-1 0 range(y)+1].*binSize];
            eastShift = [eastShift; -nanmax(x).*binSize 0];
            west = [west; [-borderSize 0 0 0]+[nanmin(x)-1 nanmin(y)-1 nanmin(x)-1 range(y)+1].*binSize];
            westShift = [westShift; 75-(nanmin(x)-1).*binSize 0];
            
            south = [south; [0 0 0 borderSize]+[nanmin(x)-1 nanmax(y) range(x)+1 0].*binSize];
            southShift = [southShift; 0 -nanmax(y).*binSize];
            north = [north; [0 -borderSize 0 0]+[nanmin(x)-1 nanmin(y)-1 range(x)+1 nanmin(y)-1].*binSize];
            northShift = [northShift; 0 75-(nanmin(y)-1).*binSize];
        end
        
%         % Test plot code to know that it's working
%         isInEW = isInROI(p{si},south');
%         close all
%         figure
%         for i = 1:length(isInEW(:,1))
%             hold on
%             plot(p{si}(1,isInEW(i,:)),p{si}(2,isInEW(i,:)),'marker','o','linestyle','none','markersize',3)
%         end
%         plot(p{si}(1,~any(isInEW,1)),p{si}(2,~any(isInEW,1)),'marker','o','linestyle','none','markersize',3)
%         set(gca,'xlim',[0 75],'ylim',[0 75])

        [isEW mostRecentEW] = isInROI(p{si},[east; west]');
        [isNS mostRecentNS] = isInROI(p{si},[north; south]');
        
        EWNS_mostRecent = getSinceIn([any(isEW,1); any(isNS,1)],p{si});
        
        mostRecentEW(1,~any(mostRecentEW)) = 1;
        mostRecentNS(1,~any(mostRecentNS)) = 1;
        
        
        tmpEW = false(size(mostRecentEW));
        tmpNS = false(size(mostRecentNS));
        for i = 1:length(mostRecentNS)
            tmpEW(find(mostRecentEW(:,i),1,'first'),i) = true;
            tmpNS(find(mostRecentNS(:,i),1,'first'),i) = true;
        end
        mostRecentEW = tmpEW;
        mostRecentNS = tmpNS;
        
        ewShift = repmat([eastShift(:,1); westShift(:,1)],[1 length(isEW(1,:))]);
        doEWShift = ewShift(mostRecentEW);
        nsShift = repmat([northShift(:,2); southShift(:,2)],[1 length(isNS(1,:))]);
        doNSShift = nsShift(mostRecentNS);

%         % Only update based on the most recent boundary
%         doEWShift(~EWNS_mostRecent(1,:)) = 0;
%         doNSShift(~EWNS_mostRecent(2,:)) = 0;
        
        tp = p{si} + [doEWShift'; doNSShift'];
%         plot(tp(1,:),tp(2,:),'marker','o','linestyle','none','markersize',1)
        
        btp = db(tp);
        btp(btp<1) = nan;
        btp(btp>size(m,1)) = nan;
        
        lbtp = sub2ind(size(ref(:,:,1,1)),btp(1,:),btp(2,:));
        unsampled = isnan(lbtp);
        surrogateTrace = nan(size(m,3),length(lbtp(1,:)));
        for k = 1:size(m,3)
            tmp = ref(:,:,k);
            surrogateTrace(k,~unsampled) = tmp(lbtp(~unsampled));
        end
        
        predictedMaps = mkTraceMaps(p{si}(:,~unsampled),surrogateTrace(:,~unsampled),[],size(ref(:,:,1)));
        predictedMaps = predictedMaps(1:15,1:15,:);
        
        allTraces{si} = surrogateTrace(:,~unsampled);
        btMaps(:,:,:,si) = predictedMaps;
        allP{si} = p{si}(:,~unsampled);
    end

    out.maps = btMaps;
    out.trace = allTraces;
    out.p = allP;
    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end







































