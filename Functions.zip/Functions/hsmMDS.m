function hsmMDS(p)
    s = load(p{1},'envSize');
    [h hstats] = aggReplaceMaps(p,1.5.*s.envSize(1)./5);
    ah = nanmean(cat(5,h{:}),5);

    [rsm.overall.human rsm.partition.human shm] = m2rsm(ah,2.5); % 2.5

    mds2D(rsm.partition.human,repmat([0:8],[1 10]),['Plots/' slind(p{1},[1 2]) '/Summary/MDS']);

    
    pRow = repmat([1 1 1 2 2 2 3 3 3],[1 10]);
    pCol = repmat([1 2 3 1 2 3 1 2 3],[1 10]);

    d2p = sqrt((pRow-pRow').^2+(pCol-pCol').^2);

    [envLabel env_blocked] = envStuff();

    mds2D_Overall(rsm.overall.human, envLabel,['Plots/' slind(p{1},[1 2]) '/Summary/MDS'])

end