function noiseCeil = getNoiseCeiling(ref,correlationType)

    if size(ref,3)<3
        noiseCeil = [nan nan];
        return;
    end

    if nargin < 2 || isempty(correlationType)
        correlationType = 'Kendall';
    end

%     noiseCeil = nan(size(ref,3),2);
%     for i = 1:size(ref,3)
%         a = getTri(ref(:,:,i));
%         b = getTri(nanmean(ref(:,:,[1:i-1 i+1:end]),3));
%         c = getTri(nanmean(ref,3));
%         lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
%         hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
%         noiseCeil(i,:) = [lo hi];
%     end
%     noiseCeil = nanmean(noiseCeil);

    percentInclude = 0.5;
    noiseCeil = nan(size(ref,3),2);
    for i = 1:50 % number of simulations
        inds = randperm(size(ref,3));
        a = getTri(nanmean(ref(:,:,inds(floor(length(inds).*percentInclude)+1:end)),3));
        b = getTri(nanmean(ref(:,:,inds(1:floor(length(inds).*percentInclude))),3));
        c = getTri(nanmean(ref,3));
        lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
        hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
        noiseCeil(i,:) = [lo hi];
%         noiseCeil(i,1) = (2.*lo)./(1+(2-1).*lo);
    end
    noiseCeil = nanmean(noiseCeil);
end