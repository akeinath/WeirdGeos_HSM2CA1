function nm = inflate(m,n)
    nm = m;
    for i = 1:length(n)
        if n(i)
            nm = [nm(:,1:i-1) nan(size(nm,1),1) nm(:,i:end)];
            nm = [nm(1:i-1,:); nan(1,size(nm,2)); nm(i:end,:)];
        end
    end
%     for i = length(n):-1:1
%         if n(end-[size(n,1)-(i)])
%             nm = [nm(:,1:i) nan(size(nm,1),1) nm(:,i+1:end)];
%             nm = [nm(1:i,:); nan(1,size(nm,2)); nm(i+1:end,:)];
%         end
%     end
end