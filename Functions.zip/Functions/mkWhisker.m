function h = mkWhisker(d,xl,groupColor,varargin)
    if nargin<2 || isempty(xl)
        xl = 1:length(d(1,:));
    end

    if ~iscell(d)
        newD = repmat({[]},[1 length(d(1,:))]);
        for i = 1:length(d(1,:))
            newD{i} = d(:,i);
        end
        d = newD;
    end
    
    groups = length(d(:,1));
    ticks = length(d(1,:));
    set(gca,'xlim',[0.5 ticks+0.5],'xtick',[1:ticks],'xticklabel',xl,'fontname','arial',...
        'fontsize',10,'fontweight','bold')
    hold on
    
    w = 0.6;
    wpg = w./groups;
%     groupColor = ones(groups,3).*0.8

    if nargin < 3 || isempty(groupColor)
        groupColor = [0.9 0.5 0.5; 0.5 0.9 0.5; 0.5 0.5 0.9];
    end


    ebW = 6;
    th = [];
    for i = 1:groups
        for j = 1:ticks
            if isempty(d{i,j})
                continue
            end
            sVals = sort(d{i,j});
            sVals(isnan(sVals)) = [];
            
%             plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]).*ones(1,2),...
%                 sVals([1 end]),'color','k','linewidth',2);

            % 1 SD Cutoff Rule 
            cutoff = [nanmean(sVals)-nanstd(sVals) nanmean(sVals)+nanstd(sVals)];
            cutoff = [-inf inf];

            % Tukey plot rule +/- 1.6 IQR
%             iqr = [sVals(ceil(length(sVals).*0.75))-sVals(floor(length(sVals).*0.25))];
%             cutoff = [sVals(floor(length(sVals).*0.25))-iqr.*1.5 sVals(ceil(length(sVals).*0.75))+iqr.*1.5];

            plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]).*ones(1,2),...
                [max(cutoff(1),sVals(1)) min(cutoff(2),sVals(end))],'color','k','linewidth',1.5,'linestyle','-');
            
%             plot(mean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]),...
%                 sVals([sVals<cutoff(1)|sVals>cutoff(2)]),'linestyle','none',...
%                 'marker','d','markersize',2.5,'markerfacecolor','k','color','k','markeredgecolor','k')
            
            try
                h(i,j) = patch([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i)) (j-(w./2))+(wpg.*(i)) (j-(w./2))+(wpg.*(i-1))],...
                    [sVals(floor(length(sVals).*0.25)) sVals(floor(length(sVals).*0.25)) ...
                    sVals(ceil(length(sVals).*0.75)) sVals(ceil(length(sVals).*0.75))],...
                    (groupColor(ceil(j),:).*0.5)+0.5,'edgecolor',groupColor(ceil(j),:),'linewidth',2);
                
                plot(([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i))]),...
                    [nanmedian(sVals) nanmedian(sVals)],'color','k','linewidth',2);
    
    % % %             if ~isempty(varargin) && ~isempty(varargin{1})
                    th(end+1) = text(nanmean([(j-(w./2))+(wpg.*(i-1)) (j-(w./2))+(wpg.*(i)) ...
                        (j-(w./2))+(wpg.*(i)) (j-(w./2))+(wpg.*(i-1))])-0.25,...
                        0,[' ' num2str(length(sVals))],'horizontalalignment','left',...
                        'verticalalignment','middle','fontname','arial','fontsize',9,'rotation',90,...
                        'fontweight','normal','color','k');
    % % %             end
            end
        end
    end
end