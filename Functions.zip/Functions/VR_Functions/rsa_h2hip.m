function rsa_h2hip(p,doPlot)

    if nargin < 2 || isempty(doPlot)
        doPlot = true;
    end

    % Overall
% %     SMOOTHING = 1;

    [h hstats] = aggReplaceMaps(p,1.75);
    ah = nanmean(cat(5,h{:}),5);
    allHumanMaps = [h; {ah}];
%     [m mfr spatialInfo spatialInfoP splitHalf splitHalfP] = getMouseMaps();
%     save('mouse.mat','m','mfr','spatialInfo','spatialInfoP','splitHalf','splitHalfP','-v7.3');
%     imagesc(all(isnan(m{2,end}(:,:,:,10)),3))
    load('mouse.mat');

    [rsm.overall.human rsm.partition.human shm] = m2rsm(allHumanMaps,1.5); % 1 <---- overall optimal | partition --> 5 (doesn't matter above 2) | Part Raw ---> 2.5
    [rsm.overall.mouse_raw rsm.partition.mouse_raw sm] = m2rsm(m,3); % 2.5 <---- overall optimal | partition --> 2.75 | Part Raw --> 1.75
    allMouseMaps = [{cat(3,sm{1,:})}; {cat(3,sm{2,:})}; {cat(3,sm{3,:})}; {cat(3,sm{:})}];
    predictedHumanMaps = predictMaps(allHumanMaps(end),{cat(3,sm{:})},[],[],[]); %allHumanMaps(end) **********
    [rsm.overall.mouse_pred rsm.partition.mouse_pred spm] = m2rsm(predictedHumanMaps,-1);

    % environment scale - just sim to open field
%     sim2square(rsm.overall.human{end},rsm.overall.mouse_pred)

    % environment scale
    shRSA([slind(p{1},[1 2]) '/Overall_RSA'],rsm.overall.human{end},cat(3,rsm.overall.mouse_raw{:}),rsm.overall.mouse_pred);

    % environment scale by smoothing
    rsaXSmooth_overall(allHumanMaps(end),m);

  %%%% Add grid distortion function!

%     imagesc(nanmean(hstats.distortionIndex,3))
%     imagesc(nanmean(rsm.overall.human{end},3))

%     a = nanmean(hstats.distortionIndex,3);
%     b = nanmean(rsm.overall.human{end},3);
%     [rval pval] = corr(getTri(a),getTri(b));

    % partition scale
%     allStabMaps = allMouseMaps;
%     allStabMaps{end} = repmat(allStabMaps{end}(:,:,:,end),[1 1 1 10]);
%     allStabMaps{end}(isnan(allMouseMaps{end})) = nan;
%     predictedStabMaps = predictMaps(allHumanMaps(end),allStabMaps(end),[],[],[]);
%     [rsm.overall.mouse_stab rsm.partition.mouse_stab] = m2rsm(predictedStabMaps,-1);
    
    fits = shRSA([slind(p{1},[1 2]) '/Partition_RSA'],rsm.partition.human{end},repmat(eye(9),[10 10 size(rsm.partition.human{end},3)]), ...
        cat(3,rsm.partition.mouse_raw{:}),rsm.partition.mouse_pred); %repmat(-dmat,[10 10 size(hRSM{end},3)])
    drawnow

    rsaXSmooth_partitions(allHumanMaps(end),m);
    rsa_partition_xThresholding(rsm.partition.human,allHumanMaps,allMouseMaps)

%     rm = repulseMaps(allHumanMaps{end},1);
%     npm = bsxfun(@times,predictedHumanMaps{1},permute((1+rm),[1 2 4 3]));
%     [rsm.overall.mouse_pred_repulse rsm.partition.mouse_pred_repulse] = m2rsm({npm},-1);
%     fits = shRSA(rsm.partition.human{end},repmat(eye(9),[10 10 size(rsm.partition.human{end},3)]), ...
%         cat(3,rsm.partition.mouse_raw{:}),rsm.partition.mouse_stab,rsm.partition.mouse_pred,...
%         rsm.partition.mouse_pred_repulse); %repmat(-dmat,[10 10 size(hRSM{end},3)])


    % Plot example

    plotMapPredExamples(shm{end},predictedHumanMaps{end},sm{3,3})

    % rmcAnalysis

%     rmc(shm{end},predictedHumanMaps{end},true);

    % impact of learning

    m2hAcrossSequences(rsm.partition.human,allHumanMaps,allMouseMaps)

    % impact of number of cells (But which cells?!)
    m2hByNumCells(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end))

    % impact of various criteria on fit x number of cells cells
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),mfr,'MFR',1088);
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),spatialInfo,'SI',1080);
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),splitHalf,'SHC',865);
   
    % impact of binary group inclusion on fit x number of cells cells
    m2hxNumCellsXBinaryCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),spatialInfoP,'SI_PVal',1651);
    m2hxNumCellsXBinaryCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),splitHalfP,'SHC_PVal',2756);

    % impact of number of objects
    m2hByNumObjects(rsm.partition.human{end},rsm.partition.mouse_pred)

    % impact by which humans?
    m2hByNumObjectsxCrit(rsm.partition.human{end},rsm.partition.mouse_pred,nanmean(hstats.fam_error(:,end-3:end),2),'FamError');
    m2hByNumObjectsxCrit(rsm.partition.human{end},rsm.partition.mouse_pred,nanmean(hstats.fam_spread,2),'FamSpread');
    m2hByNumObjectsxCrit(rsm.partition.human{end},rsm.partition.mouse_pred,hstats.sbsod,'SBSOD');
    m2hByNumObjectsxBinaryCrit(rsm.partition.human{end},rsm.partition.mouse_pred,hstats.gender=='F','isFemale');


% % %     nsims = 30;
% % %     doLims = [1:10];
% % %     asFits = nan(2,nsims);
% % %     asJNC = nan(2,2,nsims);
% % %     for si = 1:nsims
% % %         tm = allMouseMaps{end};
% % %         nGoodS = nansum(~all(all(isnan(tm))),4);
% % %         predictedHumanMaps = predictMaps(allHumanMaps(end),{tm(:,:,nGoodS<=5,:)},[],350); % minclude 747 cells
% % %         pRSM = m2rsm(predictedHumanMaps,-1);
% % %         [asFits(1,si) asJNC(1,:,si)] = ...
% % %             help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),1);
% % % 
% % %         predictedHumanMaps = predictMaps(allHumanMaps(end),{tm(:,:,nGoodS>5,:)},[],350); % minclude 747 cells
% % %         pRSM = m2rsm(predictedHumanMaps,-1);
% % %         [asFits(2,si) asJNC(2,:,si)] = ...
% % %             help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),1);
% % %     end
% % % 
% % %     figure()
% % %     set(gcf,'position',[50 50 150 225])
% % %     mkWhisker(asFits',[{'1-5'} {'6-10'}],cool(2))
% % %     set(gca,'xlim',[0.5 2.5],'ylim',[0 1])
% % %     ylabel('Kendalls Tau')
% % %     xlabel('Include cells active in N trials')
% % %     title('Similarity to human representation','fontname','arial','fontsize',9)
% % %     plotJNC = [nanmin(asJNC(1,1,:,:),[],3) nanmin(asJNC(2,1,:,:),[],3); ...
% % %         nanmax(asJNC(1,1,:,:),[],3) nanmax(asJNC(2,1,:,:),[],3)];
% % %     x = [[1:length(plotJNC(1,:))]-0.45; [1:length(plotJNC(1,:))]+0.45; ...
% % %         [1:length(plotJNC(1,:))]+0.45; [1:length(plotJNC(1,:))]-0.45];
% % %     patch(x,plotJNC([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
% % %     saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_ByActiveTrials',[{'tiff'} {'pdf'}])

% 
%     nanmax(nanmax(allMouseMaps{end},[],1),[],2)
%     nsims = 30;
%     doLims = [10:-1:2];
%     asFits = nan(length(doLims),nsims);
%     asJNC = nan(length(doLims),2,nsims);
%     for si = 1:nsims
%         for lim = doLims
%             tm = allMouseMaps{end};
%             nGoodS = nansum(~all(all(isnan(tm))),4);
%             predictedHumanMaps = predictMaps(allHumanMaps(end),{tm(:,:,nGoodS>=lim,:)},[],1400); % minclude 747 cells
%             pRSM = m2rsm(predictedHumanMaps,-1);
%             [asFits(lim,si) asJNC(lim,:,si)] = ...
%                 help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),1);
%         end
%     end

%     % impact of adjusting predicted maps before prediction
% 
%     nsims = 50;
%     doScale = [0:0.02:0.98];
%     asFits = nan(length(doScale),nsims);
%     asJNC = nan(length(doScale),2,nsims);
%     for si = 1:nsims
%         for scaleI = 1:length(doScale)
%             tm = predictMaps(allHumanMaps(end),allMouseMaps(end),[],3795,doScale(scaleI));
%             [~, pRSM] = m2rsm(tm,-1);
%             [asFits(scaleI,si) asJNC(scaleI,:,si)] = ...
%                 help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),1);
%         end
%     end
% 
%     eyefit = help_shRSA(hRSM{end},repmat(eye(9),[10 10 size(hRSM{end},3)]), ...
%         size(hRSM{end},3),1);
% 
%     figure()
%     set(gcf,'position',[50 50 450 225])
%     subplot(1,2,1)
%     mkWhisker(asFits',doScale,cool(length(doScale)))
%     plot(get(gca,'xlim'),ones(1,2).*eyefit,'linestyle','--','color',[0.8 0.8 0.8]);
%     set(gca,'xlim',[-1 length(doScale)+1],'ylim',[0 1])
%     ylabel('Kendalls Tau')
%     xlabel('Predicted Map Threshold')
%     title('Similarity to human representation','fontname','arial','fontsize',9)
%     subplot(1,2,2)
%     mkWhisker(asFits',doScale,cool(length(doScale)))
%     set(gca,'xlim',[20-0.5 37+0.5],'ylim',[0.6 0.9])
%     ylabel('Kendalls Tau')
%     xlabel('Predicted Map Threshold')
%     saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_ByPredThresholding',[{'tiff'} {'pdf'}])
%     drawnow

    % RSA x Environment

    h = aggReplaceMaps(p, 1.75); % ADJUST CRITERIA?!?!
    ah = nanmean(cat(5,h{:}),5);
    allHumanMaps = [h; {ah}];
    [~, hRSM] = m2rsm(allHumanMaps,1.5);
    load('mouse.mat');
    [~, mRSM sm] = m2rsm(m,3);
    allMouseMaps = [{cat(3,sm{1,:})}; {cat(3,sm{2,:})}; {cat(3,sm{3,:})}; {cat(3,sm{:})}];
    mRSM = [{cat(3,mRSM{1,:})}; {cat(3,mRSM{2,:})}; {cat(3,mRSM{3,:})}; {cat(3,mRSM{:})}];
    
    predictedHumanMaps = predictMaps(allHumanMaps(end),allMouseMaps(end));
    [~, pRSM] = m2rsm(predictedHumanMaps{1},-1);

    allStabMaps = allMouseMaps;
    allStabMaps{end} = repmat(allStabMaps{end}(:,:,:,end),[1 1 1 10]);
    allStabMaps{end}(isnan(allMouseMaps{end})) = nan;
    predictedStabMaps = predictMaps(allHumanMaps(end),allStabMaps(end),[],[],[]);
    [~, pStabRSM] = m2rsm(predictedStabMaps,-1);
%     help_shRSA(hRSM{end},pRSM,size(hRSM{end},3),1);
    
    [envLabel env_blocked] = envStuff();
    prsm = nan(length(envLabel),length(envLabel),length(envLabel),length(envLabel));
    sprsm = nan(length(envLabel),length(envLabel),length(envLabel),length(envLabel));
    tRSM1 = nanmean(pRSM,3);
    tRSM3 = nanmean(pStabRSM,3);
    tRSM2 = nanmean(hRSM{end},3);
    for ca1_i = 1:length(envLabel)
        for ca1_j = 1:length(envLabel)
            for hsm_i = 1:length(envLabel)
                for hsm_j = 1:length(envLabel)
    
                    rsm1 = tRSM1((ca1_i-1).*9+1:(ca1_i).*9,(ca1_j-1).*9+1:(ca1_j).*9,:);
                    rsm2 = tRSM2((hsm_i-1).*9+1:(hsm_i).*9,(hsm_j-1).*9+1:(hsm_j).*9,:);

                    rsm3 = tRSM3((ca1_i-1).*9+1:(ca1_i).*9,(ca1_j-1).*9+1:(ca1_j).*9,:);
    
                    a = rsm1(:);
                    b = rsm2(:);
                    c = rsm3(:);

                    try
                        prsm(ca1_i,ca1_j,hsm_i,hsm_j) = ...
                            corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)), ...
                            'type','kendall');

                        sprsm(ca1_i,ca1_j,hsm_i,hsm_j) = ...
                            corr(c(~isnan(c)&~isnan(b)),b(~isnan(c)&~isnan(b)), ...
                            'type','kendall');
                    end
                end
            end
        end
    end

    if doPlot

    

        figure
        set(gcf,'position',[50 50 700 350])
        subplot(1,2,1)
        tmp = permute(prsm(10,1:9,10,1:9),[2 4 1 3]);
        tmp2 = permute(sprsm(10,1:9,10,1:9),[2 4 1 3]);
        tmp = tmp-tmp2;
        tmp = squarify(tmp);
        imagesc(tmp)
        alpha(double(~isnan(tmp)))
        colorbar
%         caxis([0.6 0.9])
        axis equal
        axis square
        ylabel('CA1 Sq->Env')
        xlabel('Human Sq->Env')
        set(gca,'xtick',1:length(envLabel),'xticklabel',envLabel, ...
            'ytick',1:length(envLabel),'yticklabel',envLabel);
        subplot(1,2,2)
        a = tmp(1:length(tmp)+1:end);
        mkBar(a,envLabel)
        saveFig(gcf,'Plots/Experiment_1/Summary/RSM_Square->Env_Comparison',[{'tiff'} {'pdf'}])


%         fitVals = [];
%         for i = 1:10
%             fitVals = [fitVals [tmp(i,i); sort(tmp([1:i-1 i+1:end],i),'descend')]];
%         end
%         figure()
%         set(gcf,'position',[50 50 175 225])
%         mkGraph(fitVals')

        sameTransform = tmp(logical(eye(size(tmp))));

        blah = tmp;
        blah(logical(eye(size(tmp)))) = nan;
        diffTransform = nanmean(blah);

%         [a b] = nanmax(tmp,[],1);
%         diffTransform = [getTri(tmp,1); getTri(tmp',1)];

        figure()
        set(gcf,'position',[50 50 175 225])
        mkGraph([{sameTransform} {diffTransform'}],[{'Same'} {'Different'}],[0 0 0])
        ylabel('Kendalls Tau')
        xlabel('Sq->Env Transformation')
%         set(gca,'ylim',[0 1])
        hold on
        plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
        [h pval ci tstat] = ttest(sameTransform);
        [h pval ci tstat] = ttest(diffTransform);
        [h pval ci tstat] = ttest(sameTransform,diffTransform');
        saveFig(gcf,'Plots/Experiment_1/Summary/RSM_Square->Env_Comparison_SameVsDiff',[{'tiff'} {'pdf'}])
    end
    drawnow
end









































