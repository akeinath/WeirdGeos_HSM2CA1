function m2hxSIxNumCells(hRSM,allHumanMaps,allMouseMaps,spatialInfo)
    doCells = round(10.98.*[10].^[0:0.25:2]);
    cmfr = cat(1,spatialInfo{:});
    scmfr = sort(cmfr(:));
    scmfr(isnan(scmfr)) = [];
    nsims = 30;
    divs = 2;
    doLims = [0; scmfr(round(length(scmfr)./divs):round(length(scmfr)./divs):end); nanmax(scmfr)];
    asFits = nan(length(doCells),nsims,divs);
    asJNC = nan(length(doCells),2,nsims,divs);
    for si = 1:nsims
        for di = 1:divs
            tm = allMouseMaps{end};
            isGood = cmfr>doLims(di) & cmfr<=doLims(di+1);
            [a b] = find(~isGood);
            for i = 1:length(a)
                tm(:,:,a(i),b(i)) = nan;
            end
            for k = 1:length(doCells)
                predictedHumanMaps = predictMaps(allHumanMaps(end),{tm},[],doCells(k)); % minclude 747 cells
                [~, pRSM] = m2rsm(predictedHumanMaps,-1);
                [asFits(k,si,di) asJNC(k,:,si,di)] = ...
                    help_shRSA(hRSM,pRSM,[],1);
            end
        end
    end

    figure()
    set(gcf,'position',[50 50 300 300])
    doColors = [0.9 0.4 0.2; 0.2 0.4 0.9];
    for di = 1:divs
        semilogx(repmat(doCells,[nsims 1]),asFits(:,:,di)',...
            'linestyle','none','color',doColors(di,:).*0.5+0.5,'marker','o','markersize',5)
        hold on
        plot(doCells,nanmedian(asFits(:,:,di),2)','marker','+','color',doColors(di,:),'markersize',7,...
            'linestyle','none')
    end
    ylabel('Kendalls Tau')
    set(gca,'ylim',[0 1],'xlim',[8 1500])
    xlabel('Number of cells')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_BySIByNCells',[{'tiff'} {'pdf'}])
    drawnow
end
