function descriptives(paths)

    warning off all
    fprintf('\n\ndescriptives()\n\n');

    sn = [];
    ages = [];
    genders = [];
    sbsods = [];
    error_exclusions = 0;
    for p = paths'
        s = load(p{1},'properties','envSize');
        
        if isempty(fieldnames(s))
            continue
        end

        s = load(p{1},'fam_error','envSize');
        tmp = s.fam_error(:,end-3:end);
        if nanmean(tmp(:)) > 1.5.*s.envSize(1)./5
            error_exclusions = error_exclusions+1;
            continue
        end

        s = load(p{1},'properties');

        sn = [sn; s.properties.subjectNum];
        ages = [ages; s.properties.age];
        genders = [genders; {upper(s.properties.gender(1))}];
        sbsods = [sbsods; s.properties.sbsod];
    end

    outP = ['Stats/' slind(p{1},[1 2]) '_Descriptives.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    
    isF = cellfun(@any,cellfun(@ismember,genders,repmat({'F'},size(genders)),'uni',false));
    isM = cellfun(@any,cellfun(@ismember,genders,repmat({'M'},size(genders)),'uni',false));
    str = sprintf('\nGender: Female = %i, Male = %i, Other = %i', ...
        [nansum(isF) nansum(isM) nansum(~isF&~isM)]);
    fprintf(fid,str);
    str = sprintf('\nSBSOD: Mean = %0.3f, S.D. = %0.3f, range = [%0.2f, %0.2f]', ...
        [nanmean(sbsods) nanstd(sbsods) nanmin(sbsods) nanmax(sbsods)]);
    fprintf(fid,str);
    str = sprintf('\nPerformance Exclusions (>1.5m replacement error): %i', ...
        [error_exclusions]);
    fprintf(fid,str);
    str = sprintf('\n\nn = %i participants, with a gender distribution of female = %i, male = %i, and non-binary = %i', ...
        [nansum(isF|isM|(~isF&~isM)) nansum(isF) nansum(isM) nansum(~isF&~isM)]);
    fprintf(fid,str);
    str = sprintf(' and an age distribution of = %0.3f +/- %0.3f years (mean +/- standard deviation) ranged %i to %i years.', ...
        [nanmean(ages) nanstd(ages) nanmin(ages) nanmax(ages)]);
    fprintf(fid,str);
    fclose(fid);
end