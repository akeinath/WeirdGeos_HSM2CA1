function aFamError = plotFamError(paths)

    close all


    aFamError = [];
    for p = paths'

        s = load(p{1},'fam_error','envSize','fam_block_error');
        
        if isempty(fieldnames(s))
            continue
        end

        if nanmean(s.fam_block_error(:,end)) >= 1.5.*s.envSize(1)./5
            continue
        end

        aFamError = [aFamError; nanmean(s.fam_error,1)];
        
    end

    s = load(p{1},'envSize');
    es = s.envSize(1);

    close all
    drawnow
    figure(1)
    set(gcf,'position',[50 50 350.*3./2 225])
    mkPairedWhisker(aFamError,[1:length(aFamError(1,:))],[ones(4,3).*0.0; ...
        bsxfun(@times,ones(length(aFamError(1,:))-4,3).*0.0,[0.5 0.5 0.9])]);
    set(gca,'xlim',[0.25 length(aFamError(1,:))+0.75],'ylim',[0 4.*es./5]);
% % %     plot([4.5 4.5],get(gca,'ylim'),'color',[0.75 0.75 0.75],'linestyle','--')
% % %     text(2.5,nanmax(get(gca,'ylim')).*0.92,'Familiar only block', ...
% % %         'fontname','arial','fontsize',11,'horizontalalignment','center');
% % %     text(6.5,nanmax(get(gca,'ylim')).*0.92,'Deformation blocks', ...
% % %         'fontname','arial','fontsize',11,'horizontalalignment','center');
    xlabel('Trial number')
    ylabel('Error (vm)')
    figP = ['Plots/' slind(p{1},[1 2],'/.') '/Summary/OpenFieldError'];
    saveFig(gcf,figP,[{'tiff'} {'pdf'}])

% % %     aFamError % do ANOVA;

    [a b c] = kruskalwallis(aFamError(:,1:8),[],'off')
    sprintf(['Kruskal-Wallis: Chi2(%i,%i) = %0.3f, p = %0.3e'],[b{2,3} b{3,3} b{2,5} b{2,6}])


    [a b c] = anova1(aFamError(:,5:8),[],'off')
    sprintf(['Deformation block: F(%i,%i) = %0.3f, p = %0.3e'],[b{2,3} b{3,3} b{2,5} b{2,6}])
        
    [a b c] = anova1(aFamError(:,1:8),[],'off')
    sprintf(['Deformation block: F(%i,%i) = %0.3f, p = %0.3e'],[b{2,3} b{3,3} b{2,5} b{2,6}])
    
    doTests = aFamError(:,1:8);
    ap = nan(length(doTests(1,:)));
    for i = 1:length(doTests(1,:))
        for j = i+1:length(doTests(1,:))
            [a b c] = signrank(doTests(:,i),doTests(:,j));
            ap(i,j) = a;
        end
    end

    close all
    drawnow
    figure(1)
    set(gcf,'position',[50 50 350 225])
    mkWhisker(aFamError,[1:length(aFamError(1,:))],[ones(4,3).*0.7; ...
        bsxfun(@times,ones(length(aFamError(1,:))-4,3),[0.5 0.5 0.9])]);
    set(gca,'xlim',[0.25 length(aFamError(1,:))+0.75],'ylim',[0 5]);
    plot([4.5 4.5],get(gca,'ylim'),'color',[0.75 0.75 0.75],'linestyle','--')
    text(2.5,nanmax(get(gca,'ylim')).*0.92,'Familiar only block', ...
        'fontname','arial','fontsize',11,'horizontalalignment','center');
    text(6.5,nanmax(get(gca,'ylim')).*0.92,'Deformation blocks', ...
        'fontname','arial','fontsize',11,'horizontalalignment','center');
    xlabel('Trial number')
    ylabel('Error (vm)')
    set(gca,'yscale','log')
    figP = ['Plots/' slind(p{1},[1 2],'/.') '/Summary/OpenFieldError_Semilog'];
    saveFig(gcf,figP,[{'tiff'} {'pdf'}])

end