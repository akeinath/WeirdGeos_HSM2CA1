function m2hByNumCells(hRSM,allHumanMaps,allMouseMaps)
    doCells = round(37.95.*[10].^[0:0.25:2]);
    nsims = 500;
    asFits = nan(length(doCells),nsims);
    asJNC = nan(length(doCells),2,nsims);
    strLen = 0;
    fprintf('\n\t\Computing:  ')
    tic

    isPart = false;
    if size(hRSM,1)>45
        isPart = true;
        tag = ['PartitionWise_'];
    else
        tag = ['Overall_'];
    end

    for si = 1:nsims
        str = sprintf('%i of %i',[si nsims]);
        fprintf([repmat('\b',[1 strLen]) str]);
        strLen = length(str);
        for cellI = 1:length(doCells)
            predictedHumanMaps = predictMaps(allHumanMaps,allMouseMaps,[],doCells(cellI)); % minclude 747 cells
            [oRSM, pRSM] = m2rsm(predictedHumanMaps,-1);

            if isPart
                [asFits(cellI,si) asJNC(cellI,:,si)] = ...
                    help_shRSA(hRSM,pRSM,size(hRSM,3),1);
            else
                [asFits(cellI,si) asJNC(cellI,:,si)] = ...
                    help_shRSA(hRSM,oRSM,size(hRSM,3),1);
            end
        end
    end
    toc

    Fish_asFits = atanh(asFits);

    figure()
    set(gcf,'position',[50 50 300 300])
    semilogx(repmat(doCells,[nsims 1]),asFits',...
        'linestyle','none','color',[0.8 0.8 0.8],'marker','o','markersize',5)
    hold on
    plot(doCells,nanmedian(asFits,2)','marker','+','color','k','markersize',7,...
        'linestyle','none')
    ylabel('Kendalls Tau')
    X = repmat(doCells,[nsims 1]);
    Y = asFits';
    P = polyfit(log(X(:)),Y(:),1);
    hold on
%     plot(doObjects,polyval(P,log(doObjects)),'color','k')
    set(gca,'ylim',[-1 1],'xlim',[25 5000])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--')
    xlabel('Number of Cells')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNCells'],[{'tiff'} {'pdf'}])
    drawnow
    figure()
    set(gcf,'position',[50 50 300 300])
    mkWhisker(asFits',doCells,zeros(10,3))
    set(gca,'ylim',[-1 1])
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNCells_BoxWhiskers'],[{'tiff'} {'pdf'}])
    drawnow

    %%% Fisher Transforms

    figure()
    set(gcf,'position',[50 50 300 300])
    semilogx(repmat(doCells,[nsims 1]),Fish_asFits',...
        'linestyle','none','color',[0.8 0.8 0.8],'marker','o','markersize',5)
    hold on
    plot(doCells,nanmedian(Fish_asFits,2)','marker','+','color','k','markersize',7,...
        'linestyle','none')
    ylabel('Kendalls Tau')
    X = repmat(doCells,[nsims 1]);
    Y = Fish_asFits';
    P = polyfit(log(X(:)),Y(:),1);
    hold on
%     plot(doObjects,polyval(P,log(doObjects)),'color','k')
    set(gca,'ylim',[-1.25 1.25],'xlim',[25 5000])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--')
    xlabel('Number of Cells')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNCells_Fish'],[{'tiff'} {'pdf'}])
    drawnow
    figure()
    set(gcf,'position',[50 50 300 300])
    mkWhisker(Fish_asFits',doCells,zeros(10,3))
    set(gca,'ylim',[-1.25 1.25])
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNCells_BoxWhiskers_Fish'],[{'tiff'} {'pdf'}])
    drawnow
end
