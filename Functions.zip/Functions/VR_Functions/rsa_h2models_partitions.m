function rsa_h2hip_partitions(varargin)

    % Overall Map Predictions
    groupMaps = repmat({[]},[1 length(varargin)]);
    i = 0;
    smoothParams = [{'Experiment_2_Fog_Combined'} {1.75} {3.00} {2.00} {1.75}; ...
        {'Experiment_1'} {1} {2.5} {2.25} {1.75}; ...
        {'Experiment_3_LargeRoom_Combined'} {1.5} {3.25} {2.25} {1.75}];
    [envLabel env_blocked] = envStuff();

    orsm = [];
    hrsm = [];
    ahm = [];
    for paths = varargin
        i = i+1;
        p = paths{1};
        s = load(p{1},'envSize');
        [h hstats] = aggReplaceMaps(p,1.5.*s.envSize(1)./5);
        groupMaps{i} = nanmean(cat(5,h{:}),5);

        isSmooth = ismember(smoothParams(:,1),slind(varargin{i}{1},[1 2]));
        hSmooth = smoothParams{isSmooth,4};
        [tmp3 tmp tmp2] = m2rsm(groupMaps{i},hSmooth);
        hrsm = cat(3,hrsm,tmp);
        orsm = cat(3,orsm,tmp3);
        ahm = cat(3,ahm,tmp2{1});
    end

    % make stable prediction
    tmp = repmat(ahm(:,:,:,10),[1 1 1 10]);
    tmp(isnan(ahm)) = nan;
% % %     predictedStableMaps = predictMaps({ahm},{tmp},[],[],[]);
    [overallStable, rsmStable] = m2rsm(tmp,-1);


    testConstants = 0:2.5:35; %[0:5:35];
    testScalars = [-0.4:0.05:0.4]; %-0.3:0.05:0; %[-0.4:0.05:0.4];
    testBeta_1 = [1];
    testBeta_2 = [1]; %[0.25 0.5 1 2 3];
    proportionStable = [0]; %[0.3:0.025:0.9];
    placeThreshold = 0; %[0.2];

    allParams = combvec(testConstants,testScalars,testBeta_1,testBeta_2,proportionStable,placeThreshold);

    t2 = getTri(nanmean(hrsm,3));
    t3 = getTri(nanmean(orsm,3));

    null = nan(1000,1);
    null_overall = nan(1000,1);
    nsims = 1000;
    for i = 1:1000
        a = getTri(nanmean(hrsm(:,:,randi(size(hrsm,3),size(hrsm,3),1)),3));
        b = getTri(nanmean(hrsm(:,:,randi(size(hrsm,3),size(hrsm,3),1)),3));
        null(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type','kendall');

        a = getTri(nanmean(orsm(:,:,randi(size(orsm,3),size(orsm,3),1)),3));
        b = getTri(nanmean(orsm(:,:,randi(size(orsm,3),size(orsm,3),1)),3));
        null_overall(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type','kendall');
    end
    noiseCeiling = [getPercent(null,0.025) getPercent(null,0.975)];
    noiseCeilingOverall = [getPercent(null_overall,0.025) getPercent(null_overall,0.975)];

    pc_fits = nan(1,size(allParams,2));
    pc_overall_fits = nan(1,size(allParams,2));
    pc_noise = nan(2,size(allParams,2));
    bvc_noise = nan(2,size(allParams,2));
    fprintf('\n\nRunning grid search:  ')
    str = [];
    for i = 1:length(allParams(1,:))

        % BVC stuff
        fprintf(repmat('\b',[1 length(str)]));
        str = sprintf(['%i of %i'],[i length(allParams(1,:))]);
        fprintf(str);
        bvcM = genBVCMaps(env_blocked,allParams(1,i),allParams(2,i),allParams(3,i),allParams(4,i));
        if nanmean(all(all(all(isnan(bvcM),1),2),4))>0.10 % At least 90% of sampled BVCs must be active in at least one environment
            continue
        end

% % %         [overallRSM, testRSM] = m2rsm(bvcM,-1);
% % % 
% % %         isBad = permute(all(all(isnan(testRSM),1),2),[3 1 2]);
% % %         testRSM(:,:,isBad) = [];
% % %         testRSM = testRSM(:,:,randperm(size(testRSM,3)));
% % % 
% % %         a = testRSM(:,:,1:round(size(testRSM,3).*(1-allParams(5,i))));
% % %         b = rsmStable(:,:,randi(size(rsmStable,3),round(size(testRSM,3).*(allParams(5,i))),1));
% % %         
% % %         t1 = getTri(nanmean(cat(3,a,b),3));
% % %         bvc_fits(i) = corr(t1(~isnan(t1)&~isnan(t2)),t2(~isnan(t1)&~isnan(t2)),'type','kendall');
% % % 
% % %         %%%%
% % %         
% % %         isBad = permute(all(all(isnan(overallRSM),1),2),[3 1 2]);
% % %         overallRSM(:,:,isBad) = [];
% % %         overallRSM = overallRSM(:,:,randperm(size(overallRSM,3)));
% % % 
% % %         a = overallRSM(:,:,1:round(size(overallRSM,3).*(1-allParams(5,i))));
% % %         b = overallStable(:,:,randi(size(overallStable,3),round(size(overallRSM,3).*(allParams(5,i))),1));
% % %         
% % %         t1 = getTri(nanmean(cat(3,a,b),3));
% % %         bvc_overall_fits(i) = corr(t1(~isnan(t1)&~isnan(t3)),t3(~isnan(t1)&~isnan(t3)),'type','kendall');

        %%%%




        % BVC2P stuff

        iters = 10;
        ifits = nan(1,iters);
        iofits = nan(1,iters);
        for q = 1:iters

            pM = m2linM(bvcM);
            nPM = maxnorm(pM,allParams(6,i));

            if nanmean(all(all(all(isnan(nPM),1),2),4))>0.10 % At least 90% of sampled place field maps must be active in at least one environment
                continue
            end
    
            [overallRSM, testRSM] = m2rsm(nPM,-1);
            isBad = permute(all(all(isnan(testRSM),1),2),[3 1 2]);
            testRSM(:,:,isBad) = [];
            a = testRSM(:,:,1:round(size(testRSM,3).*(1-allParams(5,i))));
            b = rsmStable(:,:,randi(size(rsmStable,3),round(size(testRSM,3).*(allParams(5,i))),1));
    
            t1 = getTri(nanmean(cat(3,a,b),3));
            ifits(q) = corr(t1(~isnan(t1)&~isnan(t2)),t2(~isnan(t1)&~isnan(t2)),'type','kendall');
    
            %%%%%
    
            isBad = permute(all(all(isnan(overallRSM),1),2),[3 1 2]);
            overallRSM(:,:,isBad) = [];
            overallRSM = overallRSM(:,:,randperm(size(overallRSM,3)));
    
            a = overallRSM(:,:,1:round(size(overallRSM,3).*(1-allParams(5,i))));
            b = overallStable(:,:,randi(size(overallStable,3),round(size(overallRSM,3).*(allParams(5,i))),1));
            
            t1 = getTri(nanmean(cat(3,a,b),3));
            iofits(q) = corr(t1(~isnan(t1)&~isnan(t3)),t3(~isnan(t1)&~isnan(t3)),'type','kendall');
        end
        pc_fits(i) = nanmean(ifits);
        pc_overall_fits(i) = nanmean(iofits);


        %%%%%%

% % %         [fits jointNoiseCeiling] = help_shRSA(hrsm,cat(3,a,b),nanmin(size(hrsm,3),size(cat(3,a,b),3)));
% % %         
% % %         pc_fits(i) = nanmean(fits);
% % %         pc_noise(:,i) = [getPercent(jointNoiseCeiling,0.025) getPercent(jointNoiseCeiling,0.975)];
    end

    pc_fits(pc_fits==0) = nan;
    pc_overall_fits(pc_overall_fits==0) = nan;

    %%%% Partition-wise
    rpc = reshape(pc_fits,[length(testConstants) length(testScalars) length(testBeta_1) length(testBeta_2) length(proportionStable) length(placeThreshold)]);
    [a b] = nanmax(pc_fits);
    [a b c d e f] = ind2sub(size(rpc,1:6),b);
    sprintf('\n\n\tMax: %0.3f \tBest Params: %3.3f %3.3f %3.3f %3.3f %3.3f %3.3f',[nanmax(pc_fits) testConstants(a) testScalars(b) ...
        testBeta_1(c) testBeta_2(d) proportionStable(e) placeThreshold(f)])

    %%%%%%% Overall

    rpc = reshape(pc_overall_fits,[length(testConstants) length(testScalars) length(testBeta_1) length(testBeta_2) length(proportionStable) length(placeThreshold)]);
    [a b] = nanmax(pc_overall_fits);
    [a b c d e f] = ind2sub(size(rpc,1:6),b);
    sprintf('\n\n\tMax: %0.3f \tBest Params: %3.3f %3.3f %3.3f %3.3f %3.3f %3.3f',[nanmax(pc_overall_fits) testConstants(a) testScalars(b) ...
        testBeta_1(c) testBeta_2(d) proportionStable(e) placeThreshold(f)])

    
    plotParamSearch(pc_fits,allParams);
    plotParamSearch(pc_overall_fits,allParams);
    plotParamSearch(bvc_fits,allParams);
    plotParamSearch(bvc_overall_fits,allParams);

    [nanmax(pc_fits) nanmax(pc_overall_fits) nanmax(bvc_fits) nanmax(bvc_overall_fits)]

end









































