function plotRSMs(m,root)
    
    allM = densify(m);

    maxPerPage = 25;
    chunks = [];
    for i = 1:maxPerPage:length(allM(1,1,:))
        chunks{(i-1)./maxPerPage+1} = [allM(:,:,i:nanmin(length(allM(1,1,:)),i+maxPerPage-1))];
    end
    
    for chunk_i = 1:length(chunks)
        m = chunks{chunk_i};

        close all
        figure
        set(gcf,'position',[50 50 ceil(sqrt(length(m(1,1,:)))).*300 ...
            ceil(sqrt(length(m(1,1,:)))).*300])
        for k = 1:length(m(1,1,:))
            subplot(ceil(sqrt(length(m(1,1,:)))),ceil(sqrt(length(m(1,1,:)))),k)
            imagesc(m(:,:,k))
            alpha(double(~isnan(m(:,:,k))))
            colormap(gca,'inferno')
            axis square
            axis equal
            axis off
            h = colorbar('location','eastoutside');
            xlabel(h,'Correlation distance')
        end

        saveFig(gcf,['Plots/' root '/IndividualRSMs_chunk_' num2str(chunk_i)],[{'pdf'} {'tiff'}])

    end
end