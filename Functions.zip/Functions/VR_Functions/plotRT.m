function aFamVel = plotRT(paths)

    close all

    [envLabel env_blocked] = envStuff();

    aVel = [];
    aFamVel = [];
    for p = paths'

        s = load(p{1},'objOrg','fam_block_error','envSize');
        
        if isempty(fieldnames(s))
            continue
        end

        if nanmean(s.fam_block_error(:,end)) >= 1.5.*s.envSize(1)./5
            continue
        end

        tmp = nan(length(s.objOrg),length(envLabel));
        famVel = [];
        for i = 1:length(s.objOrg)
            for j = 1:length(envLabel)

                isGood = ismember(s.objOrg(i).env,envLabel(j));
                isGood(ismember(s.objOrg(i).phase,[{'Familiar_Replace_Trials'} ...
                    {'Familiar_Replace_Trials___No_Fog'}])) = false; % Ignore replacements from initial learning
                tmp(i,j) = nanmean(s.objOrg(i).velocity(isGood));
            end

            famVel = [famVel; s.objOrg(i).velocity(ismember(s.objOrg(i).env,{'OpenField'}))];
        end

        aVel = [aVel; nanmean(tmp,1)];
        aFamVel = [aFamVel; nanmean(famVel,1)];
    end

    close all
    drawnow
    figure(1)
    set(gcf,'position',[50 50 700.*3./2 225])
    subplot(1,2,1)
    mkPairedWhisker(aFamVel,[1:length(aFamVel(1,:))],[ones(4,3).*0.0; ...
        bsxfun(@times,ones(length(aFamVel(1,:))-4,3).*0.0,[0.5 0.5 0.9])]);
    plot([4.5 4.5],get(gca,'ylim'),'color',[0.75 0.75 0.75],'linestyle','--')
    text(2.5,nanmax(get(gca,'ylim')).*0.08,'Familiar only block', ...
        'fontname','arial','fontsize',11,'horizontalalignment','center');
    text(6.5,nanmax(get(gca,'ylim')).*0.08,'Deformation blocks', ...
        'fontname','arial','fontsize',11,'horizontalalignment','center');
    set(gca,'ylim',[0 nanmax(get(gca,'ylim'))],'xlim',[0.25 length(aFamVel(1,:))+0.75]);
    xlabel('Trial number')
    ylabel('Velocity (m/s)')
    subplot(1,2,2)
    mkWhisker(aVel,envLabel,bsxfun(@times,[0.75 0.75 0.9],ones(length(aVel(:,1)),3)));
    set(gca,'xlim',[0 length(envLabel)+1],'ylim',[0 nanmax(get(gca,'ylim'))],'xlim',[0.25 length(aVel(1,:))+0.75])
    xlabel('Environment')
    ylabel('Velocity (m/s)')
    figP = ['Plots/' slind(p{1},[1 2],'/.') '/Summary/Velocity_x_Trial_Config'];
    saveFig(gcf,figP,[{'tiff'} {'pdf'}])

    
% % %     [a b c] = kruskalwallis(aFamVel(:,1:8),[],'off')
% % %     sprintf(['Kruskal-Wallis: Chi2(%i,%i) = %0.3f, p = %0.3e'],[b{2,3} b{3,3} b{2,5} b{2,6}])
% % % 
% % %     [a b c] = anova1(aFamVel(:,5:8),[],'off')
% % %     sprintf(['Deformation block: F(%i,%i) = %0.3f, p = %0.3e'],[b{2,3} b{3,3} b{2,5} b{2,6}])
% % %     
% % %     doTests = aFamVel(:,1:8);
% % %     ap = nan(length(doTests(1,:)));
% % %     for i = 1:length(doTests(1,:))
% % %         for j = i+1:length(doTests(1,:))
% % %             [a b c] = signrank(doTests(:,i),doTests(:,j));
% % %             ap(i,j) = a;
% % %         end
% % %     end
    
end