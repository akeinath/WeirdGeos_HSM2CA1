function m2hByNumObjects(hRSM,pRSM)
    doObjects = round(length(hRSM(1,1,:))./100.*[10].^[0:0.25:2]);
    nsims = 500;
    asFits = nan(length(doObjects),nsims);
    asJNC = nan(length(doObjects),2,nsims);
    for si = 1:nsims
        for objI = 1:length(doObjects)
            shuff = randperm(size(hRSM,3));
            hRSM = hRSM(:,:,shuff);
            pRSM = pRSM(:,:,shuff);
            [asFits(objI,si) asJNC(objI,:,si)] = ...
                help_shRSA(hRSM(:,:,1:doObjects(objI)),...
                pRSM(:,:,1:doObjects(objI)),[],1);
        end
    end

    if size(hRSM,1)>45
        tag = ['PartitionWise_'];
    else
        tag = ['Overall_'];
    end

    Fish_asFits = atanh(asFits);

    figure()
    set(gcf,'position',[50 50 300 300])
    semilogx(repmat(doObjects,[nsims 1]),asFits',...
        'linestyle','none','color',[0.8 0.8 0.8],'marker','o','markersize',5)
    hold on
    plot(doObjects,nanmedian(asFits,2)','marker','+','color','k','markersize',7,...
        'linestyle','none')
    ylabel('Kendalls Tau')
    X = repmat(doObjects,[nsims 1]);
    Y = asFits';
    P = polyfit(log(X(:)),Y(:),1);
    hold on
%     plot(doObjects,polyval(P,log(doObjects)),'color','k')
    set(gca,'ylim',[-1 1],'xlim',[4 size(hRSM,3).*1.2])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--')
    xlabel('Number of Objects')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNObjs'],[{'tiff'} {'pdf'}])
    drawnow
    figure()
    set(gcf,'position',[50 50 300 300])
    mkWhisker(asFits',doObjects,zeros(10,3))
    set(gca,'ylim',[-1 1])
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNObjs_BoxWhiskers'],[{'tiff'} {'pdf'}])
    drawnow

    %%% Fisher Transforms

    figure()
    set(gcf,'position',[50 50 300 300])
    semilogx(repmat(doObjects,[nsims 1]),Fish_asFits',...
        'linestyle','none','color',[0.8 0.8 0.8],'marker','o','markersize',5)
    hold on
    plot(doObjects,nanmedian(Fish_asFits,2)','marker','+','color','k','markersize',7,...
        'linestyle','none')
    ylabel('Kendalls Tau')
    X = repmat(doObjects,[nsims 1]);
    Y = Fish_asFits';
    P = polyfit(log(X(:)),Y(:),1);
    hold on
%     plot(doObjects,polyval(P,log(doObjects)),'color','k')
    set(gca,'ylim',[-1.25 1.25],'xlim',[4 size(hRSM,3).*1.2])
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--')
    xlabel('Number of Objects')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNObjs_Fish'],[{'tiff'} {'pdf'}])
    drawnow
    figure()
    set(gcf,'position',[50 50 300 300])
    mkWhisker(Fish_asFits',doObjects,zeros(10,3))
    set(gca,'ylim',[-1.25 1.25])
    saveFig(gcf,['Plots/Experiment_1/Summary/' tag 'MPred2H_ByNObjs_BoxWhiskers_Fish'],[{'tiff'} {'pdf'}])
    drawnow

end
