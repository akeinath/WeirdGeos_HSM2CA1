function pval = rsaTest(a,b)
    ta = getTri(densify(a));
    tb = getTri(densify(b));
end