function getAccRT(paths,recompute)

    if nargin < 2 || isempty(recompute)
        recompute = false;
    end

    clc

    fprintf('\n\ngetAccRT()\n\n');
    [envLabel env_blocked] = envStuff();

    afe = [];
    afs = [];
    abe = [];
    abs = [];
    for p = paths'

% % % %         s = load(p{1},'fam_error','fam_spread','fam_block_spread','fam_block_error');
% % % %         
% % % %         if ~recompute && ~isempty(fieldnames(s)) && isfield(s,'fam_block_error')
% % % %             afe = [afe; s.fam_error];
% % % %             afs = [afs; s.fam_spread];
% % % %             abe = [abe; s.fam_block_error];
% % % %             abs = [abs; s.fam_block_spread];
% % % %             continue
% % % %         end

        fprintf(['\tComputing accuracy:  ' slind(p{1},[1 3],'\/.') '... ']);

        s = load(p{1});

        famError = [];
        blockError = [];
        blockSpread = [];
        famSpread = [];
        famVel = [];
        vels = [];
        for i = 1:length(s.objOrg)
            
            ol = s.objOrg(i).pos([1 3],ismember(s.objOrg(i).env,{'OpenField'}));
            ol = ol-s.objOrg(i).true_loc';
            tmp = [];
            for q = 1:length(ol)./4
                tmp(q) = sqrt(nansum(nanmedian(ol(:,(q-1).*4+1:(q).*4),2).^2));
            end
            blockError = [blockError; tmp];

            ol = s.objOrg(i).pos([1 3],ismember(s.objOrg(i).env,{'OpenField'}));
            tmp = [];
            for q = 1:length(ol)./4
                bl = ol(:,(q-1).*4+1:(q).*4);
                bs = bl-nanmedian(bl,2);
                tmp(q) = nanmean(sqrt(nansum(bs.^2)));
            end
            blockSpread = [blockSpread; tmp];


            tmp = nansum([s.objOrg(i).pos([1 3],:)-s.objOrg(i).true_loc'].^2,1).^(1./2);
            famError = [famError; tmp(ismember(s.objOrg(i).env,{'OpenField'}))];

            tmp = s.objOrg(i).pos([1 3],ismember(s.objOrg(i).env,{'OpenField'}));
            tmp = nansum([tmp-nanmean(tmp(:,end-3:end),2)].^2,1).^(1./2);
            famSpread = [famSpread; nanmean(tmp(:,end-3:end))];


            time = cellfun(@size,s.objOrg(i).trajectory, ...
                repmat({2},[size(s.objOrg(i).trajectory)]))*(1./90); % 90Hz frame rate seems correct TEST THOUGH?!

            distances = cellfun(@getPathDist,s.objOrg(i).trajectory);

            vel = distances./time;

            s.objOrg(i).RT = time;
            s.objOrg(i).pathDistance = distances;
            s.objOrg(i).velocity = vel;

            famVel = [famVel; vel(ismember(s.objOrg(i).env,{'OpenField'}))];
% 
%             tmp = [];
%             for j = 1:length(envLabel)
%                 tmp = [tmp nanmedian(vel([false(1,4) true(1,40)] & ...
%                     ismember(s.objOrg(i).env,envLabel(j))))];
%             end
%             vels = [vels; tmp];
        end

        close all
        
        figure(1)
        set(gcf,'position',[250 250 700 225])
        subplot(1,2,1)
        mkGraph(famError,[1:length(famError(1,:))],[0.3 0.3 0.9]);
        xlabel('Trial number')
        ylabel('Error (m)')
        subplot(1,2,2)
        mkGraph(famVel,[1:length(famVel(1,:))],[0.3 0.3 0.9]);
        xlabel('Trial number')
        ylabel('Velocity (m/s)')
        figP = ['Plots/' slind(p{1},[1 3],'/\.') '/OpenFieldError'];
        saveFig(gcf,figP,[{'tiff'} {'pdf'}])

        s.fam_error = famError;
        s.fam_spread = famSpread;
        s.fam_block_error = blockError;
        s.fam_block_spread = blockSpread;

        save(p{1},'-struct','s','-v7.3');
        fprintf('Done.\n');

        afe = [afe; famError];
        afs = [afs; famSpread];
        abe = [abe; blockError];
        abs = [abs; blockSpread];
    end

    gafe = nan(length(paths),size(afe,2));
    gafs = nan(length(paths),size(afe,2));
    gabs = nan(length(paths),size(abe,2));
    gabe = nan(length(paths),size(abe,2));
    for si = 1:length(paths)
        gafe(si,:) = nanmean(afe((si-1).*5+1:(si).*5,:),1);
        gafs(si,:) = nanmean(afs((si-1).*5+1:(si).*5,:),1);
        gabe(si,:) = nanmean(abe((si-1).*5+1:(si).*5,:),1);
        gabs(si,:) = nanmean(abs((si-1).*5+1:(si).*5,:),1);
    end


    figure
    set(gcf,'position',[50 50 300 300])
    A = nanmean(gabe(gabe(:,end)<1.5,end),2);
    B = nanmean(gabs(gabe(:,end)<1.5,end),2);
    scatter(A,B,10,'k')
    xlabel('Open Field Replace Error (Deformation Block)')
    ylabel('Open Field Replace Spread (Deformation Block)')
    axis square
    axis equal
    hold on
    plot(nanmean(A),nanmean(B),'color',[0.9 0.3 0.9],'linestyle','none','marker','d',...
        'markerfacecolor',[0.7 0.3 0.9],'markersize',8)

%     set(gca,'xlim',[0 nanmax([get(gca,'xlim') get(gca,'ylim')])+0.2], ...
%         'ylim',[0 nanmax([get(gca,'xlim') get(gca,'ylim')])+0.2])
    set(gca,'xlim',[0 1.5],'ylim',[0 1.5])
    plot([0 nanmax(get(gca,'xlim'))],[0 nanmax(get(gca,'ylim'))], ...
        'color',[0.8 0.8 0.8],'linestyle','--')
    plot([1.75 1.75],[0 nanmax(get(gca,'ylim'))], ...
        'color',[0.5 0.5 0.5],'linestyle',':')
%     lsline
    [r pval] = corr(A,B);
    text(0.1,1.6,sprintf('r = %0.3f, p = %0.3e',[r pval]),'fontsize',12)
end






















