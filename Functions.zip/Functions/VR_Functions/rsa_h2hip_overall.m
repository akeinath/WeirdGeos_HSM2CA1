function rsa_h2hip_overall(p)

    s = load(p{1},'envSize');
    [h hstats] = aggReplaceMaps(p,1.5.*s.envSize(1)./5);
    ah = nanmean(cat(5,h{:}),5);
    allHumanMaps = [h; {ah}];
    load('mouse.mat');

    % Grid search over smoothing parameters
% % %     [hSmooth mSmooth] = rsaXSmooth_overall([slind(p{1},[1 2]) '/Overall_SmoothingParameters'],allHumanMaps(end),m);

    hSmooth = 1;
    mSmooth = 2.5;

    [rsm.overall.human rsm.partition.human shm] = m2rsm(allHumanMaps,hSmooth); % 1 <---- overall optimal | partition --> 5 (doesn't matter above 2) | Part Raw ---> 2.5
    [rsm.overall.mouse_raw rsm.partition.mouse_raw sm] = m2rsm(m,mSmooth); % 2.5 <---- overall optimal | partition --> 2.75 | Part Raw --> 1.75
    allMouseMaps = [{cat(3,sm{1,:})}; {cat(3,sm{2,:})}; {cat(3,sm{3,:})}; {cat(3,sm{:})}];
    predictedHumanMaps = predictMaps(allHumanMaps(end),{cat(3,sm{:})},[],[],[]); %allHumanMaps(end) **********
    [rsm.overall.mouse_pred rsm.partition.mouse_pred] = m2rsm(predictedHumanMaps,-1);
    tmp = repmat(allMouseMaps{end}(:,:,:,10),[1 1 1 10]);
    tmp(isnan(allMouseMaps{end})) = nan;
    predictedStableMaps = predictMaps(allHumanMaps(end),{tmp},[],[],[]);
    [rsm.overall.mouse_pred_stable rsm.partition.mouse_pred_stable rsm.pixel.mouse_pred_stable] = m2rsm(predictedStableMaps,-1);

    %%%%%%%%
    
    [envLabel env_blocked] = envStuff();
    a = rsm.overall.human{end};
    a = permute(a(end,:,:),[3 2 1]);
    b = nansum(env_blocked,2);

    vals = repmat({[]},[1 4]);
    label = [];
    for i = 1:4
        t = a(:,b==i);
        vals{i} = t(:);
        label = [label; ones(numel(t),1).*i];
    end

    figure
    ylabel('Correlation (r)')
    xlabel('# closed partitions')
    mkWhisker(vals,[1:4],zeros(4,3))
    [a b c] = kruskalwallis(cat(1,vals{:}),label);

    %%%%%%%%

    % overall map scale RSA between species
    fits = shRSA([slind(p{1},[1 2]) '/Overall_RSA'],rsm.overall.human{end},rsm.overall.mouse_pred_stable,rsm.overall.mouse_pred);

    %%% Cross-species comparison when median-splitting mouse CA1 cells by
    %%% various criteria
    [spatialInfo splitHalf] = getMouseMapStats(m,spm,samp,mSmooth);
    m2hxNumCellsXCrit(rsm.overall.human{end},allHumanMaps(end),allMouseMaps(end),mfr,'MFR'); % 1088
    m2hxNumCellsXCrit(rsm.overall.human{end},allHumanMaps(end),allMouseMaps(end),spatialInfo,'SI'); % 1080
    m2hxNumCellsXCrit(rsm.overall.human{end},allHumanMaps(end),allMouseMaps(end),splitHalf,'SHC'); % 865

    %%% Cross-species comparison when median-splitting human spatial memory
    %%% by various criteria and by sex of participant.
    m2hByNumObjectsxCrit(rsm.overall.human{end},rsm.overall.mouse_pred,hstats.fam_block_error(:,end),'FamError');
    m2hByNumObjectsxCrit(rsm.overall.human{end},rsm.overall.mouse_pred,hstats.fam_block_spread(:,end),'FamSpread');
    m2hByNumObjectsxBinaryCrit(rsm.overall.human{end},rsm.overall.mouse_pred,hstats.gender=='F','isFemale');

end





































