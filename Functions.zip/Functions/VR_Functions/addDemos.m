function addDemos(paths,doSheet)

    [a b demo] = xlsread(doSheet,1,'A1:F200');

    warning off all
    fprintf('\n\naddDemos()\n\n');

    for p = paths'
        s = load(p{1},'properties');
        
        if ~isempty(fieldnames(s))
%             isSame = s.properties.subjectNum == subNum & s.properties.age == demo{isExp&isSubNum,3} & ...
%                 s.properties.gender == demo{isExp&isSubNum,4} & s.properties.sbsod == demo{isExp&isSubNum,5};
%             if isSame
                continue
%             end
        end

        fprintf(['\tAdding Demographics:  ' slind(p{1},[1 3],'/\.') '... ']);

        s = load(p{1});
        
        tmp = slind(p{1},[2 3],'/.');
        if tmp(1)=='D'
            isSub = ismember(cellfun(@num2str,demo(:,2),'uni',0),{tmp});

            s.properties.subjectNum = str2num(slind(slind(p{1},[2 3],'/.'),[1 2],'_'));
            s.properties.age = demo{isSub,3};
            s.properties.gender = demo{isSub,4};
            s.properties.sbsod = demo{isSub,5};
            s.properties.include = demo{isSub,6};
        else
%             isExp = cellfun(@all,cellfun(@ismember,demo(:,1),repmat({slind(p{1},[1 2])},[length(demo(:,1)) 1]),'uni',0));
            isExp = true(size(demo,1),1);
            subNum = str2num(p{1}(find(ismember(p{1},'_'),1,'last')+1:end-4));
            isSubNum = cellfun(@all,cellfun(@ismember,demo(:,2),repmat({subNum},[length(demo(:,1)) 1]),'uni',0));

            s.properties.subjectNum = subNum;
            s.properties.age = demo{isExp&isSubNum,3};
            s.properties.gender = demo{isExp&isSubNum,4};
            s.properties.sbsod = demo{isExp&isSubNum,5};
            s.properties.include = demo{isExp&isSubNum,6};
        end

        save(p{1},'-struct','s','-v7.3');
        fprintf('Done.\n');
    end
end