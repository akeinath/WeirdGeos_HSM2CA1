function m2hAcrossSequences(hRSM,allHumanMaps,allMouseMaps)
    nsims = 50;
    oFits = nan(length(allHumanMaps),length(allMouseMaps),nsims);
    oJNC = nan(length(allHumanMaps),length(allMouseMaps),nsims);
    pFits = nan(length(allHumanMaps),length(allMouseMaps),nsims);
    pJNC = nan(length(allHumanMaps),length(allMouseMaps),nsims);
    for si = 1:nsims

%         tic
        [predictedHumanMaps minclude] = predictMaps(allHumanMaps,allMouseMaps(1:3),[],[]); % minclude 747 cells
        [oRSM, pRSM] = m2rsm(predictedHumanMaps,-1);
%         toc

        for hi = 1:length(allHumanMaps)
            for mi = 1:length(allMouseMaps)

                [fits jnc] = help_shRSA(hRSM.overall.human{hi},oRSM{hi,mi}, ...
                    size(hRSM.overall.human{hi},3),1);
                oFits(hi,mi,si) = fits;
                oJNC(hi,mi,si) = jnc(1);

                [fits jnc] = help_shRSA(hRSM.partition.human{hi},pRSM{hi,mi}, ...
                    size(hRSM.partition.human{hi},3),1);
                pFits(hi,mi,si) = fits;
                pJNC(hi,mi,si) = jnc(1);
            end
        end
    end

    a = permute(oFits,[3 2 1]);
    b = permute(oJNC,[3 2 1]);

    figure
    set(gcf,'position',[50 50 200 225])
    doPerc = 0.025;
    subplot(1,2,1)
    jnc = [];
    jointNoiseCeiling = b;
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    hold on
    mkWhisker(a,1:length(allMouseMaps),[0.6 0.6 0.6; 0.6 0.6 0.6; 0.6 0.6 0.6])
    ylabel('Kendalls Tau')
    xlabel('Sequence')
    set(gca,'ylim',[0 1]);
    for i = 1:size(a,2)
        tmp = bsxfun(@gt,a(:,i),b(:,i)');
        pval_btwOverall = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
        text(2,0.15+0.07.*(i-1),sprintf('p = %0.4f',pval_btwOverall),'fontname','arial','fontsize',9,'horizontalalignment','center')
    end
    subplot(1,2,2)
    a = permute(pFits,[3 2 1]);
    b = permute(pJNC,[3 2 1]);
    jnc = [];
    jointNoiseCeiling = b;
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    hold on
    mkWhisker(a,1:length(allMouseMaps),[0.6 0.6 0.6; 0.6 0.6 0.6; 0.6 0.6 0.6])
    ylabel('Kendalls Tau')
    xlabel('Sequence')
    set(gca,'ylim',[0 1]);
    for i = 1:size(a,2)
        tmp = bsxfun(@gt,a(:,i),b(:,i)');
        pval_btwOverall = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
        text(2,0.15+0.07.*(i-1),sprintf('p = %0.4f',pval_btwOverall),'fontname','arial','fontsize',9,'horizontalalignment','center')
    end
end