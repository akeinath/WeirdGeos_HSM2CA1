function m2hLearning(allHumanMaps,allMouseMaps)
    nsims = 50;
    asFits = nan(1,4,nsims);
    asJNC = nan(1,4,2,nsims);
    for si = 1:nsims
        predictedHumanMaps = predictMaps(allHumanMaps,allMouseMaps,[],747); % minclude 747 cells
        pRSM = m2rsm(predictedHumanMaps,-1);
        for hi = 1:5
            for mi = 1:4
                [fits jnc] = help_shRSA(hRSM{hi},pRSM{hi,mi},size(hRSM{hi},3),1);
                asFits(hi,mi,si) = fits;
                asJNC(hi,mi,:,si) = jnc;
            end
        end
    end

    tmp = permute(asFits(end,1:3,:),[3 2 1]);

%     [a b c] = kruskalwallis(permute(asFits(end,1:3,:),[3 2 1]));

    eyefit = help_shRSA(hRSM{end},repmat(eye(9),[10 10 size(hRSM{end},3)]), ...
        size(hRSM{end},3),1);

    plotJNC = permute([nanmin(asJNC(end,:,1,:),[],4); ...
        nanmax(asJNC(end,:,1,:),[],4)],[1 2 3 4]);
    figure()
    set(gcf,'position',[50 50 225 275])
    mkWhisker(permute(asFits(end,:,:),[3 2 1]),[{'1'} {'2'} {'3'} {'Combined'}],...
        [0.3 0.3 0.6; 0.2 0.2 0.7; 0.1 0.1 0.8; 0.6 0.6 0.6].*0.5+0.5);
    hold on
    plot(get(gca,'xlim'),ones(1,2).*eyefit,'linestyle','--','color',[0.8 0.8 0.8]);
    set(gca,'ylim',[0 1],'xlim',[0.25 4.75])
    xlabel('Mouse sequence')
    ylabel('Kendalls Tau')
    x = [[1:length(plotJNC(1,:))]-0.45; [1:length(plotJNC(1,:))]+0.45; ...
        [1:length(plotJNC(1,:))]+0.45; [1:length(plotJNC(1,:))]-0.45];
    patch(x,plotJNC([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_BySequence',[{'tiff'} {'pdf'}])
    drawnow
end