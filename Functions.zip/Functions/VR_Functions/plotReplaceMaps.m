function plotReplaceMaps(paths)


    warning off all

    for p = paths'
        s = load(p{1},'maps');

        colormap parula

        close all

        figure
        set(gcf,'position',[50 50 1400 1000])
        for k = 1:length(s.maps(1,1,:,1))
            catMaps = permute(s.maps(:,:,k,1),[2 1 3 4]);
            for j = 2:length(s.maps(1,1,1,:))
                catMaps = cat(2,catMaps,nan(length(s.maps(:,1,1,1)),1),permute(s.maps(:,:,k,j),[2 1 3 4]));
            end
            subplot(length(s.maps(1,1,:,1)),1,k)
            imagesc(catMaps)
            axis equal
            alpha(double(~isnan(catMaps)))
            axis off
        end

        figP = ['Plots/' slind(p{1},[1 3],'/.') '/Replace_Maps'];
        saveFig(gcf,figP,[{'tiff'} {'pdf'}])
    end
end