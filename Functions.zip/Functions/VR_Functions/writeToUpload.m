function aFamError = writeToUpload(paths)

    close all


    aFamError = [];
    for p = paths'

        s = load(p{1});
        
        if nanmean(s.fam_block_error(:,end)) >= 1.5.*s.envSize(1)./5
            continue
        end

        fprintf(['\n\t' p{1}])
        outP = ['ToUpload/' p{1}];
        checkP(outP);
        save(outP,'-struct','s','-v7.3');
        
    end

end