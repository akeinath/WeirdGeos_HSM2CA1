function out = mkRSA(p,doPlot)

    if nargin < 2 || isempty(doPlot)
        doPlot = true;
    end

    % HUMAN RSM

    % combine all maps and do PV correlation on full population

    [aggMaps RSMs_individual RSMs_pv RSMs_pmap RSMs_pvi] =  aggReplaceMaps(p,0);
  
    toPlot = [{densify(nanmean(RSMs_individual,3))} {densify(RSMs_pv)} ...
        {densify(nanmean(RSMs_pmap,3))} {densify(nanmean(RSMs_pvi,3))}];
    labels = [{'Average Map Corr'} {'Agg Pop Vec'} {'Partition Map'} {'Indiv Pop Vec'}];

    close all
    figure
    set(gcf,'position',[50 50 350.*length(toPlot) 400])
    for i = 1:length(toPlot)
        subplot(1,length(toPlot),i)
        imagesc(toPlot{i})
        alpha(double(~isnan(toPlot{i})))
        title(labels{i})
        colormap(gca,'inferno')
        axis square
        axis equal
        axis off
        h = colorbar('location','southoutside');
        xlabel(h,'Correlation (r)')
    end
    saveFig(gcf,'Plots/Experiment_1/Summary/RSM_Human',[{'tiff'} {'pdf'}])
end









































