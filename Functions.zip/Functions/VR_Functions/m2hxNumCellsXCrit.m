function m2hxNumCellsXCrit(hRSM,allHumanMaps,allMouseMaps,mfr,critName,critValue)

    cmfr = cat(1,mfr{:});
    scmfr = sort(cmfr(:));
    scmfr(isnan(scmfr)) = [];
    nsims = 500;
    divs = 2;

    if nargin < 6 || isempty(critValue)
        doLims = [-inf; scmfr(round(length(scmfr)./divs):round(length(scmfr)./divs):end); inf];
    else
        doLims = [-inf; critValue; inf];
    end

    maxCells = nan(1,divs);
    for di = 1:divs
        tm = allMouseMaps{end};
        isGood = cmfr>doLims(di) & cmfr<=doLims(di+1);
        [a b] = find(~isGood);
        for i = 1:length(a)
            tm(:,:,a(i),b(i)) = nan;
        end
        
        rtm = reshape(tm,[numel(tm(:,:,1,1)) size(tm,[3 4])]);
        for j = 1:size(rtm,3)
            for i = 1:size(rtm,1)
                tg = nansum(~(isnan(rtm(i,:,j))|all(isnan(rtm(:,:,10)))));
                if tg~=0
                    maxCells(di) = nanmin(maxCells(di),tg);
                end
            end
        end
    end

%     doCells = round((maxCells'./100).*[10].^[0:0.25:2]);
    doCells = maxCells;
    doCells = nanmin(doCells)-1;
%     doCells = round((maxCells'./100).*[10].^[0:1:2]);

    tic
    asFits = nan(divs,nsims);
    asJNC = nan(2,nsims,divs);
    for si = 1:nsims
        for di = 1:divs
            tm = allMouseMaps{end};
            isGood = cmfr>doLims(di) & cmfr<=doLims(di+1);
            [a b] = find(~isGood);
            for i = 1:length(a)
                tm(:,:,a(i),b(i)) = nan;
            end
            predictedHumanMaps = predictMaps(allHumanMaps(end),{tm},[],doCells); % minclude 747 cells
            [oRSM, pRSM] = m2rsm(predictedHumanMaps,-1);

            if size(hRSM,1)== 10
                [asFits(di,si,1) asJNC(:,si,di)] = ...
                    help_shRSA(hRSM,oRSM,[],1);
            else
                [asFits(di,si,1) asJNC(:,si,di)] = ...
                    help_shRSA(hRSM,pRSM,[],1);
            end
        end
    end
    toc

    %%%%%%%%%%%%%%%

    figure()
    set(gcf,'position',[50 50 125 225])
    doColors = jet(2).*0.75+0.25;
    doColors = doColors([2 1],:);
    mkWhisker(asFits',[{'< Median'} {'> Median'}],doColors)
    hold on
    set(gca,'ylim',[0 1])

    doPerc = 0.025;
    jnc = [];
    jointNoiseCeiling = permute(asJNC(1,:,:),[2 3 1]);
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    ylabel('Kendalls Tau')
    xlabel(critName)

    fits = asFits';
    outP = ['Stats/Experiment_1/MPred2Hx_' critName '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    ntests = nchoosek(length(fits(1,:)),2);
    for i = 1:length(fits(1,:))
        for j = i+1:length(fits(1,:))

            fprintf(fid,['\nGroups:  ' num2str(i) ' vs. ' num2str(j)]);

            actual = abs(nanmean(fits(:,i))-nanmean(fits(:,j)));

            a = fits(:,i);
            b = fits(:,j);
            c = a(:)<[b(:)]';
            pval = nanmean(c(:));
            pval = nanmin(pval,1-pval).*2;

            str = sprintf('; \tActual = %0.3f, p = %0.4f, p (bonferroni) = %0.4f',[actual pval pval.*ntests]);
            fprintf(fid,str);
        end
    end
    fclose(fid);

    text(1.5,1.05,sprintf('p = %0.4f',pval.*ntests),'fontname','arial','fontsize',9,'horizontalalignment','center')
    text(1.5,0.95,sprintf('n = %i',doCells(1)),'fontname','arial','fontsize',9,'horizontalalignment','center')
    saveFig(gcf,['Plots/Experiment_1/Summary/MPred2Hx_' critName],[{'tiff'} {'pdf'}])
    drawnow


%     figure()
%     set(gcf,'position',[50 50 125 225])
%     doColors = [0.9 0.4 0.2; 0.2 0.4 0.9];
%     fits = permute(asFits(end,:,:),[2 3 1]);
%     mkWhisker(fits,[{'< Median'} {'> Median'}],doColors)
%     hold on
%     set(gca,'ylim',[0 1])
% 
%     doPerc = 0.025;
%     jnc = [];
%     jointNoiseCeiling = permute(asJNC(end,:,:,:),[3 2 4 1]);
%     for i = 1:length(jointNoiseCeiling(1,1,:))
%         jnc = [jnc [getPercent(jointNoiseCeiling(:,1,i),doPerc); ...
%             getPercent(jointNoiseCeiling(:,1,i),1-doPerc)]];
%     end
%     
%     x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
%         [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
%     patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
%     ylabel('Kendalls Tau')
%     xlabel(critName)
% 
%     outP = ['Stats/Experiment_1/MPred2Hx_' critName '.txt'];
%     checkP(outP);
%     fid = fopen(outP,'w');
%     ntests = nchoosek(length(fits(1,:)),2);
%     for i = 1:length(fits(1,:))
%         for j = i+1:length(fits(1,:))
% 
%             fprintf(fid,['\nGroups:  ' num2str(i) ' vs. ' num2str(j)]);
% 
%             actual = abs(nanmean(fits(:,i))-nanmean(fits(:,j)));
% 
%             null = nan(10000,1);
%             for q = 1:10000
%                 tmp = [fits(:,i); fits(:,j)];
%                 tmp = tmp(randperm(length(tmp)));
%                 tmp = [tmp(1:length(tmp)./2) tmp(length(tmp)./2+1:end)];
%                 null(q) = abs(nanmean(tmp(:,1))-nanmean(tmp(:,2)));
%             end
%             pval = nanmean(actual<null);
% 
%             str = sprintf('; \tActual = %0.3f, p = %0.4f, p (bonferroni) = %0.4f',[actual pval pval.*ntests]);
%             fprintf(fid,str);
%         end
%     end
%     fclose(fid);
% 
%     text(1.5,1.05,sprintf('p = %0.4f',pval.*ntests),'fontname','arial','fontsize',9,'horizontalalignment','center')
%     saveFig(gcf,['Plots/Experiment_1/Summary/MPred2Hx_' critName],[{'tiff'} {'pdf'}])
%     drawnow
end
