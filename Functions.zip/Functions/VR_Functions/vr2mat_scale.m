function outPs = vr2mat(paths,outFolder,recompute)
    if nargin < 2 || isempty(outFolder)
        outFolder = 'MatlabData/';
    end

    if nargin < 3 || isempty(recompute)
        recompute = false;
    end

    clc

    [envLabel env_blocked] = envStuff();

    envSize = [5 5];
    objOrder = [{'1'} {'2'} {'3'} {'4'} {'5'}];

    fprintf('vr2mat()\n\n');

    outPs = [];
    for p = paths'

        tmp = slind(p{1},[1 0]);
        outP = [outFolder tmp(1:end-4)];
        if ~recompute && exist([outP '.mat'])==2
            continue
        end

        fprintf(['\n\tCreating:  ' slind(outP,[1 0]) '\t']);
        tic
        
        fid = fopen(p{1});
        d = textscan(fid,'%d %s %s %s %f %f %d %d %d %d %d %d %d %d %d %f %f %f %f %f %f %f','delimiter',',');
        fclose(fid);
        
        s = struct;
        s.raw = d;

        %%%% Fix positions that glitch to 0, 0, 0
        isGlitched = d{end-5} == 0 & d{end-4} == 0 & d{end-3} == 0;
        d{end-6}(isGlitched) = nan;
        d{end-5}(isGlitched) = nan;
        d{end-4}(isGlitched) = nan;
        interpD = interpNaNs([cat(1,d{end-6}) cat(1,d{end-5}) cat(1,d{end-4})]);
        d{end-6} = interpD(:,1);
        d{end-5} = interpD(:,2);
        d{end-4} = interpD(:,3);
        %%%%%

        uphase = unique(d{2});
        keep = [{'Familiar Replace Trials'}  {'Familiar Replace Trials - No Fog'}  {'Block 1'} {'Block 2'} {'Block 3'} {'Block 4'}];
        for phase_i = 1:length(keep)
            isPhase = ismember(d{2},keep(phase_i));
            if nansum(isPhase)==0
                continue
            end
            

            s.(spaceSub(keep{phase_i})) = struct;
            s.envSize = envSize.*d{end}(end);
            isPhase = ismember(d{2},keep(phase_i));
            isReplace = ismember(d{3},{'Replace'});
            doTrials = unique(d{1}(isPhase&isReplace));
            for trial_i = 1:length(doTrials)
                isTrial = ismember(d{1},doTrials(trial_i));
                s.(spaceSub(keep{phase_i}))(trial_i).pos = [d{end-6}(isTrial)'; d{end-5}(isTrial)'; d{end-4}(isTrial)'];
                s.(spaceSub(keep{phase_i}))(trial_i).hd = [d{end-3}(isTrial)'; d{end-2}(isTrial)'; d{end-1}(isTrial)'];
                trialStart = find(isTrial,1,'first');
                s.(spaceSub(keep{phase_i}))(trial_i).objName = d{4}(trialStart);
                s.(spaceSub(keep{phase_i}))(trial_i).objP = [d{5}(trialStart) d{6}(trialStart)].*d{end}(trialStart);
                s.(spaceSub(keep{phase_i}))(trial_i).env_blocked = [d{7}(trialStart) d{8}(trialStart) d{9}(trialStart) ...
                    d{10}(trialStart) d{11}(trialStart) d{12}(trialStart) d{13}(trialStart) d{14}(trialStart) d{15}(trialStart)];
                s.(spaceSub(keep{phase_i}))(trial_i).env = envLabel{ismember(env_blocked,s.(spaceSub(keep{phase_i}))(trial_i).env_blocked,'rows')};
                s.(spaceSub(keep{phase_i}))(trial_i).scale = d{end}(isTrial)';
            end
        end

        s.objOrg = struct;
        for i = 1:length(objOrder)
            s.objOrg(i).objName = objOrder{i};

            objPos = [];
            objPhase = [];
            objHD = [];
            objEnv = [];
            objBlocked = [];
            objTraj = [];
            objScale = [];
            for phase_i = 1:length(keep)
                isPhase = ismember(d{2},keep(phase_i));
                if nansum(isPhase)==0
                    continue
                end

                isObj = find(ismember(cat(2,s.(spaceSub(keep{phase_i})).objName),objOrder{i}));
                for trial_i = 1:length(isObj)
                    objPhase = [objPhase {spaceSub(keep{phase_i})}];
                    objPos = [objPos s.(spaceSub(keep{phase_i}))(isObj(trial_i)).pos(:,end)];
                    objHD = [objHD s.(spaceSub(keep{phase_i}))(isObj(trial_i)).hd(:,end)];
                    objEnv = [objEnv {s.(spaceSub(keep{phase_i}))(isObj(trial_i)).env}];
                    objBlocked = [objBlocked s.(spaceSub(keep{phase_i}))(isObj(trial_i)).env_blocked'];
                    objTraj = [objTraj {[s.(spaceSub(keep{phase_i}))(isObj(trial_i)).pos; ...
                        s.(spaceSub(keep{phase_i}))(isObj(trial_i)).hd]}];
                    objScale = [objScale {s.(spaceSub(keep{phase_i}))(isObj(trial_i)).scale}];
                end
            end

            s.objOrg(i).phase = objPhase;
            s.objOrg(i).pos = objPos;
            s.objOrg(i).hd = objHD;
            s.objOrg(i).trajectory = objTraj;
            s.objOrg(i).true_loc = s.(spaceSub(keep{phase_i}))(isObj(trial_i)).objP;
            s.objOrg(i).env = objEnv;
            s.objOrg(i).blocked = objBlocked;
            s.objOrg(i).scale = objScale;
        end

        checkP(outP);
        save(outP,'-struct','s','-v7.3');
        outPs = [outPs; {outP}];

        str = toc;
        fprintf([num2str(str) ' sec.']);

%         plotVRPaaths({[outP '.mat']});
    end
end
















