function plotMapPredExamples(a,b,c)
    
    inds = find(nansum(~all(all(isnan(c),1),2),4)==10);
    c2 = c(:,:,[inds([3 5 6 7 8])],[10 1:9]);

    tmp = cat(3,a(:,:,8,[10 1:9]),b(:,:,8,[10 1:9]),c2);

    s.maps = tmp;
    figure
    set(gcf,'position',[50 50 1600 1000])
    for k = 1:length(s.maps(1,1,:,1))
        catMaps = permute(mnorm(s.maps(:,:,k,1)),[2 1 3 4]);
        for j = 2:length(s.maps(1,1,1,:))
            catMaps = cat(2,catMaps,nan(length(s.maps(:,1,1,1)),1),mnorm(permute(s.maps(:,:,k,j),[2 1 3 4])));
        end
        subplot(length(s.maps(1,1,:,1)),1,k)
        imagesc(catMaps)
        axis equal
        alpha(double(~isnan(catMaps)))
        axis off
    end
    saveFig(gcf,'Plots/Experiment_1/Summary/ExamplePredictedMaps',[{'tiff'} {'pdf'}])
end