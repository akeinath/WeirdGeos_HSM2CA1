function m2hByNumObjects(hRSM,pRSM,crit,critName)


    doObjects = round(nanmin(nansum(crit),nansum(~crit))./100.*[10].^[0:0.25:2]);
    doObjects(doObjects<4) = [];
    nsims = 500;
    asFits = nan(length(doObjects),nsims,2);
    asJNC = nan(length(doObjects),2,nsims,2);
    for si = 1:nsims
        for objI = 1:length(doObjects)

            thrsm = hRSM(:,:,crit);
            tprsm = pRSM(:,:,crit);

            shuff = randperm(size(thrsm,3));
            thrsm = thrsm(:,:,shuff);
            tprsm = tprsm(:,:,shuff);
            [asFits(objI,si,1) asJNC(objI,:,si,1)] = ...
                help_shRSA(thrsm(:,:,1:doObjects(objI)),...
                tprsm(:,:,1:doObjects(objI)),[],1);

            thrsm = hRSM(:,:,~crit);
            tprsm = pRSM(:,:,~crit);

            shuff = randperm(size(thrsm,3));
            thrsm = thrsm(:,:,shuff);
            tprsm = tprsm(:,:,shuff);
            [asFits(objI,si,2) asJNC(objI,:,si,2)] = ...
                help_shRSA(thrsm(:,:,1:doObjects(objI)),...
                tprsm(:,:,1:doObjects(objI)),[],1);
        end
    end

    figure()
    set(gcf,'position',[50 50 300 300])
    doColors = jet(2).*0.75+0.25;    
    doColors = doColors([2 1],:);
    for di = 1:2
        semilogx(repmat(doObjects,[nsims 1])+0.025.* ...
            randn([nsims length(doObjects)]).*doObjects,asFits(:,:,di)',...
            'linestyle','none','color','none','marker','o', ...
            'markersize',3,'markerfacecolor',doColors(di,:).*0.25+0.75)
        hold on
        plot(doObjects,nanmedian(asFits(:,:,di),2)','marker','+','color',doColors(di,:).*0.5+0.5,'markersize',8,...
            'linestyle','-');
        h(di) = plot(doObjects,nanmedian(asFits(:,:,di),2)','marker','+','color',doColors(di,:),'markersize',8,...
            'linestyle','none','linewidth',2);
    end
    legend(h,[{'Is'} {'Is Not'}],'location','northwest')
    ylabel('Kendalls Tau')
    set(gca,'ylim',[0 1],'xlim',[3 (size(hRSM,3)./2).*1.3])
    xlabel('Number of Objects')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/MPred2HxNumObjectsx_' critName],[{'tiff'} {'pdf'}])
    drawnow

    %%%%%%%%%%%%

    figure()
    set(gcf,'position',[50 50 125 225])
    fits = permute(asFits(end,:,:),[2 3 1]);
    mkWhisker(fits,[{'Female'} {'Not'}],doColors)
    hold on
    set(gca,'ylim',[0 1])

    doPerc = 0.025;
    jnc = [];
    jointNoiseCeiling = permute(asJNC(end,:,:,:),[3 2 4 1]);
    for i = 1:length(jointNoiseCeiling(1,1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,1,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,1,i),1-doPerc)]];
    end
    
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    ylabel('Kendalls Tau')
    xlabel(critName)

    outP = ['Stats/Experiment_1/MPred2Hx_' critName '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    ntests = nchoosek(length(fits(1,:)),2);
    for i = 1:length(fits(1,:))
        for j = i+1:length(fits(1,:))

            fprintf(fid,['\nGroups:  ' num2str(i) ' vs. ' num2str(j)]);

            actual = abs(nanmean(fits(:,i))-nanmean(fits(:,j)));

            null = nan(10000,1);
            for q = 1:10000
                tmp = [fits(:,i); fits(:,j)];
                tmp = tmp(randperm(length(tmp)));
                tmp = [tmp(1:length(tmp)./2) tmp(length(tmp)./2+1:end)];
                null(q) = abs(nanmean(tmp(:,1))-nanmean(tmp(:,2)));
            end
            pval = nanmean(actual<null);

            str = sprintf('; \tActual = %0.3f, p = %0.4f, p (bonferroni) = %0.4f',[actual pval pval.*ntests]);
            fprintf(fid,str);
        end
    end
    fclose(fid);

    a = asFits(end,:,1);
    b = asFits(end,:,2);
    c = a(:)<[b(:)]';
    pval = nanmean(c(:));
    pval = nanmin(pval,1-pval).*2;

    text(1.5,1.05,sprintf('p = %0.4f',pval.*ntests),'fontname','arial','fontsize',9,'horizontalalignment','center')
    saveFig(gcf,['Plots/Experiment_1/Summary/MPred2Hx_' critName],[{'tiff'} {'pdf'}])
    drawnow
end
