function ap = dispxD2B(paths)
    close all

    [envLabel env_blocked] = envStuff();
    allDxD2B = [];

    partSize = (5./3);
    isX = -2.5:partSize:2.5-partSize;
    isY = -2.5:partSize:2.5-partSize;
    s = load(paths{1},'envSize');
    isX = isX.*(s.envSize(1)./5);
    isY = isY.*(s.envSize(1)./5);

    aab = repmat({[]},[1 length(envLabel)]);
    for i = 1:length(envLabel)
        ab = [];
        for j = 1:9
            if env_blocked(i,j)
                yp = mod(j-1,3);
                xp = floor((j-1)./3);
                bound = [-2.5+((5./3).*(yp)) ...
                    -2.5+((5./3).*(xp)) 5./3 5./3];
                bound = [bound(1) bound(2) bound(1)+bound(3) bound(2); ...
                    bound(1) bound(2) bound(1) bound(2)+bound(4); ...
                    bound(1)+bound(3) bound(2) bound(1)+bound(3) bound(2)+bound(4); ...
                    bound(1) bound(2)+bound(4) bound(1)+bound(3) bound(2)+bound(4)];
                ab = [ab; bound];
            end
        end
        aab{i} = ab.*(s.envSize(1)./5);
    end

%     wallPos = {[-]};


%     agg = nan(5,3,length(paths),length(envLabel));
%     aDisp_OF = [];
%     for p = paths'
%         fprintf(['\tPlotting displacement x Distance to Boundary:  ' slind(p{1},[1 3],'/.') '\n']);
% 
%         s = load(p{1},'objOrg');
% 
%         for k = 1:length(s.objOrg)
%             
%             isGood = ismember(s.objOrg(k).env,envLabel(end)); % Open Field
%             isGood(1:4) = false; % Ignore first four replacements from initial learning
%             rl_OF = s.objOrg(k).pos([1 3],isGood);
%             rl_OF = nanmean(rl_OF,2);
%             disp_OF = nanmean(sqrt(nansum(bsxfun(@minus,s.objOrg(k).pos([1 3],isGood),rl_OF).^2)));
%             aDisp_OF = [aDisp_OF; disp_OF];
% 
%             for envI = 1:length(envLabel)-1
%                 isGood = ismember(s.objOrg(k).env,envLabel(envI));
%                 isGood(1:4) = false; % Ignore first four replacements from initial learning
% 
%                 rl = s.objOrg(k).pos([1 3],isGood);
% %                 disp = nanmean(sqrt(nansum(bsxfun(@minus,rl,rl_OF).^2)));
%                 disp = sqrt(nansum(nanmean(rl,2)-rl_OF).^2);
% 
%                 aDist = [];
%                 for q = 1:size(aab{envI},1)
%                     aDist = [aDist; point_to_line(rl_OF,aab{envI}(q,1:2)',aab{envI}(q,3:4)')];
%                 end
%                 d2b = nanmin(aDist);
% 
%                 inPart = (nansum(isX<rl_OF(2),2)-1).*3 + nansum(isY<rl_OF(1),2);
%                 isBlocked = env_blocked(envI,inPart);
% 
%                 agg(k,:,ismember(paths,p),envI) = [d2b disp isBlocked];
%             end
%         end
%     end
% 
%     aagg = [];
%     for i = 1:length(paths)
%         aagg = cat(1,aagg,agg(:,:,i,:));
%     end
% 
%     tmp = [];
%     for i = 1:9
%         tmp = cat(1,tmp,aagg(:,:,:,i));
%     end
% 
%     toPlot = {tmp(logical(tmp(:,3)),2)};
%     stepSize = 0.2;
%     for i = 0:stepSize:5.*sqrt(2)-stepSize
%         toPlot = [toPlot tmp(~tmp(:,3) & tmp(:,1) >= i & tmp(:,1)< i+stepSize,2)];
%     end
% 
%     figure
%     set(gcf,'position',[50 50 350 275])
%     labels = [{'Closed'} num2cell([0:stepSize:5.*sqrt(2)-stepSize]+stepSize./2)];
%     mkBar(toPlot,labels,[0.3 0.3 0.9]);
%     set(gca,'xlim',[-1 length(toPlot(1,:))+2])
%     ylabel('Displacement (m)')
%     xlabel('Distance from nearest inserted boundary (m)');
%     saveFig(gcf,'Plots/Experiment_1/Summary/DispXD2B',[{'tiff'} {'pdf'}]);


    %%%%%%

    agg = nan(5,4,length(paths),length(envLabel)-1);
    aDisp_OF = [];
    outerBounds = [-(s.envSize'./2) (s.envSize'./2)];
    aCords = [];
    for p = paths'
        fprintf(['\tPlotting displacement x Distance to Boundary:  ' slind(p{1},[1 3],'/.') '\n']);

        s = load(p{1},'objOrg','fam_block_error','envSize');
        if nanmean(s.fam_block_error(:,end)) >= 1.5.*s.envSize(1)./5
            continue
        end

        for k = 1:length(s.objOrg)
            
            isGood = ismember(s.objOrg(k).env,envLabel(end)); % Open Field
            isGood(ismember(s.objOrg(k).phase,[{'Familiar_Replace_Trials'} ...
                    {'Familiar_Replace_Trials___No_Fog'}])) = false; % Ignore replacements from initial learning
            rl_OF = s.objOrg(k).pos([1 3],isGood);
            rl_OF = nanmedian(rl_OF,2);
            disp_OF = nanmean(sqrt(nansum(bsxfun(@minus,s.objOrg(k).pos([1 3],isGood),rl_OF).^2)));
            aDisp_OF = [aDisp_OF; disp_OF];

            cords = [];
            for envI = 1:length(envLabel)
                isGood = ismember(s.objOrg(k).env,envLabel(envI));
                isGood(ismember(s.objOrg(k).phase,[{'Familiar_Replace_Trials'} ...
                    {'Familiar_Replace_Trials___No_Fog'}])) = false; % Ignore replacements from initial learning

                rl = s.objOrg(k).pos([1 3],isGood);
                disp = nanmean(sqrt(nansum(bsxfun(@minus,rl,rl_OF).^2)));
                
                aDist = [];
                for q = 1:size(aab{envI},1)
                    aDist = [aDist; point_to_line(rl_OF,aab{envI}(q,1:2)',aab{envI}(q,3:4)')];
                end
                d2b = nanmin(aDist);

                inPart = (nansum(isX<rl_OF(2),2)-1).*3 + nansum(isY<rl_OF(1),2);
                isBlocked = env_blocked(envI,inPart);

                if envI == 10
                    d2b = nan;
                end

                tmp = rl_OF-outerBounds;
                agg(k,:,ismember(paths,p),envI) = [d2b disp isBlocked nanmin(abs(tmp(:)))];

% % %                 cords(envI,:) = nanmean(rl,2);

                cords(envI,:,:) = permute(rl,[3 1 2]);
            end
            aCords = cat(3,aCords,cords);
        end
    end

    %%%%% Make Vector Plots based on Coordinates %%%%%


    close all
    bins = 15;
    div = 5./bins;
    binEdges = [-2.5:div:2.5-div];
    thetaMap = nan(bins,bins,10);
    distMap = nan(bins,bins,10);
    uvMap = nan(bins,bins,10,2);
    for envI = 1:9
        for i = binEdges
            for j = binEdges
                isGood = aCords(10,1,:)>=i & aCords(10,1,:)<(i+div) & ...
                    aCords(10,2,:)>=j & aCords(10,2,:)<(j+div);
                if nansum(isGood) >= 2
                    xy = permute(aCords(envI,:,isGood) - aCords(10,:,isGood),[3 2 1]);

                    [t d] = cart2pol(nanmean(xy(:,1)),nanmean(xy(:,2)));
                    thetaMap(i==binEdges,j==binEdges,envI) = t;
                    distMap(i==binEdges,j==binEdges,envI) = d;

                    [t d] = cart2pol(xy(:,1),xy(:,2));
                    
                    uvMap(i==binEdges,j==binEdges,envI,:) = nanmean(xy);
                end
            end
        end

        atmp = [];
        for envJ = 1:9
            qxy = combvec(binEdges+div./2,binEdges+div./2);
            uv = permute(uvMap(:,:,envJ,:),[1 2 4 3]);
            ruv = reshape(uv,[length(binEdges).^2 2]);
            tmp = sqrt((ruv(:,1)).^2 + (ruv(:,2)).^2);
            atmp = [atmp; tmp];
        end
        crange = [nanmin(atmp) nanmax(atmp)];

        qxy = combvec(binEdges+div./2,binEdges+div./2);
        uv = permute(uvMap(:,:,envI,:),[1 2 4 3]);
        ruv = reshape(uv,[length(binEdges).^2 2]);
        tmp = sqrt((ruv(:,1)).^2 + (ruv(:,2)).^2);

        doC = v2rgb(tmp,crange);

        figure(1)
        set(gcf,'position',[50 50 600 600])
        subplot(3,3,envI)
        rectangle('position',[-2.5 -2.5 5 5])
        hold on
        for i = 1:size(qxy,2)
            if ~isnan(ruv(i,1))
                q = quiver(qxy(1,i)',qxy(2,i)',ruv(i,1),ruv(i,2),'off','color',doC(i,:),'maxheadsize',0.5);
    %             q.ShowArrowHead = 'off';
                q.Marker = '.';
            end
        end
        axis equal
        set(gca,'xlim',[-2.5 2.5],'ylim',[-2.5 2.5],'ydir','reverse')
        axis off
        title(envLabel{envI})
    end
    saveFig(gcf,['Plots/' slind(paths{1},[1 2]) '/Summary/VectorFlowDiagram'],[{'tiff'} {'pdf'}]);


    %%%%%%%

    aagg = [];
    for i = 1:length(paths)
        aagg = cat(1,aagg,agg(:,:,i,:));
    end

    tmp = [];
    for i = 1:9
        tmp = cat(1,tmp,aagg(:,:,:,i));
    end
    tmp(isnan(tmp(:,1)),:) = [];

    doFit = tmp(tmp(:,3)==0,1:2);
%     doFit(doFit(:,1)>3,:) = [];
    doFit(:,2) = doFit(:,2)-nanmedian(aDisp_OF);
    ap = fitDecay(doFit);
    % Mean distance to median square replace location, minus the median
    % square dispersion
    set(gca,'xlim',[-0.5 7])
    set(gca,'ylim',[-1 5])
    text(1,-0.5,sprintf('n = %i',nansum(~isnan(doFit(:,1)))));
    text(3,5,sprintf('y = p_2 * e^{(-p_1 * x)}'));
    text(3,4.5,sprintf('p_1 = %0.3f, i.q.r. = [%0.3f, %0.3f]',[getPercent(ap(:,1),0.5) getPercent(ap(:,1),0.25) getPercent(ap(:,1),0.75)]));
    text(3,4,sprintf('p_2 = %0.3f, i.q.r. = [%0.3f, %0.3f]',[getPercent(ap(:,2),0.5) getPercent(ap(:,2),0.25) getPercent(ap(:,2),0.75)]));
    set(gcf,'position',[50 50 450 350])
    saveFig(gcf,['Plots/' slind(paths{1},[1 2]) '/Summary/DispXD2B'],[{'tiff'} {'pdf'}]);

    %%%%%% By Both bounds and distance

    s = load(paths{1},'envSize');
    stepSize = 0.25.*s.envSize(1)./5;
    bins = 0:stepSize:2.5.*s.envSize(1)./5;
    toPlot = repmat({[]},[length(bins)]);
    for i = bins
        for j = bins
            toPlot{bins==i,bins==j} = [tmp(~tmp(:,3) & tmp(:,1) >= i & tmp(:,1)< i+stepSize & ...
                ~tmp(:,3) & tmp(:,4) >= j & tmp(:,4) < j+stepSize,2)];
        end
    end

    v = cellfun(@nanmedian,toPlot);
    vn = cellfun(@length,toPlot);
    v(vn<5) = nan;

    figure
    set(gcf,'position',[50 50 325 275])
    imagesc(bins,bins,v)
    alpha(double(~isnan(v)))
    colormap jet
    colorbar
    caxis([0 nanmax(v(:))])
    xlabel('D2Bounds')
    ylabel('D2Inserted')
    set(gca,'ydir','normal')
    axis square
    saveFig(gcf,['Plots/' slind(paths{1},[1 2]) '/Summary/AccessibleD2B_by_D2Bounds'],[{'tiff'} {'pdf'}]);

    %%%%%%% By Environment

    tmp2 = repmat({[]},[2 10]);
    for i = 1:10
        a = aagg(:,:,:,i);
        tmp2{1,i} = a(a(:,3)==0,2);
        tmp2{2,i} = a(a(:,3)==1,2);
    end
    
    figure
    set(gcf,'position',[50 50 225 225])
    aggVals = [{cat(1,tmp2{2,1:9})} {cat(1,tmp2{1,1:9})} {cat(1,tmp2{1,10})}];
    mkWhisker(aggVals,[{'Enclosed'} {'Accessible'} {'Open Field'}],[0.2 0.2 0.9; 0.4 0.4 0.8; 0 0 0])

    [a b c] = ranksum(aggVals{1},aggVals{3});
    sprintf(['Z(%i) = %0.3f, p = %0.3e'],[c.ranksum c.zval a])

    figure
    set(gcf,'position',[50 50 225 225])
    mkWhisker(tmp2(1,1:10),envLabel,zeros(10,3))
    saveFig(gcf,['Plots/' slind(paths{1},[1 2]) '/Summary/AccessibleD2B_by_env'],[{'tiff'} {'pdf'}]);

    ap = nan(1,9);
    for i = 1:9
        ap(i) = ranksum(tmp2{1,i},tmp2{1,10});
    end

    %%%%%%%%

    toPlot = {tmp(logical(tmp(:,3)),2)};
    s = load(paths{1},'envSize');
    stepSize = 0.1.*s.envSize(1)./5;
    for i = 0:stepSize:1.5.*s.envSize(1)./5
        toPlot = [toPlot tmp(~tmp(:,3) & tmp(:,1) >= i & tmp(:,1)< i+stepSize,2)];
    end
    toPlot = [toPlot(2:end)];
%     scat = [ones(nansum(tmp(:,3)),1).*-0.25+randn(nansum(tmp(:,3)),1).*0.025 ...
%         tmp(logical(tmp(:,3)),2)];
%     scat = [scat; tmp(~tmp(:,3),1:2)];

    figure
    set(gcf,'position',[50 50 350 275])

    labels = [num2cell([0:stepSize:1.5.*s.envSize(1)./5]+stepSize./2)];
%     plot(scat(:,1),scat(:,2),'linestyle','none','marker','o','color',[0.8 0.8 0.8])
    hold on
    mkWhisker(toPlot,labels,cool(length(toPlot)));
    set(gca,'xlim',[-1 length(toPlot(1,:))+2])
    plot(get(gca,'xlim'),nanmedian(aDisp_OF).*ones(1,2),'color',[0.25 0.25 0.25],'linestyle',':');
    ylabel('Mean displacement from square replace (m)')
    xlabel('Distance from nearest inserted boundary (m)');
    set(gca,'ylim',[0 6])

    outP = ['Stats/DisplacementXDistance2Partition.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    fprintf(fid,'\t\t\tDisplacement X Distance2Partition Rank-Sum versus Open Field Displacement\n');
    aSig = false(1,length(toPlot));
    apv = [];
    for i = 1:length(toPlot)
        try
            [pval b c] = ranksum(toPlot{i},aDisp_OF);
            fprintf(fid,['\nGroup:  ' num2str(labels{i})]);
            fprintf(fid,',  Z(%i)=%0.3f, p=%0.3e ',c.ranksum,c.zval,pval);
            aSig(i) = pval<0.05;
            apv(i) = pval;
        end
    end
    fclose(fid);

    sigLocs = get(gca,'xtick');
    sigLocs = sigLocs(logical(aSig));
    text(sigLocs,ones(1,length(sigLocs)).*nanmax(get(gca,'ylim')).*0.95,'*','fontname','arial', ...
        'fontsize',11,'fontweight','bold','horizontalalignment','center');

    saveFig(gcf,['Plots/' slind(paths{1},[1 2]) '/Summary/DispXD2B_Binned'],[{'tiff'} {'pdf'}]);
    
end


































