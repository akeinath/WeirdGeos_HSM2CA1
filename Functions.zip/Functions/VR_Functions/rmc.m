function vals = rmc(h,p,doPlot)

    if nargin < 3 || isempty(doPlot)
        doPlot = true;
    end

    rh = reshape(h,[numel(h(:,:,1,1)) size(h,[3 4])]);
    rp = reshape(p,[numel(p(:,:,1,1)) size(p,[3 4])]);

    vals = nan(size(rh,[2 3]));
    for i = 1:size(rh,3)
        a = rh(:,:,i);
        b = rp(:,:,i);

        isGood = ~any(isnan(a),2)&~any(isnan(b),2);
        xc = corr(a(isGood,:),b(isGood,:));
        vals(:,i) = xc(logical(eye(size(xc))));
    end

    if doPlot

        [envLabel env_blocked] = envStuff();
    
        [a reorder] = sort(nanmedian(vals));
    
        envLabel = envLabel(reorder);
        vals = vals(:,reorder);
    
        figure
        set(gcf,'position',[50 50 350 225])
        mkWhisker(atanh(vals(:,1:end-1)),envLabel(1:end-1),cool(9))
        hold on
        plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
        set(gca,'ylim',[-3.5 3.5])
        saveFig(gcf,'Plots/Experiment_1/Summary/RMC_H2Pred',[{'tiff'} {'pdf'}])
    
        fid = fopen('Stats/RateMapCorrelationComparison.txt','w');
        fprintf(fid,'\nKruskal-Wallis test:\n');
        [a b c] = kruskalwallis((vals(:,1:9)),[],'off');
        for j = 1:length(b(:,1))
            tp = [];
            for i = 1:length(b(1,:))
                tp = [tp num2str(b{j,i}) ',\t'];
            end
            fprintf(fid,[tp '\n']);
        end
    
    
        fprintf(fid,'\nRank-sum contrasts:\n');
        for i = 1:9
            for j = i+1:9
                [a b c] = ranksum(vals(:,i),vals(:,j));
                str = sprintf('Z(%i) = %0.3f, p = %0.2e',[c.ranksum abs(c.zval) a]);
                fprintf(fid,['\n' envLabel{i} ' vs ' envLabel{j}]);
                fprintf(fid,[', ' str]);
                if a<0.001
                    fprintf(fid,[' *']);
                end
            end
        end
        fclose(fid);
    
    
        rah = h(:,:,:,reorder);
        rv = repmat(permute(vals,[3 4 1 2]),[15 15]);
        rah(rah==0) = nan;
        rrv = rv.*(rah);
        rrv(isnan(rah)) = nan;
    
        weightedAverage = nansum(rrv,3)./nansum(rah,3);
        maps = permute(weightedAverage,[2 1 4 3]);
        catMaps = maps(:,:,1);
        for j = 2:length(maps(1,1,:))-1
            catMaps = cat(2,catMaps,nan(length(maps(:,1,1)),1),maps(:,:,j));
        end
    
        figure
        set(gcf,'position',[50 50 1200 300])
        imagesc(catMaps)
        axis equal
        alpha(double(~isnan(catMaps)))
        axis off
        caxis([round(nanmin(catMaps(:)).*20)./20 ...
            round(nanmax(catMaps(:)).*20)./20])
        colorbar
        saveFig(gcf,'Plots/Experiment_1/Summary/RMC_H2Pred_X_Location',[{'tiff'} {'pdf'}])
    end
end
















