function getAcc(paths,recompute)

    if nargin < 2 || isempty(recompute)
        recompute = false;
    end

    clc

    fprintf('\n\ngetAcc()\n\n');

    for p = paths'

        s = load(p{1},'fam_error');
        
        if ~recompute && ~isempty(fieldnames(s))
            continue
        end

        fprintf(['\tComputing accuracy:  ' slind(p{1},[1 3],'\/.') '... ']);

        s = load(p{1});

        famError = [];
        famSpread = [];
        for i = 1:length(s.objOrg)
            tmp = nansum([s.objOrg(i).pos([1 3],:)-s.objOrg(i).true_loc'].^2,1).^(1./2);
            famError = [famError; tmp(ismember(s.objOrg(i).env,{'OpenField'}))];

            tmp = s.objOrg(i).pos([1 3],ismember(s.objOrg(i).env,{'OpenField'}));
            tmp = nansum([tmp-nanmean(tmp(:,5:end),2)].^2,1).^(1./2);
            famSpread = [famSpread; nanmean(tmp(:,5:end))];
        end

        close all
        
        figure(1)
        set(gcf,'position',[50 50 300 225])
        mkGraph(famError,[1:length(famError(1,:))],[0.3 0.3 0.9]);
        xlabel('Trial number')
        ylabel('Error (vm)')
        figP = ['Plots/' slind(p{1},[1 3],'/\.') '/OpenFieldError'];
        saveFig(gcf,figP,[{'tiff'} {'pdf'}])
        s.fam_error = famError;
        s.fam_spread = famSpread;

        save(p{1},'-struct','s','-v7.3');
        fprintf('Done.\n');
    end
end