function plotVRPaths(paths)

    [envLabel env_blocked] = envStuff();

    warning off all

    for p = paths'
        figP = ['Plots/' slind(p{1},[1 3],'/\.') '/Replace_Trajectories'];
        if exist([figP '.pdf'])==2
            continue
        end

        s = load(p{1});

        doColors = inferno(7);
        doColors = doColors(2:end-1,:);

        close all

        figure
        set(gcf,'position',[50 50 1400 200])
        
        if isfield(s.Block_1(1),'scale')
            doScale = s.Block_1(1).scale(1);
        else
            doScale = 1;
        end

        hold on
        for i = 1:length(envLabel)
            xShift = i-1;
            for j = 1:9
                if env_blocked(i,j)
                    yp = mod(j-1,3);
                    xp = floor((j-1)./3);
                    rectangle('position',[-2.5+6.*xShift+((5./3).*(yp)) ...
                        -2.5+((5./3).*(xp)) 5./3 5./3].*doScale,'facecolor',[0.8 0.8 0.8],...
                        'edgecolor','white')
                end
            end
            rectangle('position',[-2.5+6.*xShift -2.5 5 5].*doScale,'edgecolor','k')
        end

        nBlocks = nansum(cellfun(@contains,fieldnames(s),repmat({'Block'},size(fieldnames(s)))));
        for i = 1:nBlocks
            for j = 1:length(s.(['Block_' num2str(i)]))

                xShift = find(ismember(envLabel,s.(['Block_' num2str(i)])(j).env))-1;
                plot(doScale.*6.*xShift+s.(['Block_' num2str(i)])(j).pos([1],:),s.(['Block_' num2str(i)])(j).pos([3],:),...
                    'linestyle','-','color',doColors(str2num(s.(['Block_' num2str(i)])(j).objName{1}),:))
                hold on
                plot(doScale.*6.*xShift+s.(['Block_' num2str(i)])(j).pos([1],end),s.(['Block_' num2str(i)])(j).pos([3],end),...
                    'marker','d','color',doColors(str2num(s.(['Block_' num2str(i)])(j).objName{1}),:),...
                    'markerfacecolor',doColors(str2num(s.(['Block_' num2str(i)])(j).objName{1}),:))
            end
        end
        axis equal
        axis off
        set(gca,'ylim',[-3 3].*doScale,'xlim',[-3 57].*[doScale doScale],'ydir','reverse')

        saveFig(gcf,figP,[{'tiff'} {'pdf'}])
    end
end