function rsa_h2hip_partitions(p)

    

    s = load(p{1},'envSize');
    [h hstats] = aggReplaceMaps(p,1.5.*s.envSize(1)./5);
    ah = nanmean(cat(5,h{:}),5);
    allHumanMaps = [h; {ah}];
%     [m mfr spm samp orders] = getMouseMaps();
%     save('mouse.mat','m','spm','mfr','samp','orders','-v7.3');

    load('mouse.mat');

    % Grid search for smoothing parameters (commented out for run-time)
% % %     [hSmooth mSmooth] = rsaXSmooth_partitions([slind(p{1},[1 2]) '/Partition_SmoothingParameters'],allHumanMaps(end),m);

    hSmooth = 2.25; 
    mSmooth = 1.75;
    [rsm.overall.human rsm.partition.human shm] = m2rsm(allHumanMaps,hSmooth); % 2.5
    [rsm.overall.mouse_raw rsm.partition.mouse_raw sm] = m2rsm(m,mSmooth); % 1.75
    allMouseMaps = [{cat(3,sm{1,:})}; {cat(3,sm{2,:})}; {cat(3,sm{3,:})}; {cat(3,sm{:})}];
    predictedHumanMaps = predictMaps(allHumanMaps(end),{cat(3,sm{:})},[],[],[]);
    [rsm.overall.mouse_pred rsm.partition.mouse_pred rsm.pixel.mouse_pred] = m2rsm(predictedHumanMaps,-1);

    fits = shRSA([slind(p{1},[1 2]) '/Partition_RSA'],rsm.partition.human{end},repmat(eye(9),[10 10 size(rsm.partition.human{end},3)]), ...
        rsm.partition.mouse_pred); %repmat(-dmat,[10 10 size(hRSM{end},3)])
    drawnow

    % make stable mouse prediction
    tmp = repmat(allMouseMaps{end}(:,:,:,10),[1 1 1 10]);
    tmp(isnan(allMouseMaps{end})) = nan;
    predictedStableMaps = predictMaps(allHumanMaps(end),{tmp},[],[],[]);
    [rsm.overall.mouse_pred_stable rsm.partition.mouse_pred_stable ...
        rsm.pixel.mouse_pred_stable] = m2rsm(predictedStableMaps,-1);
    
%     % Make human stable prediction
%     tmp = repmat(ah(:,:,:,10),[1 1 1 10]);
%     tmp(isnan(ah)) = nan;
%     [rsm.overall.human_stable rsm.partition.human_stable ...
%         human_stable_maps rsm.pixel.human_stable] = m2rsm(tmp,hSmooth);

    % residual analysis
    residAnalysis([slind(p{1},[1 2]) '/Partition_RSA'],(rsm.partition.human{end}), ...
        (rsm.partition.mouse_pred),(rsm.partition.mouse_pred_stable)) 

    % RSA with combination of stable RSM and mouseRSM
    multiRSA([slind(p{1},[1 2]) '/Partition_RSA'],(rsm.partition.human{end}), ...
        (rsm.partition.mouse_pred),(rsm.partition.mouse_pred_stable));
    
    % Plot example
    plotMapPredExamples(shm{end},predictedHumanMaps{end},sm{3,3})

    % impact of learning
% % %     m2hAcrossSequences(rsm.partition.human,allHumanMaps,allMouseMaps)
% % %     m2hAcrossBlocks(rsm.partition.human,allHumanMaps,allMouseMaps)

    % impact of number of cells (But which cells?!)
% % %     m2hByNumCells(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end))
% % %     m2hByNumObjects(rsm.partition.human{end},rsm.partition.mouse_pred)

    % impact of various criteria on fit x number of cells cells
    [spatialInfo splitHalf] = getMouseMapStats(m,spm,samp,mSmooth); % WRITE THIS
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),mfr,'MFR'); % 1088
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),spatialInfo,'SI'); % 1080
    m2hxNumCellsXCrit(rsm.partition.human{end},allHumanMaps(end),allMouseMaps(end),splitHalf,'SHC'); % 865

    % impact by which humans?
    m2hByNumObjectsxCrit(rsm.partition.human{end},rsm.partition.mouse_pred,hstats.fam_block_error(:,end),'FamError');
    m2hByNumObjectsxCrit(rsm.partition.human{end},rsm.partition.mouse_pred,hstats.fam_block_spread(:,end),'FamSpread');
% % %     m2hByNumObjectsxCrit(rsm.partition.human{end}(:,:,~isnan(hstats.sbsod)), ...
% % %         rsm.partition.mouse_pred(:,:,~isnan(hstats.sbsod)),hstats.sbsod(~isnan(hstats.sbsod)),'SBSOD');
    m2hByNumObjectsxBinaryCrit(rsm.partition.human{end},rsm.partition.mouse_pred,hstats.gender=='F','isFemale');
end









































