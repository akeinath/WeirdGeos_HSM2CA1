function [allMaps minclude] = predictMaps(ah,am,sd,minclude,threshold)

    %% This function takes in the human memory maps, the mouse maps, and possibly a mouse
    %% map smoothing kernel and returns the Matched Mouse Maps
    %% This function utilizes ParFor parallel looping

    if nargin < 3 || isempty(sd)
        sd = -1;
    end

    if nargin < 4 || isempty(minclude)
        minclude = inf;
    end

    if nargin < 5 || isempty(threshold)
        threshold = 0;
    end



    allMaps = repmat({[]},[numel(ah) numel(am)]);

%     fprintf('\n\t\t\tGenerating Human Map predictions from mouse maps... ');
    tic
    for q = 1:numel(ah)
        for p = 1:numel(am)

            h = ah{q};
            m = am{p};

            if sd > 0
                kern = fspecial('gauss',[size(m,[1]).*3.*ones(1,2)],sd);
                isBad = isnan(m);
                m(isBad) = 0;
                m = imfilter(m,kern,'same');
                m(isBad) = nan;
            end

            m = mnorm(m);

            m = m-threshold;
            m(m<0) = 0;
            m = mnorm(m);

            rAMM = reshape(m,[numel(m(:,:,1,1)) size(m,[3 4])]);
            rAHM = reshape(h,[numel(h(:,:,1,1)) size(h,[3 4])]);
        
            sqH = rAHM(:,:,10);
            sqH = bsxfun(@rdivide,sqH,nansum(sqH));
        
            sqM = rAMM(:,:,10);
            ensemble = permute(nansum(bsxfun(@times,sqM,permute(sqH,[1 3 2]))),[2 3 1]);
            doExclude1 = all(isnan(sqM));
        
            simMaps = nan(15,15,length(ensemble(1,:)),10);

            minInds = inf;
            parfor j = 1:10 % parfor
                possible = rAMM(:,:,j);
                for k = 1:length(possible(:,1))
                    doExclude2 = (isnan(possible(k,:)))|doExclude1;
                    if all(doExclude2)
                        continue
                    end
                    minInds = nanmin(minInds,nansum(~doExclude2));
                end
            end
            if isinf(minclude)
                minclude = minInds;
            end

            parfor j = 1:10 % parfor
                possible = rAMM(:,:,j);
                possMap = nan(15.^2,length(ensemble(1,:)));
                for k = 1:length(possible(:,1))
                    doExclude2 = (isnan(possible(k,:)))|doExclude1;
                    if all(doExclude2)
                        continue
                    end
                    inds = find(~doExclude2);
                    inds = inds(randperm(length(inds)));
                    if ~(isinf(minclude))
                        inds = inds(1:minclude); % Include a random XXX cells
                    end
                    doInc = false(size(doExclude2));
                    doInc(inds) = true;

                    possMap(k,:) = corr(ensemble(doInc,:),possible(k,doInc)','type','pearson');

%                     possMap(k,:) =1-pdist2(ensemble(doInc,:)',possible(k,doInc),'cosine');
                end
                rpm = reshape(possMap,[15 15 length(ensemble(1,:))]);
                simMaps(:,:,:,j) = rpm;
            end

            allMaps{q,p} = simMaps;
        end
    end

%     tmp = toc;
%     fprintf('  %0.3fs. Minimum cells = %i',[tmp]);

end