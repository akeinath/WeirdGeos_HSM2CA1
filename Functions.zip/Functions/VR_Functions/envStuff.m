function [envLabel env_blocked] = envStuff()
    
    envLabel = [{'OpenField'} {'Glenn'} {'T'} {'+'} {'BitDonut'} {'O'} {'U'} {'Rect'} {'I'} {'L'}];
    
    env_blocked = [0 0 0 0 0 0 0 0 0; ... % Open Field
    1 0 0 0 0 0 0 0 1; ... % Glenn
    0 0 0 1 0 1 1 0 1; ... % T
    1 0 1 0 0 0 1 0 1; ... %+
    1 0 0 0 1 0 0 0 0; ... %bit donut
    0 0 0 0 1 0 0 0 0; ... %O
    0 0 0 0 1 1 0 0 0; ... %C
    1 0 0 1 0 0 1 0 0; ... %rect
    0 0 0 1 0 1 0 0 0; ... %I
    0 1 1 0 1 1 0 0 0]; % L

    canonOrder = [4 5 2 9 10 6 8 3 7 1];
    envLabel = envLabel(canonOrder);
    env_blocked = env_blocked(canonOrder,:);
end