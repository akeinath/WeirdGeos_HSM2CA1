function rsa_h2hip_groupComp(varargin)
    clc
    load('mouse.mat');

    % Overall Map Predictions
    groupMaps = repmat({[]},[1 length(varargin)]);
    i = 0;
% % %     smoothParams = [{'Experiment_2_Fog_Combined'} {1.75} {3.00} {2.00} {1.75}; ...
% % %         {'Experiment_1'} {1} {2.5} {2.25} {1.75}; ...
% % %         {'Experiment_3_LargeRoom_Combined'} {1.5} {3.00} {2.00} {1.75}];

    smoothParams = [{'Experiment_2_Fog_Combined_ToShare'} {1.00} {2.50} {2.25} {1.75}; ...
        {'Experiment_1_ToShare'} {1} {2.5} {2.25} {1.75}; ...
        {'Experiment_3_LargeRoom_Combined_ToShare'} {1} {2.5} {2.25} {1.75}];

    phm = repmat({[]},[length(varargin) 2]);
    hm = repmat({[]},[length(varargin) 2]);
    for paths = varargin
        i = i+1;
        p = paths{1};
        s = load(p{1},'envSize');
        [h hstats] = aggReplaceMaps(p,1.5.*s.envSize(1)./5);
        groupMaps{i} = nanmean(cat(5,h{:}),5);

        isSmooth = ismember(smoothParams(:,1),slind(varargin{i}{1},[1 2]));
        hSmooth = smoothParams{isSmooth,2};
        mSmooth = smoothParams{isSmooth,3};
        [rsm.overall.mouse_raw rsm.partition.mouse_raw sm] = m2rsm(m,mSmooth); 
        phm(i,1) = predictMaps({groupMaps{i}},{cat(3,sm{:})},[],[],[]);
        [rsm.overall.human rsm.partition.human hm(i,1)] = m2rsm(groupMaps{i},hSmooth);
        
        hSmooth = smoothParams{isSmooth,4};
        mSmooth = smoothParams{isSmooth,5};
        [rsm.overall.mouse_raw rsm.partition.mouse_raw sm] = m2rsm(m,mSmooth); 
        phm(i,2) = predictMaps({groupMaps{i}},{cat(3,sm{:})},[],[],[]);
        [rsm.overall.human rsm.partition.human hm(i,2)] = m2rsm(groupMaps{i},hSmooth);
    end

    doNumMaps = nanmin(cellfun(@size,groupMaps,repmat({3},size(groupMaps))));
    doSims = 500;
    allFits = nan(doSims,length(varargin),2);
    fprintf('\n\tComparing Groups... \n\t\t')
    str = '';
    btwOverall = nan(doSims,2);
    btwPartition = nan(doSims,2);
    jnc2m = nan(doSims,length(varargin),2);
    for i = 1:length(groupMaps)
        for si = 1:doSims
            fprintf(repmat('\b',[1 length(str)]));
            str = sprintf('Group %i of %i, Random Sampling (without replacement) %i of %i',[i length(groupMaps) si doSims]);
            fprintf(str);

            doI = randi(size(hm{i,1},3),doNumMaps,1);
    
            [rsm.overall.human rsm.partition.human shm] = m2rsm(hm{i,1}(:,:,doI,:),-1); 
            [rsm.overall.mouse_pred rsm.partition.mouse_pred spm] = m2rsm(phm{i,1}(:,:,doI,:),-1);
            [allFits(si,i,1) b] = help_shRSA(rsm.overall.mouse_pred,rsm.overall.human,[],1);
            jnc2m(si,i,1) = b(1);

            [rsm.overall.human rsm.partition.human shm] = m2rsm(hm{i,2}(:,:,doI,:),-1); 
            [rsm.overall.mouse_pred rsm.partition.mouse_pred spm] = m2rsm(phm{i,2}(:,:,doI,:),-1);
            [allFits(si,i,2) b] = help_shRSA(rsm.partition.mouse_pred,rsm.partition.human,[],1);
            jnc2m(si,i,2) = b(1);

            for j = i+1:length(groupMaps)

                doI = randi(size(hm{i,1},3),doNumMaps,1);
                [o1] = m2rsm(hm{i,1}(:,:,doI,:),-1);
                [~, p1] = m2rsm(hm{i,2}(:,:,doI,:),-1);
    
                doI = randi(size(hm{j,1},3),doNumMaps,1);
                [o2] = m2rsm(hm{j,1}(:,:,doI,:),-1);
                [~, p2] = m2rsm(hm{j,2}(:,:,doI,:),-1);
    
                [tmp b] = help_shRSA(o1,o2,[],1);
                btwOverall(si,:) = [tmp b(1)];
    
                [tmp b] = help_shRSA(p1,p2,[],1);
                btwPartition(si,:) = [tmp b(1)];
            end
        end
    end

    labels = [];
    for i = 1:length(varargin)
        labels = [labels {slind(varargin{i}{1},[1 2])}];
    end

    figure
    set(gcf,'position',[50 50 200 225])
    subplot(1,2,1)
    jnc = [];
    doPerc = 0.025;
    jointNoiseCeiling = jnc2m(:,:,1);
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    mkWhisker(allFits(:,:,1),labels,[0.6 0.6 0.6; 0.4 0.4 0.8; 0.8 0.4 0.4])
    set(gca,'ylim',[0 1]);
    subplot(1,2,2)
    jnc = [];
    doPerc = 0.025;
    jointNoiseCeiling = jnc2m(:,:,2);
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    mkWhisker(allFits(:,:,2),labels,[0.6 0.6 0.6; 0.4 0.4 0.8; 0.8 0.4 0.4])
    set(gca,'ylim',[0 1]);

    outP = ['Stats/Group_Comparison_' cat(2,labels{:}) '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    for gi = 1:length(varargin)-1
        for gj = gi+1:length(varargin)
            [a b c] = ranksum(allFits(:,gi,1),allFits(:,gj,1));
            fprintf(fid,['\n\n\t\t****Group ' slind(varargin{gi}{1},[1 2]) '\tVS\t' slind(varargin{gj}{1},[1 2]) '****']);
            fprintf(fid,'\n\nOverall fits (Rank-sum): z(%i) = %0.3f, p = %0.4e',[c.ranksum c.zval a]);
            [a b c] = ranksum(allFits(:,gi,2),allFits(:,gj,2));
            fprintf(fid,'\nPartition fits (Rank-sum): z(%i) = %0.3f, p = %0.4e',[c.ranksum c.zval a]);

            a = allFits(:,:,1);
            tmp = bsxfun(@gt,a(:,gi),a(:,gj)');
            pval_overall = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;

            a = allFits(:,:,2);
            tmp = bsxfun(@gt,a(:,gi),a(:,gj)');
            pval_partitions = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
            fprintf(fid,'\nNonparametric shuffles: Overall p = %0.4e; Partitions p = %0.4e',[pval_overall pval_partitions]);
        end
    end
    subplot(1,2,1)
    text(1.5,1.05,sprintf('p = %0.4f',pval_overall),'fontname','arial','fontsize',9,'horizontalalignment','center')
    subplot(1,2,2)
    text(1.5,1.05,sprintf('p = %0.4f',pval_partitions),'fontname','arial','fontsize',9,'horizontalalignment','center')
    drawnow
    root = ['Plots/BetweenGroups/' cat(2,labels{:}) '_ToMouse'];
    saveFig(gcf,root,[{'pdf'} {'tiff'}])
    fclose(fid)


    figure
    set(gcf,'position',[50 50 200 225])
    doPerc = 0.025;
    subplot(1,2,1)
    jnc = [];
    jointNoiseCeiling = btwOverall(:,2);
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    hold on
    mkWhisker(btwOverall(:,1),labels,[0.6 0.6 0.6; 0.4 0.4 0.8; 0.8 0.4 0.4])
    ylabel('Kendalls Tau')
    xlabel('Overall')
    set(gca,'ylim',[0 1]);
    tmp = bsxfun(@gt,btwOverall(:,1),btwOverall(:,2)');
    pval_btwOverall = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
    text(1.5,1.05,sprintf('p = %0.4f',pval_btwOverall),'fontname','arial','fontsize',9,'horizontalalignment','center')
    subplot(1,2,2)
    jnc = [];
    jointNoiseCeiling = btwPartition(:,2);
    for i = 1:length(jointNoiseCeiling(1,:))
        jnc = [jnc [getPercent(jointNoiseCeiling(:,i),doPerc); ...
            getPercent(jointNoiseCeiling(:,i),1-doPerc)]];
    end
    x = [[1:length(jnc(1,:))]-0.45; [1:length(jnc(1,:))]+0.45; ...
        [1:length(jnc(1,:))]+0.45; [1:length(jnc(1,:))]-0.45];
    patch(x,jnc([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    hold on
    mkWhisker(btwPartition(:,1),labels,[0.6 0.6 0.6; 0.4 0.4 0.8; 0.8 0.4 0.4])
    ylabel('Kendalls Tau')
    xlabel('Parititon')
    set(gca,'ylim',[0 1]);
    tmp = bsxfun(@gt,btwPartition(:,1),btwPartition(:,2)');
    pval_btwPartition = nanmin(nanmean(tmp(:)),1-nanmean(tmp(:))).*2;
    text(1.5,1.05,sprintf('p = %0.4f',pval_btwPartition),'fontname','arial','fontsize',9,'horizontalalignment','center')
    root = ['Plots/BetweenGroups/' cat(2,labels{:}) '_ToEachOther'];
    saveFig(gcf,root,[{'pdf'} {'tiff'}])



    o1 = m2rsm(hm{1,1},-1); 
    o2 = m2rsm(hm{2,1},-1); 
    
    [~, p1] = m2rsm(hm{1,2},-1); 
    [~, p2] = m2rsm(hm{2,2},-1); 
    

    figure
    set(gcf,'position',[50 50 700 250])
    subplot(1,2,1)
    tmp = nanmean(o1,3);
    tmp2 = nanmean(o2,3);
    tmp(triu(true(size(tmp)))) = tmp2(triu(true(size(tmp))));
    imagesc(tmp);
    colorbar
    colormap inferno
    alpha(double(~isnan(tmp)))
    axis equal
    axis square
    axis off

    subplot(1,2,2)
    tmp = nanmean(p1,3);
    tmp2 = nanmean(p2,3);
    
    tmp(triu(true(size(tmp)))) = tmp2(triu(true(size(tmp))));
    doEx = all(isnan(tmp),2);
    tmp(doEx,:) = [];
    tmp(:,doEx) = [];
    imagesc(tmp);
    colorbar
    colormap inferno
    alpha(double(~isnan(tmp)))
    axis equal
    axis square
    axis off

    root = ['Plots/BetweenGroups/' cat(2,labels{:}) '_RSMComp'];
    saveFig(gcf,root,[{'pdf'} {'tiff'}])

end









































