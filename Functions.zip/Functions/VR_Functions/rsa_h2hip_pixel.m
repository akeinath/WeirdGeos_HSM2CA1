function rsa_h2hip(p)

    [h hstats] = aggReplaceMaps(p,1.5);
    ah = nanmean(cat(5,h{:}),5);
    allHumanMaps = [h; {ah}];
    load('mouse.mat');

    [hSmooth mSmooth] = rsaXSmooth_pixels([slind(p{1},[1 2]) '/Pixels_SmoothingParameters'],allHumanMaps(end),m);

%     hSmooth = 2.5;
%     mSmooth = 1.75;

    [rsm.overall.human rsm.partition.human shm rsm.pixel.human] = m2rsm(allHumanMaps,hSmooth,true,true); % 1 <---- overall optimal | partition --> 5 (doesn't matter above 2) | Part Raw ---> 2.5
    [rsm.overall.mouse_raw rsm.partition.mouse_raw sm rsm.pixel.mouse_raw] = m2rsm(m,mSmooth,true,true); % 2.5 <---- overall optimal | partition --> 2.75 | Part Raw --> 1.75
    allMouseMaps = [{cat(3,sm{1,:})}; {cat(3,sm{2,:})}; {cat(3,sm{3,:})}; {cat(3,sm{:})}];
    predictedHumanMaps = predictMaps(allHumanMaps(end),{cat(3,sm{:})},[],[],[]); %allHumanMaps(end) **********
    [rsm.overall.mouse_pred rsm.partition.mouse_pred spm rsm.pixel.mouse_pred] = m2rsm(predictedHumanMaps,-1,true,true);

    val = nan(100,1);
    jnc = nan(100,1);
    for i = 1:100
        a = randi(size(allHumanMaps{end},3),size(allHumanMaps{end},3),1);
        doMaps = shm{end}(:,:,a,:);
        phm = spm{end}(:,:,a,:);
        [~, ~, ~, h] = m2rsm({doMaps},-1,true,true);
        [~, ~, ~, m] = m2rsm({phm},-1,true,true);

        val(i) = estKendall(h,m);

        tmp = cat(5,doMaps,phm);
        doFlip = rand(size(doMaps,3),1)<0.5;
        doFlip = mod([doFlip+1 doFlip+2],2)+1;
        for q = 1:length(doFlip(:,1))
            tmp(:,:,q,:,:) = tmp(:,:,q,:,doFlip(q,:));
        end

        [~, ~, ~, nh] = m2rsm({tmp(:,:,:,:,1)},-1,true,true);
        [~, ~, ~, nm] = m2rsm(tmp(:,:,:,:,2),-1,true,true);

        jnc(i) = estKendall(nh,nm);
    end
    


end









































