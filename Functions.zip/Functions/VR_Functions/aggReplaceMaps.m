function [aggMaps hstats] = aggReplaceMaps(paths,threshold)

    if nargin < 2 || isempty(threshold)
        threshold = inf;
    end

    warning off all

    hstats = struct;
    hstats.subNum = [];
    hstats.age = [];
    hstats.gender = [];
    hstats.sbsod = [];
    hstats.fam_error = [];
    hstats.fam_spread = [];
    hstats.fam_block_error = [];
    hstats.fam_block_spread = [];
    hstats.distortionIndex = [];
    aggMaps = repmat({[]},[4 1]);
    for p = paths'
        s = load(p{1},'maps','partition_maps','unsmoothed_maps', ...
            'unsmoothed_maps_blocked','fam_error','fam_spread','distortionIndex','properties',...
            'fam_block_error','fam_block_spread');
%         tmp = s.fam_error(:,end-3:end);
        tmp = s.fam_block_error(:,end);
        if nanmean(tmp(:)) > threshold
            continue
        end

        try
            hstats.subNum = [hstats.subNum; s.properties.subjectNum.*ones(5,1)];
            hstats.age = [hstats.age; s.properties.age.*ones(5,1)];
            hstats.sbsod = [hstats.sbsod; s.properties.sbsod.*ones(5,1)];
            hstats.gender = [hstats.gender; repmat(upper(s.properties.gender(1)),[5 1])];
        catch
            hstats.subNum = [hstats.subNum; nan(5,1)];
            hstats.age = [hstats.age; nan(5,1)];
            hstats.sbsod = [hstats.sbsod; nan(5,1)];
            hstats.gender = [hstats.gender; nan(5,1)];
        end

            

        hstats.fam_error = [hstats.fam_error; s.fam_error];
        hstats.fam_spread = [hstats.fam_spread; s.fam_spread];
        hstats.fam_block_error = [hstats.fam_block_error; s.fam_block_error];
        hstats.fam_block_spread = [hstats.fam_block_spread; s.fam_block_spread];
        for j = 1:size(s.unsmoothed_maps_blocked,5)
            aggMaps{j,1} = cat(3,aggMaps{j,1},s.unsmoothed_maps_blocked(:,:,:,:,j));
        end
        hstats.distortionIndex = cat(3,hstats.distortionIndex,s.distortionIndex);
    end

end