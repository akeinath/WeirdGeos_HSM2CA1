function m2hAcrossBlocks(hRSM,allHumanMaps,allMouseMaps)
    
    nsims = 10;
    asFits = nan(nsims,5);
    asJNC = nan(nsims,5,2);
    for si = 1:nsims
        predictedHumanMaps = predictMaps(allHumanMaps,allMouseMaps(end)); % minclude 747 cells
        [~, pRSM] = m2rsm(predictedHumanMaps,-1);
        for hi = 1:5
            [fits jnc] = help_shRSA(hRSM{hi},pRSM{hi},size(hRSM{hi},3),1);
            asFits(si,hi) = fits;
            asJNC(si,hi,:) = jnc;
        end
    end

%     [a b c] = kruskalwallis(asFits(:,1:4),[],'off');
%     (b{2,5} - (size(asFits,2)-1) + 1) ./ (size(asFits,1)-(size(asFits,2)-1))

%     [a b c] = kruskalwallis(permute(asFits(end,1:3,:),[3 2 1]));

    eyefit = help_shRSA(hRSM{end},repmat(eye(9),[10 10 size(hRSM{end},3)]), ...
        size(hRSM{end},3),1);

    plotJNC = permute([nanmin(asJNC(end,:,1,:),[],4); ...
        nanmax(asJNC(end,:,1,:),[],4)],[1 2 3 4]);
    figure()
    set(gcf,'position',[50 50 225 275])
    mkWhisker(asFits,[{'1'} {'2'} {'3'} {'4'} {'Combined'}],...
        [0.1 0.1 0.6; 0.1 0.1 0.7; 0.1 0.1 0.8; 0.1 0.1 0.9; 0.6 0.6 0.6].*0.5+0.5);
    hold on
    plot(get(gca,'xlim'),ones(1,2).*eyefit,'linestyle','--','color',[0.8 0.8 0.8]);
    set(gca,'ylim',[0 1],'xlim',[0.25 5.75])
    xlabel('Human replacement block')
    ylabel('Kendalls Tau')
    x = [[1:length(plotJNC(1,:))]-0.45; [1:length(plotJNC(1,:))]+0.45; ...
        [1:length(plotJNC(1,:))]+0.45; [1:length(plotJNC(1,:))]-0.45];
    patch(x,plotJNC([1 1 2 2],:),[0.9 0.9 0.9],'edgecolor','none')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,'Plots/Experiment_1/Summary/MPred2H_ByBlock',[{'tiff'} {'pdf'}])
    drawnow
end