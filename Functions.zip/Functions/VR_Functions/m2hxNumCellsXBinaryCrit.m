function m2hxNumCellsXBinaryCrit(hRSM,allHumanMaps,allMouseMaps,mfr,critName,maxCells)

    

    doCells = round((maxCells./100).*[10].^[0:0.25:2]);
    
    

    cmfr = cat(1,mfr{:});
    bmfr = cmfr<0.01;
    
    nsims = 100;
    asFits = nan(length(doCells),nsims,2);
    asJNC = nan(length(doCells),2,nsims,2);
    for si = 1:nsims
        tm = allMouseMaps{end};

        % selected cells

        [a b] = find(~bmfr);
        for i = 1:length(a)
            tm(:,:,a(i),b(i)) = nan;
        end

        for k = length(doCells)
            predictedHumanMaps = predictMaps(allHumanMaps(end),{tm},[],doCells(k)); % minclude 747 cells
            [oRSM, pRSM] = m2rsm(predictedHumanMaps,-1);
            [asFits(k,si,1) asJNC(k,:,si,1)] = ...
                help_shRSA(hRSM,pRSM,[],1);
        end

        % random cells
        for k = length(doCells)
            predictedHumanMaps = predictMaps(allHumanMaps(end),allMouseMaps(end),[],doCells(k)); % minclude 747 cells
            [oRSM, pRSM] = m2rsm(predictedHumanMaps,-1);
            
            [asFits(k,si,2) asJNC(k,:,si,2)] = ...
                help_shRSA(hRSM,pRSM,[],1);
        end

    end

    figure()
    set(gcf,'position',[50 50 300 300])
    doColors = [0.9 0.4 0.2; 0.2 0.4 0.9];
    for di = 1:2
        semilogx(repmat(doCells,[nsims 1])+0.025.*randn([nsims length(doCells)]).*doCells,asFits(:,:,di)',...
            'linestyle','none','color','none','marker','o', ...
            'markersize',3,'markerfacecolor',doColors(di,:).*0.25+0.75)
        hold on
        plot(doCells,nanmedian(asFits(:,:,di),2)','marker','+','color',doColors(di,:).*0.5+0.5,'markersize',8,...
            'linestyle','-');
        h(di) = plot(doCells,nanmedian(asFits(:,:,di),2)','marker','+','color',doColors(di,:),'markersize',8,...
            'linestyle','none','linewidth',2);
    end
    legend(h,[{'Selected cells'} {'Random cells'}],'location','northwest')
    ylabel('Kendalls Tau')
    set(gca,'ylim',[0 1],'xlim',[8 maxCells.*1.1])
    xlabel('Number of cells')
    title('Similarity to human representation','fontname','arial','fontsize',9)
    saveFig(gcf,['Plots/Experiment_1/Summary/MPred2HxNCellsx_' critName],[{'tiff'} {'pdf'}])
    drawnow
end
