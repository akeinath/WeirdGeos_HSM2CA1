function getDistortionIndex(paths,recompute)
    
    if nargin < 2 || isempty(recompute)
        recompute = false;
    end


    warning off all
    fprintf('\n\ngetDistortionIndex()\n\n');

    [envLabel env_blocked] = envStuff();

    for p = paths'
        s = load(p{1},'distortionIndex');
        
        if ~recompute && ~isempty(fieldnames(s))
            continue
        end
        
        fprintf(['\tGetting Distortion Index:  ' slind(p{1},[1 3],'\/.') '... ']);

        s = load(p{1});

        adi = nan(length(envLabel),length(envLabel),length(s.objOrg));
        for k = 1:length(s.objOrg)
            arl = nan(2,4,length(envLabel));
            for envI = 1:length(envLabel)
                isGood = ismember(s.objOrg(k).env,envLabel(envI));
                isGood(ismember(s.objOrg(k).phase,[{'Familiar_Replace_Trials'} ...
                    {'Familiar_Replace_Trials___No_Fog'}])) = false; % Ignore replacements from initial learning
                arl(:,:,envI) = s.objOrg(k).pos([1 3],isGood);
            end
            tmp = permute(arl,[2 3 1]);
            x = tmp(:,:,1);
            y = tmp(:,:,2);

            x2 = bsxfun(@minus,x(:),x(:)').^2;
            y2 = bsxfun(@minus,y(:),y(:)').^2;
            d = sqrt(x2+y2);
            d(logical(eye(size(d)))) = nan;

            for i = 1:length(x(1,:))
                for j = 1:length(x(1,:))
                    chunk = d((i-1).*length(x(:,1))+1:(i).*length(x(:,1)),...
                        (j-1).*length(x(:,1))+1:(j).*length(x(:,1)));
                    adi(i,j,k) = nanmean(chunk(:));
                end
            end
        end

        s.distortionIndex = adi;

        save(p{1},'-struct','s','-v7.3');
        fprintf('Done.\n');
    end
end