function mkReplaceMaps(paths,recompute,kernScale)
    
    if nargin < 2 || isempty(recompute)
        recompute = false;
    end

    if nargin < 3 || isempty(kernScale)
        kernScale = 1;
    end

    warning off all
    fprintf('\n\nmkReplaceMap()\n\n');

    [envLabel env_blocked] = envStuff();

    for p = paths'
        s = load(p{1},'maps');
        
        if ~recompute && ~isempty(fieldnames(s))
            continue
        end
        
        fprintf(['\tMaking replacement maps:  ' slind(p{1},[1 3],'\/.') '... ']);

        s = load(p{1});

%         tmp = s.fam_spread;
%         sd = kernScale.*sqrt(s.fam_spread); %(3).*nanmean(tmp(:)); % Smooth with the scale determined by the familiar replacement accuracy in experimental blocks

        sd = kernScale;

        if length(sd)==1
            sd = ones(length(s.objOrg),1).*sd;
        end

        nBins = 15;
        map = zeros(nBins,nBins,length(s.objOrg),length(envLabel));
        unmap = zeros(nBins,nBins,length(s.objOrg),length(envLabel));
        nBlocks = nansum(cellfun(@contains,fieldnames(s),repmat({'Block'},size(fieldnames(s)))));
        unmap_blocked = zeros(nBins,nBins,length(s.objOrg),length(envLabel),nBlocks);
        map_blocked = zeros(nBins,nBins,length(s.objOrg),length(envLabel),nBlocks);
        pmap = zeros(3,3,length(s.objOrg),length(envLabel));
        for k = 1:length(s.objOrg)
            for envI = 1:length(envLabel)
                isGood = ismember(s.objOrg(k).env,envLabel(envI));
                isGood(ismember(s.objOrg(k).phase,[{'Familiar_Replace_Trials'} ...
                    {'Familiar_Replace_Trials___No_Fog'}])) = false; % Ignore replacements from initial learning

                rl = s.objOrg(k).pos([1 3],isGood);
                start = -s.envSize./2;
                inc = s.envSize./nBins;
                brl = floor(bsxfun(@rdivide,bsxfun(@minus,rl,start'),inc'))+1;
                
                brl = nanmin(brl,ones(size(brl)).*nBins); % in case just beyond binning

                tm = zeros(nBins,nBins);
                btm = zeros(nBins,nBins,nBlocks);
                try
                    doPix = sub2ind(size(tm),brl(1,:),brl(2,:));
                catch
                    'blah'
                end
                for i = 1:length(doPix(1,:))
                    tm(doPix(i)) = tm(doPix(i))+1;
                    btm(brl(1,i),brl(2,i),i) = 1;
                end


                kern = fspecial('gauss',[nBins.*3],sd(k));
                map(:,:,k,envI) = imfilter(tm,kern,'same');
                for q = 1:nBlocks
                    map_blocked(:,:,k,envI,q) = imfilter(btm(:,:,q),kern,'same');
                end
                unmap(:,:,k,envI) = tm;
                unmap_blocked(:,:,k,envI,:) = btm;

                %%% Block out unsampled locations
                for j = 1:9
                    xp = mod(j-1,3);
                    yp = floor((j-1)./3);

                    x = xp(1).*(nBins./3)+1:(xp(1)+1).*(nBins./3);
                    y = yp(1).*(nBins./3)+1:(yp(1)+1).*(nBins./3);

                    pmap(xp(1)+1,yp(1)+1,k,envI) = nansum(nansum(unmap(x,y,k,envI)));
                    if env_blocked(envI,j)
                        map(x,y,k,envI) = nan;
                        unmap(x,y,k,envI) = nan;
                        pmap(xp(1)+1,yp(1)+1,k,envI) = nan;

                        for q = 1:nBlocks
                            unmap_blocked(x,y,k,envI,q) = nan;
                        end
                    end

                end

            end

        end

        s.maps = map;
        s.unsmoothed_maps = unmap;
        s.unsmoothed_maps_blocked = unmap_blocked;
        s.maps_blocked = map_blocked;
        s.partition_maps = pmap;

        save(p{1},'-struct','s','-v7.3');
        fprintf('Done.\n');
    end
end