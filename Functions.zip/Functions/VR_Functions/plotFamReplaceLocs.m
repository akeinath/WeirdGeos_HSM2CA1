function plotFamReplaceLocs(paths)

    close all


    aRL = [];
    for p = paths'

        s = load(p{1},'objOrg');
        
        if isempty(fieldnames(s))
            continue
        end

        if isfield(s.objOrg(1),'scale')
            doScale = s.objOrg(1).scale{1}(1);
        else
            doScale = 1;
        end

        rl = [];
        for i = 1:length(s.objOrg)
            tmp = s.objOrg(i).pos([1 3],ismember(s.objOrg(i).env,{'OpenField'}) & ...
                ~ismember(s.objOrg(i).phase,[{'Familiar_Replace_Trials'} {'Familiar_Replace_Trials___No_Fog'}]));
            aRL = [aRL; nanmedian(tmp,2)'];
        end
        
    end

    close all
    drawnow
    figure(1)
    set(gcf,'position',[50 50 250 250])
    rectangle('position',[-2.5 -2.5 5 5].*doScale)
    hold on
    plot(aRL(:,1),aRL(:,2),'linestyle','none','marker','o','markerfacecolor','k', ...
        'markeredgecolor','none','markersize',4)
    axis equal
    axis square
    set(gca,'xlim',[-2.5 2.5].*doScale,'ylim',[-2.5 2.5].*doScale)
    axis off
    figP = ['Plots/' slind(p{1},[1 2],'/.') '/Summary/OpenField_ReplaceLocs'];
    saveFig(gcf,figP,[{'tiff'} {'pdf'}])

end