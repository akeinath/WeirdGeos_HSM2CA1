function cleanCalciumVideos(p)
    clc
    
    fprintf('Checking and correcting blank frames... \n')
    
    % make sure there aren't any pure-black frames, which would crash msRun
%     files = dir([p '/msCam*.avi']);
%     names = {files(:).name};
    names = {'9.avi'};
    for name = names
%         obj = VideoReader([p '/' name{1}]);
        
        obj = VideoReader([ name{1}]);
        frames = [];
        
        tmp = read(obj);
        tmp2 = double(tmp);
%         
%         avg = permute(nanmean(nanmean(nanmean(tmp2,3),1),2),[4 1 2 3]);
%         
%         dt = diff(tmp2,[],4);
%         rdt = nanmax(abs(reshape(dt,[numel(dt(:,:,:,1))],length(dt(1,1,1,:)))),[],1);
        
        interpFrames = [388 783]; %find(nanmean(tmp2)<=5);
        
%         find(rdt>50)
        
        if ~isempty(interpFrames)
            fprintf(['\tFrames interpolated for:  ' num2str(length(interpFrames)) '\n' p '/' name{1} '\n'])
            for i = interpFrames
                if i==1
                    tmp(:,:,:,i) = tmp(:,:,:,i+1);
                elseif i == length(tmp(1,1,1,:))
                    tmp(:,:,:,i) = tmp(:,:,:,i-1);
                else
                    tmp(:,:,:,i) = tmp(:,:,:,i-1);
                end
            end


%             outObj = VideoWriter([p '/' name{1}],'Grayscale AVI');
            outObj = VideoWriter([name{1} ' (2)'],'Uncompressed AVI');
            open(outObj)
            writeVideo(outObj,tmp);
            close(outObj)
        end
    end
end