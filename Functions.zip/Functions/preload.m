function preload(paths)

end