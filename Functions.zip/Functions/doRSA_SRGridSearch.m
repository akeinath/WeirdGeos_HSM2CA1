function doRSA_SRGridSearch(across,root)
    
    warning off all

    doS = [10:90];

%     doGammas = [0.995 0.95 0.8 0.6 0.4];
%     doAlphas = [(50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5)];
%     doTimestep = [1 5 15 30 60];

%     doGammas = [0.999 0.95 0.90 0.8 0.6];
%     doAlphas = [(50./30).*10.^(-4) (50./30).*10.^(-3).*5 (50./30).*10.^(-3) (50./30).*10.^(-3)./5 (50./30).*10.^(-2)];
%     doTimestep = [1 3 10 30 60 150];

    doGammas = [0.999 0.95 0.90 0.8 0.6];
    doAlphas = [(50./30).*10.^(-4) (50./30).*10.^(-3).*5 (50./30).*10.^(-3) (50./30).*10.^(-3)./5 (50./30).*10.^(-2)];
    doTimestep = [1 3 10 30 60 150];

    doChoices = combvec(doGammas,doAlphas,doTimestep);
    lrLabels = cellfun(@num2str,num2cell(1:length(doChoices(1,:))),'uni',0);

    correlationType = 'kendall';
    measures = fieldnames(across.rsa);
    measures = {'pearson'}; % Just do pearson comparisons
    for mi = 1:length(measures)
        um = unique(across.rsa.(measures{mi}).label);
        doComps = fieldnames(across.rsa.(measures{mi}).rsm);
        doComps(~cellfun(@contains,doComps,repmat({'bvc_sr_'},[length(doComps) 1]))) = []; % Just include BVC_SR comparisons

        aaRSMs = [];
        aRSMs = [];
        compRSMs = repmat({[]},[1 length(doComps)]);
        compRSMs3 = repmat({[]},[1 length(doComps)]);
        for mouseI = 1:length(um)
            isM = ismember(across.rsa.(measures{mi}).label,um(mouseI));
            ref = across.rsa.(measures{mi}).rsm.actual(doS,doS,isM);
            aRSMs = cat(3,aRSMs,nanmean(ref,3));

            noiseCeil = nan(size(ref,3),2);
            for i = 1:size(ref,3)
                a = getTri(ref(:,:,i));
                b = getTri(nanmean(ref(:,:,[1:i-1 i+1:end]),3));
                c = getTri(nanmean(ref,3));
                lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
                hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
                noiseCeil(i,:) = [lo hi];
            end
            noiseCeil = nanmean(noiseCeil);
        
            aaRSMs = cat(2,aaRSMs,getTri(nanmean(ref,3)));

            for i = length(doComps):-1:1
                if isempty(across.rsa.(measures{mi}).rsm.(doComps{i}))
                    across.rsa.(measures{mi}).rsm = rmfield(across.rsa.(measures{mi}).rsm,(doComps{i}));
                    doComps(i) = [];
                end
            end
            
            fits = nan(length(doComps),1);
            for i = 1:length(doComps)
                compRSMs3{i} = cat(3,compRSMs3{i},nanmean(across.rsa.(measures{mi}).rsm.(doComps{i})(doS,doS,isM),3));
                a = getTri(nanmean(across.rsa.(measures{mi}).rsm.(doComps{i})(doS,doS,isM),3));
                b = getTri(nanmean(ref,3));
                compRSMs{i} = cat(2,compRSMs{i},a);
                fits(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
            end
        
    
            figure(2)
            set(gcf,'position',[50 50 40.*length(doComps)*length(um) 150*length(measures)])
            subplot(length(measures),length(um),(mi-1).*length(um)+mouseI)
            set(gca,'ylim',[-0.05 1]);
            mkBar(fits',doComps,[0 0 0])
            hold on
            plot(get(gca,'xlim'),[0 0],'color','k','linestyle','-','linewidth',1);
            a = get(gca,'xlim');
            patch([a(1) a(1) a(2) a(2)],[noiseCeil fliplr(noiseCeil)], ...
                [0 0 0],'facealpha',0.2,'edgecolor','none','facecolor',[0 0 0]);
            title(measures{mi})

            figure(9)
            set(gcf,'position',[50 50 300.*length(um) 300])
            subplot(length(measures),length(um),(mi-1).*length(um)+mouseI)
            colors = v2rgb([0; 0.7; fits]);
            colors(1:2,:) = [];
            for k = 1:length(fits)
                hold on
                plot3(doChoices(1,k),doChoices(2,k),doChoices(3,k),'color',colors(k,:),...
                    'markerfacecolor',colors(k,:),'markersize',10,'marker','o')
            end
            xlabel('gamma')
            ylabel('alpha')
            zlabel('timestep')
            view([30 45])
            axis square
        end
        figure(9)
        saveFig(gcf,[root '/ModelComparison/SRGridSearch/Animalwise_3D'],[{'tiff'} {'pdf'}]);

        figure(2)
        saveFig(gcf,[root '/ModelComparison/SRGridSearch/Animalwise_Bar'],[{'tiff'} {'pdf'}]);


        %%%%% Compare to average within animals first

        ref = aaRSMs;
        noiseCeil = nan(size(ref,3),2);
        for i = 1:length(aaRSMs(1,:))
            a = ref(:,i);
            b = nanmean(ref(:,[1:i-1 i+1:end]),2);
            c = nanmean(ref,2);
            lo = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
            hi = corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type',correlationType);
            noiseCeil(i,:) = [lo hi];
        end
        noiseCeil = nanmean(noiseCeil);
    
        compRSMs3 = [{aRSMs} compRSMs3];
        figure(5)
        set(gcf,'position',[50 50 300.*ceil(sqrt(length(doComps))) 300.*ceil(sqrt(length(doComps)))])
        for qi = 1:length(compRSMs3)
            subplot(ceil(sqrt(length(doComps)+1)),ceil(sqrt(length(doComps)+1)),qi)
            tmp = 1-squarify(nanmean(compRSMs3{qi},3));
            isBad = all(isnan(tmp));
            tmp(:,isBad) = [];
            tmp(isBad,:) = [];
            imagesc(tmp)
            tmp(1:length(tmp)+1:end) = nan;
            alpha(double(~isnan(tmp)))
            colormap inferno
            axis equal
            axis square
            axis off
        end
        saveFig(gcf,[root '/ModelComparison/SRGridSearch/ModelRSMs_' measures{mi}],[{'tiff'} {'pdf'}]);

        fits = nan(length(doComps),1);
        for i = 1:length(doComps)
            a = nanmean(compRSMs{i},2);
            b = nanmean(ref,2);
            fits(i) = corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',correlationType);
        end
    

        figure(4)
        set(gcf,'position',[50 50 40.*length(doComps)*length(measures) 150])
        subplot(1,length(measures),mi)
        set(gca,'ylim',[-0.05 0.8]);
        mkBar(fits',doComps,[0 0 0])
        hold on
        plot(get(gca,'xlim'),[0 0],'color','k','linestyle','-','linewidth',1);
        a = get(gca,'xlim');
        patch([a(1) a(1) a(2) a(2)],[noiseCeil fliplr(noiseCeil)], ...
            [0 0 0],'facealpha',0.2,'edgecolor','none','facecolor',[0 0 0]);
        title(measures{mi})

        figure(10)
        set(gcf,'position',[50 50 300 300])
        colors = v2rgb([0; 0.7; fits]);
        colors(1:2,:) = [];
        for k = 1:length(fits)
            hold on
            plot3(doChoices(1,k),doChoices(2,k),doChoices(3,k),'color',colors(k,:),...
                'markerfacecolor',colors(k,:),'markersize',10,'marker','o')
        end
        xlabel('gamma')
        ylabel('alpha')
        zlabel('timestep')
        view([30 45])
        axis square

        figure(10)
        saveFig(gcf,[root '/ModelComparison/SRGridSearch/Overall_3D'],[{'tiff'} {'pdf'}]);

        figure(4)
        saveFig(gcf,[root '/ModelComparison/SRGridSearch/Overall_Bar'],[{'tiff'} {'pdf'}]);
    end
end
