function [overallRSMs] = m2rsm_matched(m,sd,ignorePartitioned,doPixel)
    if nargin < 2 || isempty(sd)
        sd = -1;
    end

    if nargin < 3 || isempty(ignorePartitioned)
        ignorePartitioned = false;
    end

    if nargin < 4 || isempty(doPixel)
        doPixel = false;
    end

    if ~iscell(m)
        m = {m};
    end
    
%     fprintf(['\n\t\t\tConverting Maps to RSMs (' num2str(sd) ' s.d.):\t']);
%     tic

    smoothedMaps = m;
    pixelRSMs = repmat({[]},size(m));
    partitionRSMs = repmat({[]},size(m));
    overallRSMs = repmat({[]},size(m));
    for i = 1:length(m(1,:))
        for j = 1:length(m(:,1))
            tm = m{j,i};

            if isempty(tm)
                continue
            end

            isGood = nansum(~all(all(isnan(tm),1),2),4) >= 2;
            tm = tm(:,:,isGood,:);

            if sd > 0
                kern = fspecial('gauss',[size(tm,[1]).*3.*ones(1,2)],sd);

                atm = nan(size(tm,[1 2 3 4 4]));
                for ri = 1:10
                    for rj = 1:10
                        a = tm(:,:,:,ri);
                        a(repmat(all(isnan(tm(:,:,:,rj)),3),[1 1 size(a,3)])) = nan;
                        atm(:,:,:,ri,rj) = a;
                    end
                end
                tm = atm;
                isBad = isnan(tm);
                tm(isBad) = 0;
                tm = imfilter(tm,kern,'same');
                tm(isBad) = nan;
            end

            rtm = reshape(tm,[prod(size(tm,[1 2])) size(tm,[3 4 5])]);
            overall_vals = nan([size(tm,[4 4 3])]);
            for ri = 1:10
                for rj = ri+1:10
                    a = rtm(:,:,ri,rj);
                    b = rtm(:,:,rj,ri);
                    
                    goodPix = any(~isnan(a),2) & any(~isnan(b),2);
                    xc = corr(a(goodPix,:),b(goodPix,:));
                    overall_vals(ri,rj,:) = xc(1:length(xc)+1:end);


                end
            end
            overallRSMs{j,i} = squarify(overall_vals);
        end
    end

    if all(size(overallRSMs)==1)
%         partitionRSMs = partitionRSMs{1};
        overallRSMs = overallRSMs{1};
%         pixelRSMs = pixelRSMs{1};
    end

%     tmp = toc;
%     fprintf('  %0.3fs.',tmp);
end














