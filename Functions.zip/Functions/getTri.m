function v = getTri(m,shift)

    if nargin < 2 || isempty(shift)
        shift = 1;
    end

    if size(m,3)==1
        a = triu(true(size(m)),shift);
        v = m(a);
    else
        v = [];
        for i = 1:size(m,3)
            tm = m(:,:,i);
            a = triu(true(size(tm)),shift);
            v = [v tm(a)];
        end
    end
end