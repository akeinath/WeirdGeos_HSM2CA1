function out = c2csimAnalysis(sim,blocked,envs,pfrPart)

    [blah pfrPart] = nanmax(sim.partitioned.pfr,[],2);
    pfrPart(isnan(blah)) = nan;
    pfrPart = permute(pfrPart,[1 3 2]);
    pfrPart = pfrPart-1;

    tmp = permute(sim.c2c.pearson,[3 4 1 2]);
    isSameEnv = false(size(tmp(:,:,1,1)));
    isSameEnv([1:12:end]) = true;
    rt = tmp(repmat(isSameEnv,[1 1 length(tmp(1,1,:,1)) length(tmp(1,1,:,1))]));
    rt = reshape(rt,[11 length(tmp(1,1,:,1)) length(tmp(1,1,:,1))]);
    
    doPairs = [];
    for i = 1:length(rt(1,1,:))
        doPairs = [doPairs; [i.*ones(length(rt(1,1,:))-i,1) [(i+1):length(rt(1,1,:))]']];
    end
    allPairs = nan(11,length(doPairs(:,1)));
    for i = 1:length(doPairs(:,1))
        allPairs(:,i) = rt(:,doPairs(i,1),doPairs(i,2));
    end
    
%     %%% Just blocked-off cells
%     rt = permute(rt,[2 3 1]);
%     for i = 2:10
%         doInclude = bsxfun(@times,ismember(pfrPart(1,:),blocked{i}), ...
%             ismember(pfrPart(1,:),blocked{i})');
%         tmp = rt(:,:,i);
%         tmp(~doInclude) = nan;
%         rt(:,:,i) = tmp;
%     end
%     rt = permute(rt,[3 1 2]);
    
%     %%% Just same partition cells
%     rt = permute(rt,[2 3 1]);
%     for i = 2:11
%         doInclude = bsxfun(@eq,pfrPart(1,:),pfrPart(1,:)');
%         tmp = rt(:,:,i);
%         tmp(~doInclude) = nan;
%         rt(:,:,i) = tmp;
%     end
%     rt = permute(rt,[3 1 2]);
    
    numClosed = cellfun(@length,blocked);
    numClosed([1 11]) = 0;
    
    corrVal = nan(1,11);
    
    figure
    set(gcf,'position',[50 50 300.*5 300.*2])
    ref = nanmean(allPairs([1],:),1);
    for i = 2:11
        cr = allPairs(i,:);
        isGood = ~isnan(ref)&~isnan(cr);

        [rval pval] = corr(ref(isGood)',cr(isGood)','type','pearson');
        corrVal(i) = rval;
        
        subplot(2,5,(i-1))
        scatter(ref(isGood),cr(isGood),0.5)
        hold on
        plot([-1 1],[0 0],'linestyle','--','color','k')
        plot([0 0],[-1 1],'linestyle','--','color','k')
        set(gca,'xlim',[-1 1],'ylim',[-1 1])
        lsline
        axis equal
        axis square
%         if i == 2
            xlabel('Cell-to-cell rate map corr (Square 1)')
            ylabel(['C-to-c rate map corr (' upper(envs{i}) ')'])
%         end
        text(-0.9,-0.75,sprintf('r = %0.3f\np = %0.3f',[rval pval]))
    end
    drawnow
    
    
    out.acv = corrVal;
    
    cv = repmat({[]},[1 5]);
    for i = 0:4
        tmp = corrVal(numClosed'==i);
        cv{i+1} = tmp(~isnan(tmp));
    end
    
    out.cv = cv;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%% Just high correlation cell pairs cells
    threshold = 0.5;
    rt = permute(rt,[2 3 1]);
%     rt(repmat(rt(:,:,1)<threshold | isnan(rt(:,:,1)),[1 1 11])) = nan;
    rt(repmat(rt(:,:,1)<threshold | rt(:,:,11)<threshold | ...
        isnan(rt(:,:,1)),[1 1 11])) = nan;
    rt = permute(rt,[3 1 2]);
    
    doPairs = [];
    for i = 1:length(rt(1,1,:))
        doPairs = [doPairs; [i.*ones(length(rt(1,1,:))-i,1) [(i+1):length(rt(1,1,:))]']];
    end
    allPairs = nan(11,length(doPairs(:,1)));
    for i = 1:length(doPairs(:,1))
        allPairs(:,i) = rt(:,doPairs(i,1),doPairs(i,2));
    end

    out.hiSqStabilityPairs = repmat({[]},[1 length(allPairs(:,1))]);
    for i = 1:length(allPairs(:,1))
        out.hiSqStabilityPairs{i} = [allPairs(i,~isnan(allPairs(i,:)))]';
    end
end




















