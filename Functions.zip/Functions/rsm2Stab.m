function s = rsm2Stab(rsm)
    
    if ~iscell(rsm)
        rsm = {rsm};
    end

    s = repmat({[]},size(rsm));
    for i = numel(rsm)
        s{i} = repmat(rsm{i}(end-8:end,end-8:end,:),[10 10 1]);
        s{i}(isnan(rsm{i})) = nan;
    end

    if numel(rsm)==1
        s = s{1};
    end
end