function maps = genBVCMapss(blocked,bvc_distanceConstant,bvc_distanceScalar,beta_1,beta_2)

    % add three squares for familiarization, maybe rotate paths for less
    % redundancy?

    if nargin < 2 || isempty(bvc_distanceConstant)
        bvc_distanceConstant = 8;
    end
    if nargin < 3 || isempty(bvc_distanceScalar)
        bvc_distanceScalar = (1./12);
    end
    if nargin < 4 || isempty(beta_1)
        beta_1 = 1;
    end
    if nargin < 5 || isempty(beta_2)
        beta_2 = 1;
    end

    % params from Will de Cothi
    
    nBVCs = 1500;
    bvcAngs = rand(nBVCs,1).*2.*pi;
    bvcDists = betarnd(beta_1,beta_2,nBVCs,1).*75;
    bvc_angleSD = ones(nBVCs,1).*deg2rad(11.25);

    maps = nan(15,15,nBVCs,size(blocked,1));
    %%% Generate all BVC traces
    
    pos = combvec(2.5:5:72.5,2.5:5:72.5);

    for si = 1:size(blocked,1)

        walls = permute(getBlockedBounds(find(blocked(si,:))-1),[2 3 1]);
        wXphd = bsxfun(@minus,repmat(pos,[2 1]),walls);

        a = permute(walls([3 4],:,:) - walls([1 2],:,:),[3 1 2]);
        wtheta = cart2pol(a(:,1),a(:,2));


        rays = bvcAngs'; %[0:binAng:2.*pi-binAng];
        rayPoints = permute([cos(rays).*200; sin(rays).*200],[1 2 3]);
        m2 = permute(rayPoints(2,:)./rayPoints(1,:),[2 1 3]);
        sc = [sign(rayPoints(1,:))' sign(rayPoints(2,:))'];
        allInDist = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        allInAngs = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        for j = 1:length(walls(1,1,:))
            w1 = wXphd([1 2],:,j);
            w2 = wXphd([3 4],:,j);

            intOut = lineSegmentIntersect(wXphd(:,:,j)',[zeros(size(rayPoints))' rayPoints']);


            doesInt = intOut.intAdjacencyMatrix;
            d2w = sqrt(intOut.intMatrixX.^2 + intOut.intMatrixY.^2);
            d2w(~doesInt) = nan;
            allInDist(:,:,j) = d2w';
        end
        subAng = mod(wtheta - rays,2.*pi);
        [nearestBorder nbInd] = nanmin(allInDist,[],3);
        nearestBorderAngle = nan(size(nearestBorder));
        for i = 1:length(rays)
            nearestBorderAngle(i,:) = subAng(nbInd(i,:),i)';
        end

        % Distance tuning gaussian
        a = normpdf(bsxfun(@minus,nearestBorder,bvcDists),zeros(size(nearestBorder)), ...
            repmat(bvc_distanceConstant+bvc_distanceScalar.*bvcDists, ...
            [1 length(nearestBorder(1,:))]));
        % Angle tuning gaussian
        b = normpdf(nanmin(abs(nearestBorderAngle-[pi./2]), ...
            abs(nearestBorderAngle-[3.*pi./2])),0,repmat(bvc_angleSD, ...
            [1 length(nearestBorderAngle(1,:))]));
        bvcTrace = a.*b; % Combine

        maps(:,:,:,si) = removeBlocked(mkTraceMaps(pos,bvcTrace,[],[15 15],[],[]),{find(blocked(si,:))-1});
    end
end