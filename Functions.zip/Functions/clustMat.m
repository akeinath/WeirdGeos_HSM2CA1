function M = clustMat(M)
    Z = linkage(M,'single');
    tmp = seriation(Z,length(M)+1,length(M)+length(M)-1);
    M = M(tmp,:);
    M = M(:,tmp);
end