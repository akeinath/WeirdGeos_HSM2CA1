function srGridSearch(s,root)

    bvcPrecompP = ['MatlabData/BVC_Trace_Precomputes/' slind(root,[2 0])];
    if exist([bvcPrecompP '.mat'])~=2
        bvcTraces = genBVCs(s.position,s.blocked);
        checkP(bvcPrecompP);
        save(bvcPrecompP,'bvcTraces','-v7.3');
    else
        tic
        fprintf(['\n\t\tLoading Precomputed BVC traces...'])
        load(bvcPrecompP,'bvcTraces');
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
    end

%     OG Choices
%     doGammas = [0.995 0.95 0.8 0.6 0.4];
%     doAlphas = [(50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5)];
%     doTimestep = [1 5 15 30 60];


%     doGammas = [0.999 0.95 0.90];
%     doAlphas = [(50./30).*10.^(-1) (50./30).*10.^(-2) (50./30).*10.^(-3) (50./30).*10.^(-4) (50./30).*10.^(-5) (50./30).*10.^(-6)];
%     doTimestep = [1 150];

    doGammas = [0.999 0.95 0.90 0.8 0.6];
    doAlphas = [(50./30).*10.^(-4) (50./30).*10.^(-3).*5 (50./30).*10.^(-3) (50./30).*10.^(-3)./5 (50./30).*10.^(-2)];
    doTimestep = [1 3 10 30 60 150];

    doChoices = combvec(doGammas,doAlphas,doTimestep);

    % parameter choices
    for k = 1:length(doChoices(1,:))
        gamma = doChoices(1,k);
        alpha = doChoices(2,k);
        ts = doChoices(3,k);
        srPrecompP = ['MatlabData/SR_Trace_Precomputes/FullSearch/' slind(root,[2 0]) ...
            '_g' num2str(gamma.*1000) '_a' num2str(round(alpha.*10.^7)) '_t' num2str(ts)];
        if exist([srPrecompP '.mat'])~=2
            [srTraces srMaps] = genBVC_sr(s.position,bvcTraces,gamma,alpha,ts);
            checkP(srPrecompP);
            save(srPrecompP,'srTraces','srMaps','-v7.3');
        end
    end
end
















