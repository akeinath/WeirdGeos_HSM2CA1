function block2patch(x,y,b,s)
    
    hold on
    patch([x-s x-s x+s x+s],[y-s y+s y+s y-s],0,'edgecolor','k',...
        'facecolor','none')
    for i = 1:length(b)
        if b(i)
            x2 = (mod((i-1),3))./3;
            y2 = (floor((i-1)./3))./3;
            patch([x-s+(x2.*s.*2) x-s+(x2.*s.*2) x-s+((x2+(1./3)).*s.*2) x-s+((x2+(1./3)).*s.*2)],...
                [y-s+(y2.*s.*2) y-s+((y2+(1./3)).*s.*2) y-s+((y2+(1./3)).*s.*2) y-s+(y2.*s.*2)],...
                0,'edgecolor','none',...
                'facecolor','k')
        end
    end
end