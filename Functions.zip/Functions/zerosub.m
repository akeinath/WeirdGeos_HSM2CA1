function tmp = zerosub(um)
    tmp = um;
    isEmpty = permute(all(all(isnan(um),1),2),[3 4 1 2]);
    isSampled = permute(any(~isnan(um),3),[1 2 4 3]);
    sub = double(isSampled);
    sub(sub==0) = nan;
    sub(sub==1) = 0;
    for si = 1:length(isEmpty(1,:))
        tmp(:,:,isEmpty(:,si),si) = repmat(sub(:,:,si),[1 1 nansum(isEmpty(:,si))]);
    end
end
