function mkBatchPreload(paths,forceReload)
    
    clc
    close all
    drawnow
    
    if nargin < 2
        forceReload = true;
    end

    warning off all
     %% Split by animal
    piece = [];
    ag = [];
    spiece = [];
    labels = [];
    for i = 1:length(paths)
        ind = find(ismember(paths{i},'/'),1,'last')-1;
        piece = [piece; {paths{i}(1:ind)}];
        spiece = [spiece; {paths{i}(ind+2:end-4)}];
    end
    upiece = unique(piece);
    
    
    pause_thresh = -2;
    envSize = [17 17];
    
    
    aMinLen = inf;
    for mi = 1:length(upiece)
        isM = find(ismember(piece,upiece(mi)));
        sessions = paths(isM);
        for si = 1:length(sessions)
            s = load(sessions{si},'valid');
            aMinLen = nanmin(aMinLen,length(s.valid.traceFrames(:,1)));
        end
    end
    
    for mi = 1:length(upiece)
        fprintf(['\n\tMouse:  ' num2str(upiece{mi}(find(ismember(upiece{mi},'/'),1,'last')+1:end)) '\n'])
        isM = find(ismember(piece,upiece(mi)));
        sessions = paths(isM);
        
        slashInds = find(ismember(upiece{mi},'/'));
        top = ['MatlabData/AnalysisPreloads/' upiece{mi}(slashInds(1)+1:end)];
        
        if exist([top '.mat'],'file')~=2 || forceReload
            s = load(paths{isM(1)});
            doAl = help_getAlignmentID(s.alignment,length(isM),paths(isM));
            alignMap = s.alignment(doAl).alignmentMap;
            am = repmat({[]},[1 length(sessions)]);
            MFRs = repmat({[]},[1 length(sessions)]);
            PFRs = repmat({[]},[1 length(sessions)]);
            aGTs = repmat({[]},[1 length(sessions)]);
            aP = repmat({[]},[1 length(sessions)]);
            aSamp = nan([envSize length(sessions)]);
            SFPs = s.alignment(doAl).regDetails.spatial_footprints_corrected;
            simVecs = repmat({[]},[1 length(sessions)]);
            envs = [];
            blocked = [];
            tic
            allTraces = [];

            slashInds = find(ismember(paths{1},'/'));
            root = ['Plots/Summary' paths{1}(slashInds(1):slashInds(2)-1)];
            slashInds = find(ismember(upiece{mi},'/'));
            root = [root '/' upiece{mi}(slashInds(end)+1:end) '/ContinuousAnalyses'];
            close all
            drawnow;
            fprintf(['\t\tPreloading Data... '])
            
            for si = 1:length(sessions)
                s = load(sessions{si},'processed','exclude');
                
                slashInds = find(ismember(sessions{si},'/'));
                gT = s.processed.trace(:,1:aMinLen);
                gP = s.processed.p(:,1:aMinLen);
                if isfield(s.processed,'exclude')
                    gT = gT(s.processed.exclude.SFPs,:);
                end
                allTraces = [allTraces {gT}];
                
                amfr{si} = nanmean(gT,2);
                v = [0 sqrt(nansum(diff(gP,[],2).^2,1))].*30;
                [m os unm] = mkTraceMaps(gP,gT,[],envSize);
                aSamp(:,:,si) = os;
                am{si} = m;
                unam{si} = unm;
                aGTs{si} = gT;
                aP{si} = gP;
                
                PFRs{si} = permute(nanmax(nanmax(m,[],1),[],2),[3 1 2]);
                tm = m./repmat(nanmax(nanmax(m,[],1),[],2),size(m(:,:,1)));
                MFRs{si} = nanmean(gT(:,[]),2);
                
                
                envs = [envs; {lower(s.processed.environment)}];
                blocked = [blocked; {s.processed.blocked}];
            end  
            
            uGT = repmat({[]},[1 length(sessions)]);
            umfr = nan([length(alignMap{1}(:,1)) length(sessions)]);
            upfr = nan([length(alignMap{1}(:,1)) length(sessions)]);
            um = nan([envSize length(alignMap{1}(:,1)) length(sessions)]);
            unum = nan([envSize length(alignMap{1}(:,1)) length(sessions)]);
            for si = 1:length(sessions)
                umfr(alignMap{1}(:,si)~=0,si) = MFRs{si}(alignMap{1}(alignMap{1}(:,si)~=0,si));
                upfr(alignMap{1}(:,si)~=0,si) = PFRs{si}(alignMap{1}(alignMap{1}(:,si)~=0,si));
                um(:,:,alignMap{1}(:,si)~=0,si) = am{si}(:,:,alignMap{1}(alignMap{1}(:,si)~=0,si));
                unum(:,:,alignMap{1}(:,si)~=0,si) = unam{si}(:,:,alignMap{1}(alignMap{1}(:,si)~=0,si));
                
                tmp = aGTs{si};
                uGT{si} = nan([length(alignMap{1}(:,1)) length(tmp(1,:))]);
                uGT{si}(alignMap{1}(:,si)~=0,:) = aGTs{si}(alignMap{1}(alignMap{1}(:,si)~=0,si),:);
            end
            
            
            % remove stragler pixels
            um = removeBlocked(um(1:15,1:15,:,:),blocked);
            unum = removeBlocked(unum(1:15,1:15,:,:),blocked);
            
            maps = struct();
            maps.smoothed = um; %help_orgMaps(um);
            maps.unsmoothed = unum; %help_orgMaps(unum);
            maps.sampling = removeBlocked(aSamp(1:15,1:15,:,:).*(1./30),blocked);
            
            out.trace = uGT;
            out.position = aP;
            out.maps = maps;
            out.SFPs = SFPs';
            out.envs = envs;
            out.blocked = blocked;
            checkP(top);
            save(top,'-struct','out','-v7.3');
            
            clear um uSFPs allTraces aGT uGT
        else
            load(top);
        end
    end
end

function out = help_orgMaps(um)
    out.raw = um;
    out.maxnormed.withinSession = maxnorm(um);
    normer = repmat(nanmax(nanmax(nanmax(um,[],1),[],2),[],4),[size(um(:,:,1,:))]);
    out.maxnormed.acrossSessions = um./normer;
    out.zerosub.raw = zerosub(um);
end






































