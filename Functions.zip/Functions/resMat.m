function residTri = resMat(A,B)
    a = getTri(nanmean(A,3));
    b = getTri(nanmean(B,3));
    [beta dev stats] = glmfit(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)));
    c = double(~isnan(a)&~isnan(b));
    c(c==0) = nan;
    c(~isnan(c)) = stats.resid;
    residTri = squarify(mkTri(c,size(A(:,:,1))));
end