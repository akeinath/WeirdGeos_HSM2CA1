function vs = vecSimX(uGT,smoothing)
    
    fprintf('\n\tComputing vector similarities across days...')
    tic

    if nargin < 2 || isempty(smoothing)
        smoothing = -1;
    end
    
    if smoothing > 1
        for i = 1:length(uGT)
            uGT{i} = imfilter(uGT{i},fspecial('gauss',[1 smoothing.*7],smoothing),'same');
            uGT{i} = bin(uGT{i},smoothing);
        end
    end
    
    upperBit = 0.000000000001;
    minActCells = 10;
    vs = repmat({[]},[length(uGT) length(uGT)]);
    for si = 1:length(uGT)
        for sj = [1:si-1 si+1:length(uGT)]

            isGood = all(~isnan(uGT{si}),2) & ...
                all(~isnan(uGT{sj}),2);
            
            siAct = nansum(uGT{si}(isGood,:)>0,1);
            sjAct = nansum(uGT{sj}(isGood,:)>0,1);

            % sjAct>=minActCells

            tmp = corr(uGT{si}(isGood,siAct>=minActCells),uGT{sj}(isGood,sjAct>minActCells));
            tmp = sort(tmp,2,'descend');

            vs{si,sj} = nanmean(tmp(:,1:ceil(upperBit.*length(tmp(1,:)))),2);
%             vs(si,sj) = nanmean(nanmax(tmp,[],2));÷\
        end
    end
    imagesc(squarify(cellfun(@nanmean,vs)));
end




















