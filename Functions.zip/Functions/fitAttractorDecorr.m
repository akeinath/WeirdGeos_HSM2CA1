function fitAttractorDecorr(sim,RDMs)

    for i = 1:length()


    rsim = reshape(sim,[numel(sim(:,:,1)) length(sim(1,1,:))]);
    rRDMs = reshape(RDMs,[numel(RDMs(:,:,1)) length(RDMs(1,1,:))]);
    
    length(sims)
end
