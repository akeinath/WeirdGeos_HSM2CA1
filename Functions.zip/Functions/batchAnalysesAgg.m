function batchAnalysesAgg(paths)


    % 0.999 0.0017

    across = struct; %prepAcross();
%     across = prepAcross();
    
    warning off all
    
    clc
    fprintf('\n\t\t\t*********Running batched analyses********\n\n');
    vals = [];
    for mi = 1:length(paths) %:-1:1
        
        close all
        drawnow
        
        fprintf(['\n\n\t\t\t' macheck(paths{mi},true)])
        fprintf('\n\n\tLoading data...')
        tic
        s = load(paths{mi},'trace','maps','position','blocked','envs'); %'trace'
        tmp = toc;
        fprintf('  %0.3fs.',tmp);
        
%         s = load(paths{mi});
        slashInds = find(ismember(paths{mi},'/\'));
        root = ['Plots/BatchedAnalyses/' paths{mi}(slashInds(2)+1:end-4)];
        
%         ogSearch(s,root);
%         srGridSearch(s,root);
        across = seqAnalysis_Serial(s,root,across);
% % %         across = seqAnalysis(s,root,across);
        
% % %         s.vecSim = vecSimX(s.trace,30);
% % %         across.vecSim = cat(3,across.vecSim,splitAndOrder(s.vecSim,s.envs));
% % %         s.rsm.trace.c2c = c2cTraceAnalysis(s.trace);
% % %         s.rsm.trace.partition.c2c = c2cTraceAnalysis_Partitioned(s.trace,s.position);
% % %         s.rsm.smoothed = getPairwiseMapSim(s.maps.smoothed,'partitioned_pearson'); % 'emd_scaled' ,'partitioned_pearson'); 'partitioned_pv','partitioned_pfr'
        
% % %         isUp = triu(true(size(s.rsm.smoothed.pearson(:,:,1))),1);
% % %         tmp = nanmean(s.rsm.smoothed.pearson,3);
% % %         across.rsm.pearsonXc2c = [across.rsm.pearsonXc2c; ...
% % %             corr(tmp(isUp),s.rsm.trace.c2c(isUp),'type','pearson')];
        
% % %         cRSM = squarify(nanmean(s.rsm.trace.c2c,3));
% % %         [c cON] = splitAndOrder(cRSM,s.envs);
% % %         tmp = cRSM;
% % %         isUp = triu(true(size(tmp)),1);
% % %         tmp(~isUp) = nan;
% % %         for ci = 1:length(tmp)
% % %             tmp(ci,:) = circshift(tmp(ci,:),[0 -ci]);
% % %         end
% % %         across.rsm.drift = [across.rsm.drift; [nanmean(tmp,1) nan(1,31-length(tmp))]];
% % %         across.rsm.stabilization = [across.rsm.stabilization; ...
% % %             [cRSM(sub2ind(size(cRSM),[1:length(cRSM)-10],10+[1:length(cRSM)-10])) nan(1,21-[length(tmp)-10])]];
% % %         across.rsm.envSim = [across.rsm.envSim; permute(c(1,:,:),[3 2 1])];


%         across.rsm.pearson = cat(3,across.rsm.pearson, ...
%             squarify(nanmean(s.rsm.smoothed.pearson,3))); 
% % % 
% % %         figure
% % %         set(gcf,'position',[50 50 300 300])
% % %         imagesc(squarify(nanmean(s.rsm.smoothed.pearson,3)))
% % %         axis square
% % %         colorbar
% % %         colormap magma
% % %         caxis([0 0.6])
% % %         saveFig(gcf,[root '/RSM_Pearson'],[{'tiff'} {'pdf'}]);
% % %         
% % %         figure
% % %         set(gcf,'position',[50 50 300 300])
% % %         imagesc(squarify(s.rsm.trace.c2c))
% % %         axis square
% % %         colorbar
% % %         colormap magma
% % %         caxis([-0.1 0.5])
% % %         saveFig(gcf,[root '/RSM_c2c_trace'],[{'tiff'} {'pdf'}]);
% % % 
% % %         a = squarify(nanmean(s.rsm.smoothed.pearson,3));
% % %         b = squarify(s.rsm.trace.c2c);
% % %         vals = [vals; corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)))];
% % %         
        
%         rsm = nanmean(s.rsm.smoothed.pearson,3); %s.rsm.trace.c2c;
%         
%         crsm = nan(size(rsm));
%         for i = 1:length(rsm)
%             crsm(i,:) = circshift(rsm(i,:),[0 -i]);
%         end
%         
%         uenvs = unique(s.envs);
%         condCRSM = nan(length(uenvs),length(crsm(1,:)));
%         for i = 1:length(uenvs)
%             condCRSM(i,:) = nanmean(crsm(ismember(s.envs,uenvs(i)),:),1);
%         end
%         
%         if isempty(across.c2c.trace.condCRSM)
%             across.c2c.trace.condCRSM = condCRSM;
%         else
%             across.c2c.trace.condCRSM = cat(3,across.c2c.trace.condCRSM,condCRSM);
%         end
%         
%         figure
%         set(gcf,'position',[50 50 300 300])
%         imagesc(squarify(nanmean(s.rsm.smoothed.emds,3)))
%         axis square
%         colorbar
%         caxis([0 0.6])
%         saveFig(gcf,[root '/Overall_Map_RSM'],[{'tiff'} {'pdf'}]);
        
%         figure
%         set(gcf,'position',[50 50 300 300])
%         imagesc(squarify(nanmean(s.rsm.smoothed.pearson,3)))
%         axis square
%         colorbar
%         caxis([0 0.6])
%         saveFig(gcf,[root '/Overall_Map_RSM'],[{'tiff'} {'pdf'}]);
        
%         d = 1-squarify(nanmean(s.rsm.smoothed.pearson,3));
%         d(1:length(d)+1:end) = 0;

% % %         d = squarify(nanmean(s.rsm.smoothed.emds,3));
% % %         d(1:length(d)+1:end) = 0;
% % %         
% % %         [comps stress] = mdscale(d,2);
% % %         fprintf(['\n\t\t\tMDS Stress:  ' sprintf('%0.3f',stress)]);
% % %         doC = magma(length(comps)).*0.75;
% % %         markerSize = 5;
% % %         for ci = 1:length(comps)
% % %             markerSize = markerSize+0.2;
% % %             plot(comps(ci,1),comps(ci,2),'marker','o','linestyle','none', ...
% % %                 'color',doC(ci,:),'markerfacecolor',doC(ci,:),'markersize',markerSize);
% % %             hold on
% % %         end
% % %         
%         tmp = squarify(-nanmean(s.rsm.smoothed.partitioned.dpfr,3));
%         figure
%         set(gcf,'position',[50 50 300 300])
%         imagesc(tmp)
%         alpha(double(~isnan(tmp)));
%         axis square
%         colorbar
% %         caxis([0 0.6])
% 
%         tmp = squarify(nanmean(s.rsm.smoothed.partitioned.pearson,3));
%         figure
%         set(gcf,'position',[50 50 300 300])
%         imagesc(tmp)
%         alpha(double(~isnan(tmp)));
%         axis square
%         colorbar
%         caxis([0 0.6])s
    end

   s = across.rsa.pearson;

    um = unique(s.label);
    mouse_CA1_rsm = nan([size(s.rsm.actual,1) size(s.rsm.actual,2) length(um)]);
    for i = 1:length(um)
        mouse_CA1_rsm(:,:,i) = nanmean(s.rsm.actual(:,:,ismember(s.label,um(i))),3);
        tmp2 = mouse_CA1_rsm(:,:,i);
        tmp2(1:length(tmp2)+1:end) = nan;
        mouse_CA1_rsm(:,:,i) = tmp2;
    end
    mouse_individual_rsm = s.rsm.actual;
    save('Mouse_CA1_Agg_Across','mouse_CA1_rsm','mouse_individual_rsm','-v7.3');

    figure()
    mkLine(across.rsm.drift,[1:31])
    saveFig(gcf,'c2c_drift',{'pdf'});

    figure()
    mkLine(across.rsm.stabilization,[1:21])
    set(gca,'ylim',[0 0.4])
    saveFig(gcf,'c2c_stab',{'pdf'});

    figure()
    mkWhisker(across.rsm.envSim(:,1+[1 9 3 4 10 5 7 2 8 6]))
    saveFig(gcf,'c2c_envSim',{'pdf'});

%     save('RSA_SR_2.mat','-struct','across','-v7.3');
    across = load('RSA_SR_3');
    doRSA(across,'Plots');
    doRSA_SRGridSearch(across,'Plots');

    figure
    set(gcf,'position',[50 50 150 225])
    mkWhisker([across.models.fit.allo(:,1) across.models.fit.bt(:,1)])
    saveFig(gcf,[root '/ModelComparison/SummaryMeasures'],[{'tiff'} {'pdf'}]);

    figure
    imagesc(nanmean(across.rsm.pearson,3))
    caxis([0 0.6])
    colormap magma
    axis equal
    axis square
    axis off
    alpha(double(~isnan(nanmean(across.rsm.pearson,3))))
    saveFig(gcf,[root '/RSM_Pearson_All'],[{'tiff'} {'pdf'}]);
    
    figure
    set(gcf,'position',[50 50 300 300])
    tmp = squarify(nanmean(across.rsm.bySeq.partitioned_pearson,3));
    tmp(1:length(tmp)+1:end) = nan;
    imagesc(tmp)
    alpha(double(~isnan(tmp)));
    axis square
    colorbar
    colormap magma
%     caxis([-0.2 0.5])
    axis off
    saveFig(gcf,[root '/RSM_c2c_partitioned_trace'],[{'tiff'} {'pdf'}]);
    
    

    mds2D(tmp,[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Smoothed']);


    labels = across.rsa.pearson.label;
    t2 = reshape(across.rsa.pearson.rsm.actual, ...
        [numel(across.rsa.pearson.rsm.actual(:,:,1)) ...
        size(across.rsa.pearson.rsm.actual,3)]);
    vals = nan(length(t2(1,:)));
    for i = 1:length(t2(1,:))
        for j = i+1:length(t2(1,:))
            isGood = ~[isnan(t2(:,i)) | isnan(t2(:,j))];
            vals(i,j) = corr(t2(isGood,i),t2(isGood,j));
        end
    end
    vals = squarify(vals);

    figure
    set(gcf,'position',[50 50 300 300])
    imagesc(vals)
    colormap inferno
    alpha(double(~isnan(vals)))
    caxis([0 1])
    axis square
    axis equal
    axis off
    colorbar
    saveFig(gcf,'AnimalXAnimal_RSM_Correlation',{'pdf'})

end































 