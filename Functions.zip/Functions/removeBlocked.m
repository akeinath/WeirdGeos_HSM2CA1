function um = removeBlocked(um,blocked)

    blockMap = [0 1 2; 3 4 5; 6 7 8]';

    partSize = ceil(length(um(:,1,1,1))./3);
    for si = 1:length(um(1,1,1,:))
        for i = 1:3
            for j = 1:3
                if ismember(blockMap(i,j),blocked{si})
                    um((i-1).*partSize+1:(i).*partSize,(j-1).*partSize+1:(j).*partSize,:,si) = nan;
                end
            end
        end
    end
end