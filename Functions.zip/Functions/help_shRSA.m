function [fits jointNoiseCeiling tradNoiseCeiling] = help_shRSA(ref,comp,minS,nsims)
    if nargin < 3 || isempty(minS)
        minS = inf;
    end

    if nargin < 4 || isempty(nsims)
        nsims = 100;
    end

%     for q = 1:10
%         ref((q-1).*9+1:(q).*9,(q-1).*9+1:(q).*9,:) = nan;
%         comp((q-1).*9+1:(q).*9,(q-1).*9+1:(q).*9,:) = nan;
%     end

    doType = 'Kendall';
    tradNoiseCeiling = nan(nsims,2,2);
    fits = nan(nsims,1);
    jointNoiseCeiling = nan(nsims,2);
    for si = 1:nsims
        inds = randperm(size(ref,3));

        inds = inds(1:nanmin(minS,size(ref,3)));
        ra = ref(:,:,inds(randi(floor(length(inds)./2),floor(length(inds)./2),1)));
        rb = ref(:,:,inds(floor(end./2)+randi(floor(length(inds)./2),floor(length(inds)./2),1)));

        if nargout > 2
            a = getTri(nanmean(ra,3));
            b = getTri(nanmean(rb,3));

            %%%%%

% % %             a = tanh(getTri(nanmean(atanh(ra),3)));
% % %             b = tanh(getTri(nanmean(atanh(rb),3)));

            c = getTri(nanmean(cat(3,ra,rb),3));
            tradNoiseCeiling(si,:,1) = [corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',doType) ...
                corr(a(~isnan(a)&~isnan(b)),c(~isnan(a)&~isnan(b)),'type',doType)];
        end

        %%%%

        inds = inds(1:nanmin(minS,size(comp,3)));
        ca = comp(:,:,inds(randi(floor(length(inds)./2),floor(length(inds)./2),1)));
        cb = comp(:,:,inds(floor(end./2)+randi(floor(length(inds)./2),floor(length(inds)./2),1)));

        if nargout > 2
            a = getTri(nanmean(ra,3));
            b = getTri(nanmean(rb,3));

% % %             a = tanh(getTri(nanmean(atanh(ra),3)));
% % %             b = tanh(getTri(nanmean(atanh(rb),3)));

            c = getTri(nanmean(cat(3,ra,rb),3));
            tradNoiseCeiling(si,:,2) = [corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',doType) ...
                corr(a(~isnan(a)&~isnan(b)),c(~isnan(a)&~isnan(b)),'type',doType)];
        end

        %%%%

        t1 = getTri(nanmean(cat(3,ra,rb),3));
        t2 = getTri(nanmean(cat(3,ca,cb),3));

% % %         t1 = tanh(getTri(nanmean(atanh(cat(3,ra,rb)),3)));
% % %         t2 = tanh(getTri(nanmean(atanh(cat(3,ca,cb)),3)));

        fits(si,1) = corr(t1(~isnan(t1)&~isnan(t2)), ...
            t2(~isnan(t1)&~isnan(t2)),'type',doType);

        %%%%%

        tmp = cat(4,cat(3,ca,cb),cat(3,ra,rb));
        doFlip = rand(size(tmp,3),1)<0.5;
        doFlip = mod([doFlip+1 doFlip+2],2)+1;
        for i = 1:length(doFlip(:,1))
            tmp(:,:,i,:) = tmp(:,:,i,doFlip(i,:));
        end
        
        ca = tmp(:,:,:,1);
        cb = tmp(:,:,:,2);
        a = getTri(nanmean(ca,3));
        b = getTri(nanmean(cb,3));

% % %         a = tanh(getTri(nanmean(atanh(ca),3)));
% % %         b = tanh(getTri(nanmean(atanh(cb),3)));

        jointNoiseCeiling(si,:) = [corr(a(~isnan(a)&~isnan(b)),b(~isnan(a)&~isnan(b)),'type',doType) ...
            nan]; % corr(a(~isnan(a)&~isnan(c)),c(~isnan(a)&~isnan(c)),'type','Kendall')

    end

end