function cv = pfrPartAnalysis(sim,blocked,envs)

    [blah pfrPart] = nanmax(sim.partitioned.pfr,[],2);
    pfrPart(isnan(blah)) = nan;
    pfrPart = permute(pfrPart,[1 3 2]);

    tmp = permute(sim.c2c.pearson,[3 4 1 2]);
    isSameEnv = false(size(tmp(:,:,1,1)));
    isSameEnv([1:12:end]) = true;
    rt = tmp(repmat(isSameEnv,[1 1 length(tmp(1,1,:,1)) length(tmp(1,1,:,1))]));
    rt = reshape(rt,[11 length(tmp(1,1,:,1)) length(tmp(1,1,:,1))]);
    
%     %%% Just blocked-off cells
%     rt = permute(rt,[2 3 1]);
%     for i = 2:10
%         doInclude = bsxfun(@times,ismember(pfrPart(1,:),blocked{i}), ...
%             ismember(pfrPart(1,:),blocked{i})');
%         tmp = rt(:,:,i);
%         tmp(~doInclude) = nan;
%         rt(:,:,i) = tmp;
%     end
%     rt = permute(rt,[3 1 2]);
    
    
    doPairs = [];
    for i = 1:length(rt(1,1,:))
        doPairs = [doPairs; [i.*ones(length(rt(1,1,:))-i,1) [(i+1):length(rt(1,1,:))]']];
    end
    allPairs = nan(11,length(doPairs(:,1)));
    for i = 1:length(doPairs(:,1))
        allPairs(:,i) = rt(:,doPairs(i,1),doPairs(i,2));
    end

    
    numClosed = cellfun(@length,blocked);
    numClosed([1 11]) = 0;
    
    corrVal = nan(1,11);
    
    figure
    set(gcf,'position',[50 50 300.*5 300.*2])
    ref = nanmean(allPairs([1],:),1);
    for i = 2:11
        cr = allPairs(i,:);
        isGood = ~isnan(ref)&~isnan(cr);

        [rval pval] = corr(ref(isGood)',cr(isGood)','type','pearson');
        corrVal(i) = rval;
        
        subplot(2,5,(i-1))
        scatter(ref(isGood),cr(isGood),0.5)
        hold on
        plot([-1 1],[0 0],'linestyle','--','color','k')
        plot([0 0],[-1 1],'linestyle','--','color','k')
        set(gca,'xlim',[-1 1],'ylim',[-1 1])
        lsline
        axis equal
        axis square
        title(upper(envs{i}))
        text(-0.9,-0.75,sprintf('r = %0.3f\np = %0.3f',[rval pval]))
    end
    drawnow
    
    cv = repmat({[]},[1 5]);
    for i = 0:4
        tmp = corrVal(numClosed'==i);
        cv{i+1} = tmp(~isnan(tmp));
    end
end




















