function [hs ms asFits asJNC] = rsaXSmooth_overall(root,allHumanMaps,allMouseMaps)

    doHumanSmooth = [0.25:0.25:4];
    doMouseSmooth = [-1 0.25:0.25:4];
    asFits = nan(length(doHumanSmooth),length(doMouseSmooth));

    for mi = 1:length(doMouseSmooth)
        [rsm.overall.mouse_raw, ~, smm] = m2rsm(allMouseMaps,doMouseSmooth(mi),1);
        predictedHumanMaps = predictMaps(allHumanMaps(end),{cat(3,smm{:})}); % allHumanMaps(end)
        [rsm.overall.mouse_pred] = m2rsm(predictedHumanMaps,-1,1);
        for hi = 1:length(doHumanSmooth)
            rsm.overall.human = m2rsm(allHumanMaps(end),doHumanSmooth(hi),1);
            [fits] = help_shRSA(rsm.overall.human,rsm.overall.mouse_pred,[]);
            asFits(hi,mi) = nanmean(fits);
        end
    end

    figure
    set(gcf,'position',[50 50 250 250])
    imagesc(asFits(:,:,1))
    set(gca,'xtick',[1:length(doMouseSmooth)],'xticklabel',doMouseSmooth,...
        'ytick',[1:length(doHumanSmooth)],'yticklabel',doHumanSmooth)
    xlabel('CA1 map smoothing')
    ylabel('HSM map smoothing')
    tmp = cool;
    colormap(1-tmp(:,[2 1 1]))
    colorbar
    title('Predicted Fit (Overall)')
    saveFig(gcf,'Plots/Experiment_1/Summary/Smoothing_Overall',[{'tiff'} {'pdf'}])
    drawnow

    a = asFits(:,:,1);
    [x y] = find(a==nanmax(a(:)));

    hs = doHumanSmooth(x);
    ms = doMouseSmooth(y);

    fprintf(sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));

    outP = ['Stats/' root '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    fprintf(fid,sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));
    fclose(fid);
end
