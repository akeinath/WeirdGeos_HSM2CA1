function placeTraces = genLinPlace(inTrace)

    nBVCs = size(inTrace{1},1);

    %%%%%%% Make geometric place cells
    nPCs = nBVCs;
    placeTraces = repmat({[]},[1 length(inTrace)]);
    connections = repmat({[]},[1 nPCs]);
    for si = [1:length(inTrace)]
        %%%% Geometric SR traces
        allFits = [];
        tpt = nan(nPCs,size(inTrace{si},2));
        for k = 1:nPCs
            if si == 1
                nCons = poissrnd(4,1,1);
                while nCons<2 || nCons>16
                    nCons = poissrnd(4,1,1);
                end
                inds = randperm(nBVCs);
                connections{k} = inds(1:nCons);
            end
            tpt(k,:) = nansum(inTrace{si}(connections{k},:),1);
        end
        placeTraces{si} = tpt;
    end
end