function mkExampleFigures(paths)
    clc
    close all
    drawnow
    fprintf('\n')
    %%% Reliability constaint
    
    warning off all
    if isempty(gcp)
        parpool('local',7);
    end
    pctRunOnAll warning off all
    
    %% Split by animal
    piece = [];
    ag = [];
    spiece = [];
    for i = 1:length(paths)
        ind = find(ismember(paths{i},'/'),1,'last')-1;
        piece = [piece; {paths{i}(1:ind)}];
        spiece = [spiece; {paths{i}(ind+2:end-4)}];
    end
    upiece = unique(piece);
    
    for mi = 1:length(upiece)
        fprintf(['\n\n\tMouse:  ' num2str(upiece{mi}) '\n']) 
        isM = find(ismember(piece,upiece(mi)));
        
        figure(1)
        set(gcf,'position',[0 0 ceil(sqrt(length(isM))).*240 ceil(sqrt(length(isM))).*150]);       
        figure(2)
        set(gcf,'position',[0 0 ceil(sqrt(length(isM))).*240 ceil(sqrt(length(isM))).*150]);
        for si = 1:length(isM)
            fprintf(['\n\t\tSession:  ' paths{isM(si)}])
            s = load(paths{isM(si)},'processed','properties','calcium');
            
            figure(1)
            subplot(ceil(sqrt(length(isM))),ceil(sqrt(length(isM))),si)
            imagesc(s.calcium.meanFrame)
            colormap gray
            axis equal
            axis off

            figure(2)
            subplot(ceil(sqrt(length(isM))),ceil(sqrt(length(isM))),si)
            SFPs = s.calcium.SFPs;
            SFPs = SFPs./repmat(nanmax(nanmax(SFPs,[],1),[],2),[size(SFPs(:,:,1))]);
            if isfield(s.processed,'exclude')
                doSFPs = s.processed.exclude.SFPs;
            else
                doSFPs = true(length(SFPs(1,1,:)),1);
            end
            imagesc((nanmax(SFPs(:,:,doSFPs),[],3)).^(1.5))
            axis equal
            axis off
            colormap inferno
        end
        figure(1)
        slashInds = find(ismember(upiece{mi},'/'));
        outP = ['Plots/FOVs/' upiece{mi}(slashInds+1:end) ];
        saveFig(gcf,outP,[{'pdf'} {'tiff'}])
        
        figure(2)
        slashInds = find(ismember(upiece{mi},'/'));
        outP = ['Plots/SFPs/' upiece{mi}(slashInds+1:end) ];
        saveFig(gcf,outP,[{'pdf'} {'tiff'}])
        close all
    end
end