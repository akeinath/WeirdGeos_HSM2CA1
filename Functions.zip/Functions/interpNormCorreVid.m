function interpNormCorreVid(ms)
%     clc
    
    fprintf('\n\t--Checking and correcting error frames... \n')
    
    obj = VideoReader([ms.dirName '/' 'msvideo.avi']);
    tmp = read(obj);
    tmp = double(tmp);
    tmp2 = reshape(tmp,[obj.Width.*obj.Height length(tmp(1,1,1,:))]);
    dmAct = diff(nanmean(tmp2));
    maxInterp = 0;
    thresh = 1;
    while any(abs(dmAct) > thresh)
        plot(dmAct)
        drawnow
        
        maxInterp = maxInterp+1;
        badInd = find(dmAct>thresh);
        blah = diff(badInd);
        ignore = [false blah<30];
        badInd(ignore) = [];
        tmp(:,:,badInd) = tmp(:,:,badInd-1);
        
        badInd = find(dmAct<-thresh);
        blah = diff(badInd);
        ignore = [false blah<30];
        badInd(ignore) = [];
        tmp(:,:,badInd+1) = tmp(:,:,badInd);
        
        
        tmp2 = reshape(tmp,[obj.Width.*obj.Height length(tmp(1,1,1,:))]);
        dmAct = diff(nanmean(tmp2));
    end
    fprintf(['\n\t\t--Max number of interpolations: ' num2str(maxInterp)])
    
    tmp = uint8(tmp);
    clear tmp2
    
    outObj = VideoWriter([ms.dirName '/' 'msvideo.avi'],'Grayscale AVI');
    open(outObj)
    writeVideo(outObj,tmp);
    close(outObj)
    
end