function [si shc] = getMouseMapStats(m,spm,samp,mSmooth) % WRITE THIS
    si = repmat({[]},[size(m)]);
    shc = repmat({[]},[size(m)]);
    for i = 1:length(m(:,1))
        for j = 1:length(m(1,:))

            if isempty(m{i,j})
                continue
            end

            tm = m{i,j};
            kern = fspecial('gauss',[size(tm,[1]).*3.*ones(1,2)],mSmooth);
            isBad = isnan(tm);
            tm(isBad) = 0;
            tm = imfilter(tm,kern,'same');
            tm(isBad) = nan;

            tspm = spm{i,j};
            kern = fspecial('gauss',[size(tspm,[1]).*3.*ones(1,2)],mSmooth);
            isBad = isnan(tspm);
            tspm(isBad) = 0;
            tspm = imfilter(tspm,kern,'same');
            tspm(isBad) = nan;

            ts = samp{i,j};
            kern = fspecial('gauss',[size(ts,[1]).*3.*ones(1,2)],mSmooth);
            isBad = isnan(ts);
            ts(isBad) = 0;
            ts = imfilter(ts,kern,'same');
            ts(isBad) = nan;

            for q = 1:size(tm,4)
                si{i,j}(:,q) = getSI(tm(:,:,:,q),ts(:,:,q)); 
                shc{i,j}(:,q) = mcr(tspm(:,:,:,q,1),tspm(:,:,:,q,2));
            end
        end
    end
end