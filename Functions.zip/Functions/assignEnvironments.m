function assignEnvironments(paths)

    clc
    fprintf(['\t\nAssigning environment names.\n\n'])
    warning off all
    
    
    envSize = [17 17];
    tmp = false(envSize);
    tmp(1:15,1:15) = true;
    labels = [{[-1]} {tmp}];
    tmp = false(envSize);
    tmp(1:5,1:15) = true;
    tmp(11:15,1:15) = true;
    tmp(1:15,1:5) = true;
    tmp(1:15,11:15) = true;
    labels = [labels; {[4]} {tmp}];
    tmp = false(envSize);
    tmp(1:15,6:10) = true;
    tmp(6:10,1:15) = true;
    labels = [labels; {[0 2 6 8]} {tmp}];
    tmp = false(envSize);
    tmp(1:15,1:5) = true;
    tmp(6:10,1:15) = true;
    labels = [labels; {[3 5 6 8]} {tmp}];
    tmp = false(envSize);
    tmp(1:5,1:15) = true;
    tmp(1:15,1:5) = true;
    tmp(1:15,11:15) = true;
    labels = [labels; {[4 5]} {tmp}];
    tmp = false(envSize);
    tmp(1:10,1:15) = true;
    labels = [labels; {[2 5 8]} {tmp}];
    tmp = false(envSize);
    tmp(1:15,1:5) = true;
    tmp(1:15,11:15) = true;
    tmp(6:10,1:15) = true;
    labels = [labels; {[3 5]} {tmp}];
    tmp = false(envSize);
    tmp(6:15,1:5) = true;
    tmp(1:15,11:15) = true;
    tmp(1:5,6:10) = true;
    tmp(11:15,6:10) = true;
    labels = [labels; {[0 4]} {tmp}];
    tmp = false(envSize);
    tmp(1:5,6:15) = true;
    tmp(6:10,1:15) = true;
    tmp(11:15,1:10) = true;
    labels = [labels; {[0 8]} {tmp}];
    tmp = false(envSize);
    tmp(1:5,1:15) = true;
    tmp(1:15,11:15) = true;
    labels = [labels; {[1 2 4 5]} {tmp}];
    
    nameLabels = getEnvLabels;
    
    for p = paths'
        s = load(p{1});
        fprintf(['\n\t\t' num2str(p{1})])
        
        [map samp] = mkTraceMaps(s.processed.p,s.processed.trace,[],envSize);
        samp = (samp./30) > 1;
        
        sampDiff = permute(nansum(nansum(abs(bsxfun(@minus,samp,cat(3,labels{:,2}))),1),2),[3 1 2]);
        [a b] = nanmin(sampDiff);
        s.processed.blocked = labels{b,1};
        
        tmpA = cellfun(@ismember,repmat({s.processed.blocked}, ...
            [length(nameLabels(:,1)) 1]),nameLabels(:,1),'uniformoutput',false);
        
        tmpB = cellfun(@ismember,nameLabels(:,1),repmat({s.processed.blocked}, ...
            [length(nameLabels(:,1)) 1]),'uniformoutput',false);
        s.processed.environment = nameLabels{cellfun(@all,tmpA)&cellfun(@all,tmpB),2};
        
        save(p{1},'-struct','s','-v7.3');
    end
end