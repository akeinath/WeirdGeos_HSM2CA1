function weird_mds2D(mat,envs,root)

    goodPatches = any(~isnan(mat));

    [mdssim] = mdscale(1-mat(goodPatches,goodPatches),2);
    mdssim = mdssim(:,1:2);

    figure
    set(gcf,'position',[50 50 400 400])
    lim = nanmax(abs(mdssim(:)))+0.05;
    set(gca,'xlim',[-lim lim],'ylim',[-lim lim])
    hold on
    
    envMap = [{'g1'} {[-[[3 1 1  0 0 2 2 3]+1.5]' [3 3 2 2 0 0 1 1]'-1.5]} ; ...
        {'sq1'} {[[[3 0 0 3]-1.5]' [3 3 0 0]'-1.5]}; ...
        {'x1'} {[[3 2 2 1 1 0 0 1 1 2 2 3]'-1.5 [2 2 3 3 2 2 1 1 0 0 1 1]'-1.5]}
        {'u1'} {[[3 0 0 3 3 1 1 3]'-1.5 [3 3 0 0 1 1 2 2]'-1.5]}
        {'h1'} {[[3 0 0 1 1 0 0 3 3 2 2 3]'-1.5 [3 3 2 2 1 1 0 0 1 1 2 2]'-1.5]}];
    
    tc = hsv(8);
    keyColor = [tc(1:3,:);  tc(8,:); zeros(1,3); tc(4,:); flipud(tc(5:7,:))].*0.75+0.25;
    
    
    patchSize = 9;
    patchLabel = mod([1:length(mat)]-1,patchSize)+1;
    eLabel = floor([0:length(mat)-1]./patchSize)+1;
    geLabel = eLabel(goodPatches);
    gpLabel = patchLabel(goodPatches);
    genvs = envs(geLabel);
    
    initSize = 6;
    keySize = lim.*0.025.*ones(length(mat));
    gkeySize = keySize(goodPatches);
%     for i = 1:patchSize
%         plot(mdssim(patchLabel(goodPatches)==i,1),mdssim(patchLabel(goodPatches)==i,2),'marker','none', ...
%             'color',keyColor(i,:),'linewidth',1);
%     end

    for i = 1:length(mdssim(:,1))
        hold on
        doShape = envMap{ismember(envMap(:,1),genvs(i)),2};
        patch(mdssim(i,1)+doShape(:,1).*gkeySize(i),mdssim(i,2)+doShape(:,2).*gkeySize(i),keyColor(gpLabel(i),:), ...
            'edgecolor','w','linewidth',0.5)       
% %         h = plot(mdssim(i,1),mdssim(i,2),'marker',keyShape(geLabel(i)), ...
% %             'color',keyColor(gpLabel(i),:),'markerfacecolor',keyColor(gpLabel(i),:), ...
% %             'markersize',keySize(i),...
% %             'markeredgecolor','w');
%         if geLabel(i) == nanmax(geLabel)
%             set(patchHndl,'edgecolor','k','linewidth',1.5);
% %             set(h,'markeredgecolor','k','linewidth',1.5);
% %             text(mdssim(i,1),mdssim(i,2),upper(envLabel(envI)),'fontname','arial',...
% %                 'fontsize',6,'fontweight','bold','horizontalalignment','center',...
% %                 'verticalalignment','middle')
%         end
    end
    set(gca,'color','k')
    ylabel('MDS Dim 2 (a.u.)');
    xlabel('MDS Dim 1 (a.u.)');
    axis square
    axis equal
    
    checkP(root);
    saveFig(gcf,[root],[{'pdf'} {'tiff'}]);
end