function batchAnalyses(paths)

    across = prepAcross();
    
    warning off all
    
    clc
    fprintf('\n\t\t\t*********Running batched analyses********\n\n');
    
    for mi = 1:length(paths)
        close all
        drawnow
        fprintf(['\n' paths{mi}]);
        load(paths{mi},'um','umfr','envs','blocked','unum','upfr','uGT');
        slashInds = find(ismember(paths{mi},'/'));
        root = ['Plots/BatchedAnalyses/' paths{mi}(slashInds(3)+1:end-4)];
        
        %%% Preprocess and canonically order
        [canonOrder b] = unique(envs(2:end));
        canonOrder = [canonOrder([1:7 9:10]); canonOrder(8)];
        canonOrderNames = canonOrder;
        canonOrder = [1; [b([1:7 9:10]); b(8)]+1];
        
        %reorder
        um = um(:,:,:,canonOrder);
        unum = unum(:,:,:,canonOrder);
        umfr = umfr(:,canonOrder);
        upfr = upfr(:,canonOrder);
        uGT = uGT(:,canonOrder);
        blocked = blocked(canonOrder);
        envs = envs(canonOrder);
        envs{end} = [envs{end} ' 2'];
        
        across.mfr = [across.mfr; umfr];
        across.pfr = [across.pfr; upfr];
        
        sim = getPairwiseMapSim(um,'pearson','pv','partitioned_pfr', ...
            'c2c_pearson','partitioned_pfr','partitioned_pearson','partitioned_pv'); %,'partitioned_pearson');
        unsim = getPairwiseMapSim(unum,'partitioned_pfr','partitioned_pearson','partitioned_pv');
        
        if isfield(unsim,'partitioned') && isfield(unsim.partitioned,'pearson')
            across.unum.partitioned.pv = cat(3,across.unum.partitioned.pv, ...
                unsim.partitioned.pv);
            across.unum.partitioned.pearson = cat(3,across.unum.partitioned.pearson, ...
                unsim.partitioned.pearson);
            across.unum.partitioned.dpfr = cat(3,across.unum.partitioned.dpfr, ...
                unsim.partitioned.dpfr);
            across.um.partitioned.pv = cat(3,across.um.partitioned.pv, ...
                sim.partitioned.pv);
            across.um.partitioned.pearson = cat(3,across.um.partitioned.pearson, ...
                sim.partitioned.pearson);
            across.um.partitioned.dpfr = cat(3,across.um.partitioned.dpfr, ...
                sim.partitioned.dpfr);
        end
        
%         pfrPartAnalysis(sim,blocked,envs)
        
% % %         %%%%%%%%%% Field to field vector stuff %%%%%%%%%% 
% % %         
% % %         out = getVecFields(um,blocked,envs);
% % %         for si = 1:11
% % %             for sj = 1:11
% % %                 across.f2f{si,sj} = [across.f2f{si,sj}; out.f2f{si,sj}];
% % %                 across.pv2pv{si,sj} = cat(3,across.pv2pv{si,sj},out.pv2pv(:,:,si,sj));
% % %             end
% % %         end
% % % 
        %%%%%%%%%%%%%%%% Heterogeniety %%%%%%%%%%%%%%%%%%

        outTrace = c2cTraceAnalysis(uGT,blocked,envs);
        across.c2c.trace.xc = [across.c2c.trace.xc; outTrace.acv];
        across.c2c.trace.condProb = [across.c2c.trace.condProb; outTrace.acv];
        saveFig(gcf,[root '/Cell2cell_Trace_Conditional_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
        out = c2csimAnalysis(sim,blocked,envs);
        across.c2c.simVsBlocked = [across.c2c.simVsBlocked; out.acv];
        saveFig(gcf,[root '/Cell2cell_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
        
        numClosed = cellfun(@length,blocked);
        numClosed([1 11]) = 0;
        for i = 1:4
            across.c2c.closedHiSqStab{i} = [across.c2c.closedHiSqStab{i}; ...
                cat(1,out.hiSqStabilityPairs{numClosed==i})];
        end
    
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        



% % %         imagesc(squarify(permute(sim.c2c.pearson,[3 4 1 2])))
% % %         
% % %         figure
% % %         set(gcf,'position',[50 50 600 300])
% % %         subplot(1,2,1)
% % %         imagesc(permute(sim.c2c.pearson(1,2,:,:),[3 4 1 2]))
% % %         axis equal
% % %         subplot(1,2,2)
% % %         imagesc(permute(sim.c2c.pearson(2,1,:,:),[3 4 1 2]))
% % %         axis equal
% % %     
% % %         tmp = permute(sim.c2c.pearson,[3 4 1 2]);
% % %         allSims = nan(length(um(1,1,1,:)),length(um(1,1,1,:)),nchoosek(length(um(1,1,:,1)),2));
% % %         ind = 0;
% % %         for ki = 1:length(um(1,1,:,1))
% % %             for kj = ki+1:length(um(1,1,:,1))
% % %                 ind = ind+1;
% % %                 allSims(:,:,ind) = tmp(:,:,ki,kj);
% % %             end
% % %         end
% % %         
% % %         
% % %         isGood = true(size(sim.partitioned.pfr(:,:,1)));
% % %         isGood(~triu(true(size(isGood)))) = false;
% % %         sim.partitioned.pfr(repmat(~isGood,[1 1 length(sim.partitioned.pfr(1,1,:))])) = nan;
% % %         
% % %         [c2c cell_ids] = c2cSim(sim.partitioned.pfr,30);
% % %         [sc2c order] = sortSim(c2c);
% % %         
% % % %         sim = getPairwiseMapSim(um(1:3,1:3,:,:),'pearson','pv','partitioned_pearson');
% % %         
        
% % %         rb = repmat(blocked,[1 9])';
% % %         mds2D(nanmean(unsim.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Unsmoothed']);
% % %         mds2D(1-nanmean(unsim.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Unsmoothed']);
% % %         mds2D(nanmean(sim.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Smoothed']);
% % %         mds2D(1-nanmean(sim.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Smoothed']);
% % %         mds2D(unsim.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Unsmoothed']);
% % %         mds2D(sim.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Smoothed']);

%         figure
%         set(gcf,'position',[50 50 600 500])
%         imagesc(squarify(nanmean(sim.pearson,3)))
%         colorbar
%         axis off
%         axis square
%         alpha(double(~isnan(squarify(nanmean(sim.pearson,3)))))
%         saveFig(gcf,[root '/WholeMap_RateMapSimilarity'],[{'tiff'} {'pdf'}])

%         figure
%         set(gcf,'position',[50 50 600 500])
%         imagesc(squarify(nanmean(unsim.partitioned.pearson,3)))
%         colorbar
%         axis off
%         axis square
%         alpha(double(~isnan(squarify(nanmean(unsim.partitioned.pearson,3)))))
%         saveFig(gcf,[root '/Partition_MDS'],[{'tiff'} {'pdf'}])
    end

    root = ['Plots/BatchedAnalyses/Summary']; 
    
    %%%%%% MDS Stuff %%%%%%%%%%
    
    rb = repmat(blocked,[1 9])';
    val = mds2D(nanmean(across.unum.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Unsmoothed']);
    val = mds2D(1-nanmean(across.unum.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Unsmoothed']);
    val = mds2D(nanmean(across.um.partitioned.pearson,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/Pearson_Smoothed']);
    val = mds2D(1-nanmean(across.um.partitioned.dpfr,3),rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PFR_Smoothed']);
    val = mds2D(across.unum.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Unsmoothed']);
    val = mds2D(across.um.partitioned.pv,rb(:)',[repmat(0:8,[1 11])],[root '/Partition_MDS/PV_Smoothed']);
    
    %%%%%%%%%%%%%%%%%%%%% Firing rate stuff %%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 450 275])
    mkBow(bsxfun(@minus,across.mfr(:,2:end),across.mfr(:,1)))
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    label = cellfun(@upper,canonOrderNames','uniformoutput',false);
    label{end} = 'SQUARE 2';
    set(gca,'xticklabel',label)
    ylabel('Change in MFR')
    saveFig(gcf,[root '/MFR_Difference'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 450 275])
    mkBow(bsxfun(@minus,across.pfr(:,2:end),across.pfr(:,1)))
    hold on
    plot(get(gca,'xlim'),[0 0],'linestyle','--','color','k')
    label = cellfun(@upper,canonOrderNames','uniformoutput',false);
    label{end} = 'SQUARE 2';
    set(gca,'xticklabel',label)
    ylabel('Change in PFR')
    saveFig(gcf,[root '/PFR_Difference'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%% Heterogeneity Rate Map Stuff %%%%%%%%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkBow(across.c2c.closedHiSqStab)
    set(gca,'xticklabel',[1:4])
    xlabel('# of closed partitions')
    ylabel('Correlation')
    set(gca,'ylim',[-1 1])
    hold on
    plot(get(gca,'xlim'),[0 0],'color','k','linestyle','--')
    saveFig(gcf,[root '/Cell2cell_Heterogeniety_OnlyHiSqStabPairs'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(cellfun(@nanmean,across.c2c.simVsBlocked),0:4,[0.2 0.2 1])
    set(gca,'xticklabel',[0:4])
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%% Heterogeneity Trace Stuff %%%%%%%%%%%%%%%%%%%%%%%
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(across.c2c.simVsBlocked,envs,[0.2 0.2 1])
    set(gca,'xticklabel',envs)
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Trace_XC_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    figure
    set(gcf,'position',[50 50 250 275])
    mkGraph(across.c2c.trace.condProb,envs,[0.2 0.2 1])
    set(gca,'xticklabel',envs)
    xlabel('# of closed partitions')
    ylabel('Correlation')
    saveFig(gcf,[root '/Cell2cell_Trace_CondProb_Heterogeniety'],[{'tiff'} {'pdf'} {'jpeg'}])
    
    %%%%%%%%%%%%%%% Field transition stuff %%%%%%%%%%%%%%%%%%%%%%
    
    mkf2f2Vec(across.f2f,blocked,root)
    mkpv2pv2Vec(across.pv2pv,blocked,root)
    
    
    figure
    set(gcf,'position',[50 50 length(um(1,1,1,:)).*200 4.*200])
    for sj = 1:10

        a = across.f2f{sj}(:,1:2);
        b = across.f2f{sj}(:,3:4);

        vm = [];
        for i = 1:length(um(:,1,1,1))
            for j = 1:length(um(1,:,1,1))
                good = [(floor(a(:,1)) >= (i)) & (floor(a(:,1)) <= (i))] & ...
                    [(floor(a(:,2)) >= (j)) & (floor(a(:,2)) <= (j))];

                vm = [vm; i j nanmean(b(good,[1 2])-[i j],1)];
            end
        end
        vm(any(isnan(vm),2),:) = [];

        subplot(2,5,sj)
        quiver(vm(:,1),vm(:,2),vm(:,3),vm(:,4));
        axis equal
        axis off
    end
end
















 