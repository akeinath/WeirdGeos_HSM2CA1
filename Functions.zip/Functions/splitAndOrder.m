function [rsms canonOrderNames] = splitAndOrder(rsm,envs)
    [canonOrder b] = unique(envs(2:11));
    canonOrder = [canonOrder([1:7 9:10]); canonOrder(8)];
    canonOrderNames = canonOrder;
    canonOrder = [1; [b([1:7 9:10]); b(8)]+1];

    if size(rsm,1) < 50
    
        if iscell(rsm)
            rsms = repmat({[]},[11 11 size(rsm,3) floor(length(envs)./10)]);
        else
            rsms = nan([11 11 size(rsm,3) floor(length(envs)./10)]);
        end
        for i = 1:length(envs)./10
            rsms(:,:,:,i) = rsm((i-1).*10+1:(i).*10+1,(i-1).*10+1:(i).*10+1,:);
        end
        rsms = rsms(:,canonOrder,:,:);
        rsms = rsms(canonOrder,:,:,:);
        if ~iscell(rsm)
            rsms = squarify(rsms);
        end
        if size(rsms,3)==1
            rsms = permute(rsms,[1 2 4 3]); 
        end
    else
        rsms = nan([99 99 size(rsm,3) floor(length(envs)./10)]);
        for i = 1:length(envs)./10
            rsms(:,:,:,i) = rsm((i-1).*90+1:(i).*90+9,(i-1).*90+1:(i).*90+9,:);
        end
        
        pco = [(canonOrder-1).*9 + [1:9]]';
        pco = pco(:);
        
        rsms = rsms(:,pco,:,:);
        rsms = rsms(pco,:,:,:);
        rsms = squarify(rsms);
        if size(rsms,3)==1
            rsms = permute(rsms,[1 2 4 3]); 
        end
    end
end