function plotParamSearch(pc_fits,allParams)

    testConstants = unique(allParams(1,:))';
    testScalars = unique(allParams(2,:))';
    testBeta_1 = unique(allParams(3,:))';
    testBeta_2 = unique(allParams(4,:))';
    pc_stable_fits = unique(allParams(5,:))';
    pc_act_thresh = unique(allParams(6,:))';

    rFits = reshape(pc_fits,[length(testConstants) length(testScalars) length(testBeta_1) length(testBeta_2) length(pc_stable_fits) length(pc_act_thresh)]);
    
    [a b] = nanmax(pc_fits);
    [a b c d e f] = ind2sub(size(rFits,1:6),b);

    figure(1)
    set(gcf,'position',[50 50 1200 300])
    subplot(1,3,1)
    imagesc(testScalars,testConstants,rFits(:,:,c,d,e,f))
    xlabel('Test Scalars')
    ylabel('Test Constants')
    colorbar
% % %     caxis([0.7 0.9])
    colormap inferno
    subplot(1,3,2)
    imagesc(testBeta_2,testBeta_1,permute(rFits(a,b,:,:,e,f),[3 4 1 2 5 6]));
    set(gca,'xticklabels',testBeta_2,'yticklabels',testBeta_1,'ydir','normal')
    ylabel('Beta_B')
    xlabel('Beta_A')
    colorbar
    colormap inferno
    subplot(1,3,3)
    imagesc(pc_act_thresh,pc_stable_fits,permute(rFits(a,b,c,d,:,:),[5 6 1 2 3 4]));
    ylabel('Stable Proportion')
    xlabel('Activity Threshold')
    colorbar
    colormap inferno


%     plot(pc_stable_fits,permute(rFits(a,b,c,d,:),[5 1 2 3 4]),'linewidth',1.5);
%     hold on
%     set(gca,'xlim',[-0.05 1.05])
%     set(gca,'ylim',[-0.05 1.05])
%     plot(get(gca,'xlim'),[0 0],'color',[0.5 0.5 0.5],'linestyle','--')
%     plot(get(gca,'xlim'),[1 1],'color',[0.5 0.5 0.5],'linestyle','--')
%     plot([0 0],get(gca,'ylim'),'color',[0.5 0.5 0.5],'linestyle','--')
%     plot([1 1],get(gca,'ylim'),'color',[0.5 0.5 0.5],'linestyle','--')
end