function traces = activeNorm(traces,propActive)
    
    if nargin < 2 || isempty(propActive)
        propActive = 0.05;
    end

    
    for si = [1:length(traces)]
        traces{si}(isnan(traces{si})) = 0;
        sst = sort(traces{si},'descend');
        thresh = sst(round(length(sst(:,1)).*propActive),:);
        tmp = traces{si} - thresh;
        tmp(tmp<0) = 0;
        tmp = tmp./nanmax(tmp,[],1);
        traces{si} = tmp;
        traces{si}(isnan(traces{si})) = 0;
    end
end