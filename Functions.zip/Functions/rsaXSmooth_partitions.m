function [hs ms asFits asJNC] = rsaXSmooth_partitions(root,allHumanMaps,m)

    doHumanSmooth = [0.25:0.25:4];
    doMouseSmooth = [-1 0.25:0.25:4];
    asFits = nan(length(doHumanSmooth),length(doMouseSmooth));
    for mi = 1:length(doMouseSmooth)
        [~, ~, sm] = m2rsm(m,doMouseSmooth(mi));
        allMouseMaps = [{cat(3,sm{:})}];
        predictedHumanMaps = predictMaps(allHumanMaps(end),allMouseMaps(end));
        [~, tpRSM] = m2rsm(predictedHumanMaps,-1);
        for hi = 1:length(doHumanSmooth)
            [~, thRSM] = m2rsm(allHumanMaps(end),doHumanSmooth(hi));
            
            fits = help_shRSA(thRSM,tpRSM,size(thRSM,3));
            asFits(hi,mi,1) = nanmean(fits);
        end
    end

    figure
    set(gcf,'position',[50 50 250 250])
    imagesc(asFits(:,:,1))
    set(gca,'xtick',[1:length(doMouseSmooth)],'xticklabel',doMouseSmooth,...
        'ytick',[1:length(doHumanSmooth)],'yticklabel',doHumanSmooth)
    xlabel('CA1 map smoothing')
    ylabel('HSM map smoothing')
    tmp = cool;
    colormap(1-tmp(:,[2 1 1]))
    colorbar
    title('Predicted Fit (Partition-wise)')
    saveFig(gcf,'Plots/Experiment_1/Summary/Smoothing_Partitionwise',[{'tiff'} {'pdf'}])
    drawnow

    a = asFits(:,:,1);
    [x y] = find(a==nanmax(a(:)));

    hs = doHumanSmooth(x);
    ms = doMouseSmooth(y);

    fprintf(sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));

    outP = ['Stats/' root '.txt'];
    checkP(outP);
    fid = fopen(outP,'w');
    fprintf(fid,sprintf('\n\t\t***Optimal smoothing: Human = %0.2f, Mouse = %0.2f',[hs ms]));
    fclose(fid);
end
