function [out] = bvc_sr(p,ref,blocked,doS,bvc_distanceConstant,bvc_distanceScalar,sr_timeconstant)

    p = [p(1) p(1) p(1) p];
    blocked = [blocked(1); blocked(1); blocked(1); blocked]; 
    % add three squares for familiarization, maybe rotate paths for less
    % redundancy?
                                                               

%     p = p(doS);
%     ref = ref(:,:,:,doS(1));
%     blocked = blocked(doS);

    if nargin < 5 || isempty(bvc_distanceConstant)
        bvc_distanceConstant = 1;
    end
    if nargin < 6 || isempty(bvc_distanceScalar)
        bvc_distanceScalar = 0.25;
    end
    if nargin < 6 || isempty(sr_timeconstant)
        sr_timeconstant = 0.95;
    end


    fprintf('\n\n\t\tComputing BVC-sr model...')
    tic
    

    nPCs = size(ref,3); % size(ref,3);
    nBVCs = 1000;
    bvcAngs = rand(nBVCs,1).*2.*pi;
    bvcDists = rand(nBVCs,1).*100;
    bvc_angleSD = ones(nBVCs,1).*deg2rad(15);

    combAmt = [2 16]; % lambda = 4;
    nCons = poissrnd(4,nPCs,1);


    bvcMaps = nan(15,15,nBVCs,length(p));
    placeMaps = nan(15,15,nPCs,length(p));
    allTraces = repmat({[]},[1 length(p)]);
    connections = repmat({[]},[nPCs 1]);

    %%% Generate all BVC traces
    for si = [1:length(p)]

        walls = permute(getBlockedBounds(blocked{si}),[2 3 1]);
        wXphd = bsxfun(@minus,repmat(p{si},[2 1]),walls);

        a = permute(walls([3 4],:,:) - walls([1 2],:,:),[3 1 2]);
        wtheta = cart2pol(a(:,1),a(:,2));


        rays = bvcAngs'; %[0:binAng:2.*pi-binAng];
        rayPoints = permute([cos(rays).*200; sin(rays).*200],[1 2 3]);
        m2 = permute(rayPoints(2,:)./rayPoints(1,:),[2 1 3]);
        sc = [sign(rayPoints(1,:))' sign(rayPoints(2,:))'];
        allInDist = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        allInAngs = nan([length(rays) length(wXphd) length(walls(1,1,:))]);
        for j = 1:length(walls(1,1,:))
            w1 = wXphd([1 2],:,j);
            w2 = wXphd([3 4],:,j);

            intOut = lineSegmentIntersect(wXphd(:,:,j)',[zeros(size(rayPoints))' rayPoints']);


            doesInt = intOut.intAdjacencyMatrix;
            d2w = sqrt(intOut.intMatrixX.^2 + intOut.intMatrixY.^2);
            d2w(~doesInt) = nan;
            allInDist(:,:,j) = d2w';
        end
        subAng = mod(wtheta - rays,2.*pi);
        [nearestBorder nbInd] = nanmin(allInDist,[],3);
        nearestBorderAngle = nan(size(nearestBorder));
        for i = 1:length(rays)
            nearestBorderAngle(i,:) = subAng(nbInd(i,:),i)';
        end

        % Distance tuning gaussian
        a = normpdf(bsxfun(@minus,nearestBorder,bvcDists),zeros(size(nearestBorder)), ...
            repmat(bvc_distanceConstant+bvc_distanceScalar.*bvcDists, ...
            [1 length(nearestBorder(1,:))]));
        % Angle tuning gaussian
        b = normpdf(nanmin(abs(nearestBorderAngle-[pi./2]), ...
            abs(nearestBorderAngle-[3.*pi./2])),0,repmat(bvc_angleSD, ...
            [1 length(nearestBorderAngle(1,:))]));
        bvcTrace = a.*b; % Combine

        allTraces{si} = bvcTrace;
    end

    for si = [1:length(p)]
        bvcMaps(:,:,:,si) = mkTraceMaps(p{si},bvcTrace,[],[15 15]);



        allFits = [];
        for k = 1:nPCs
            if si == 1
                tr = ref(:,:,k);
                if all(isnan(tr))
                    continue
                end

                fit = -inf;
                fitThresh = 1;
                fitDecline = 0.0001;
                while fit<fitThresh
                    nCons = poissrnd(4,1,1);
                    if nCons<2 || nCons>16
                        fit = -inf;
                        continue
                    end
                    inds = randperm(nBVCs);
                    m = bvcMaps(:,:,inds(1:nCons),si);
                    tmp = prod(maxnorm(m),3).^(1./nCons);
                    tmp = tmp - nanmax(tmp).*0.3;
                    tmp(tmp<0) = 0;
                    tmp = tmp.*500;
                    fit = corr(tr(~isnan(tr)&~isnan(tmp)), ...
                        tmp(~isnan(tr)&~isnan(tmp)));
                    fitThresh = fitThresh - fitDecline;
                end
                allFits = [allFits; fit];
                connections{k} = inds(1:nCons);
            else
                if ~isempty(connections{k})
                    m = bvcMaps(:,:,connections{k},si);
                    tmp = prod(maxnorm(m),3).^(1./length(connections{k}));
                    tmp = tmp - nanmax(tmp).*0.3;
                    tmp(tmp<0) = 0;
                    tmp = tmp.*500;
                end
            end
            placeMaps(:,:,k,si) = tmp;
        end

%         close all
%         for i = 1:3:1000
%             figure(1)
%             set(gcf,'position',[50 50 800 400])
%             subplot(1,2,1)
%             for j = 1:length(walls(1,1,:))
%                 plot(walls([1 3],1,j),walls([2 4],1,j),'color','k')
%                 hold on
%             end
%             plot(p{si}(1,i),p{si}(2,i),'color','r','marker','o','markerfacecolor','r','markersize',10);
%             set(gca,'xlim',[-5 80],'ylim',[-5 80]);
% 
%             subplot(1,2,2)
%             plot([zeros(1,length(rays)); -cos(rays).*nearestBorder(:,i)'], ...
%                 [zeros(1,length(rays)); -sin(rays).*nearestBorder(:,i)'],'color','k')
%             set(gca,'ylim',[-110 110],'xlim',[-110 110]);
%             hold off
%             drawnow
%         end
    end

    out.maps = placeMaps;
    out.trace = allTraces;
    out.p = p;
    tmp = toc;
    fprintf('  %0.3fs.',tmp);
end







































